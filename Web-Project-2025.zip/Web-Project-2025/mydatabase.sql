--
-- PostgreSQL database dump
--

-- Dumped from database version 17.4 (Debian 17.4-1.pgdg120+2)
-- Dumped by pg_dump version 17.2

-- Started on 2025-05-01 16:08:20

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 242 (class 1255 OID 16559)
-- Name: handle_committee_complete(); Type: FUNCTION; Schema: public; Owner: user
--

CREATE FUNCTION public.handle_committee_complete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  -- Count how many committee members are now assigned to the thesis
  IF (
    SELECT COUNT(*)
    FROM thesis_professor_relationship
    WHERE thesis_id = NEW.thesis_id AND role = 'committee member'
  ) = 2 THEN

    -- Cancel all pending invitations for this thesis
    UPDATE committee_invitations
    SET status = 'canceled'
    WHERE thesis_id = NEW.thesis_id
      AND status = 'pending';

    -- Update the thesis status to 'in progress'
    UPDATE theses
    SET status = 'in progress'
    WHERE id = NEW.thesis_id;
  END IF;

  RETURN NULL; -- This trigger does not modify the inserted row
END;
$$;


ALTER FUNCTION public.handle_committee_complete() OWNER TO "user";

--
-- TOC entry 240 (class 1255 OID 16520)
-- Name: insert_committee_member(); Type: FUNCTION; Schema: public; Owner: user
--

CREATE FUNCTION public.insert_committee_member() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Only insert a new relationship when the invitation is accepted
    IF NEW.status = 'accepted' THEN
        -- Insert the new committee member relationship
        INSERT INTO thesis_professor_relationship (thesis_id, professor_id, role)
        VALUES (NEW.thesis_id, NEW.professor_id, 'committee member');
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.insert_committee_member() OWNER TO "user";

--
-- TOC entry 239 (class 1255 OID 16494)
-- Name: insert_initial_status(); Type: FUNCTION; Schema: public; Owner: user
--

CREATE FUNCTION public.insert_initial_status() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    INSERT INTO status_history (thesis_id, status, updated_at)
    VALUES (NEW.id, 'to be assigned', NOW());
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.insert_initial_status() OWNER TO "user";

--
-- TOC entry 238 (class 1255 OID 16496)
-- Name: insert_status_change(); Type: FUNCTION; Schema: public; Owner: user
--

CREATE FUNCTION public.insert_status_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW.status <> OLD.status THEN
        INSERT INTO status_history (thesis_id, status, updated_at)
        VALUES (NEW.id, NEW.status, NOW());
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.insert_status_change() OWNER TO "user";

--
-- TOC entry 241 (class 1255 OID 16475)
-- Name: insert_supervisor_into_relationship(); Type: FUNCTION; Schema: public; Owner: user
--

CREATE FUNCTION public.insert_supervisor_into_relationship() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  -- Insert a record into the thesis_professor_relationship table with the supervisor's details
  INSERT INTO thesis_professor_relationship (thesis_id, professor_id, role)
  VALUES (NEW.id, NEW.professor_id, 'supervisor');

  -- Return the newly created thesis record
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.insert_supervisor_into_relationship() OWNER TO "user";

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 237 (class 1259 OID 16582)
-- Name: announcements; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.announcements (
    id integer NOT NULL,
    thesis_id integer NOT NULL,
    text text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.announcements OWNER TO "user";

--
-- TOC entry 236 (class 1259 OID 16581)
-- Name: announcements_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.announcements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.announcements_id_seq OWNER TO "user";

--
-- TOC entry 3514 (class 0 OID 0)
-- Dependencies: 236
-- Name: announcements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.announcements_id_seq OWNED BY public.announcements.id;


--
-- TOC entry 229 (class 1259 OID 16500)
-- Name: committee_invitations; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.committee_invitations (
    id integer NOT NULL,
    thesis_id integer NOT NULL,
    professor_id integer NOT NULL,
    status character varying(10),
    invitation_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    response_date timestamp without time zone
);


ALTER TABLE public.committee_invitations OWNER TO "user";

--
-- TOC entry 228 (class 1259 OID 16499)
-- Name: committee_invitations_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.committee_invitations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.committee_invitations_id_seq OWNER TO "user";

--
-- TOC entry 3515 (class 0 OID 0)
-- Dependencies: 228
-- Name: committee_invitations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.committee_invitations_id_seq OWNED BY public.committee_invitations.id;


--
-- TOC entry 231 (class 1259 OID 16524)
-- Name: professor_notes; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.professor_notes (
    id integer NOT NULL,
    thesis_id integer NOT NULL,
    professor_id integer NOT NULL,
    title character varying(255) NOT NULL,
    note text NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT check_note_length CHECK ((length(note) <= 300))
);


ALTER TABLE public.professor_notes OWNER TO "user";

--
-- TOC entry 230 (class 1259 OID 16523)
-- Name: professor_notes_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.professor_notes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.professor_notes_id_seq OWNER TO "user";

--
-- TOC entry 3516 (class 0 OID 0)
-- Dependencies: 230
-- Name: professor_notes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.professor_notes_id_seq OWNED BY public.professor_notes.id;


--
-- TOC entry 220 (class 1259 OID 16411)
-- Name: professors; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.professors (
    id integer NOT NULL,
    user_id integer
);


ALTER TABLE public.professors OWNER TO "user";

--
-- TOC entry 219 (class 1259 OID 16410)
-- Name: professors_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.professors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.professors_id_seq OWNER TO "user";

--
-- TOC entry 3517 (class 0 OID 0)
-- Dependencies: 219
-- Name: professors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.professors_id_seq OWNED BY public.professors.id;


--
-- TOC entry 227 (class 1259 OID 16480)
-- Name: status_history; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.status_history (
    id integer NOT NULL,
    thesis_id integer,
    status character varying(255) NOT NULL,
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.status_history OWNER TO "user";

--
-- TOC entry 226 (class 1259 OID 16479)
-- Name: status_history_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.status_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.status_history_id_seq OWNER TO "user";

--
-- TOC entry 3518 (class 0 OID 0)
-- Dependencies: 226
-- Name: status_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.status_history_id_seq OWNED BY public.status_history.id;


--
-- TOC entry 235 (class 1259 OID 16562)
-- Name: student_submissions; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.student_submissions (
    id integer NOT NULL,
    thesis_id integer NOT NULL,
    draft_file_path text,
    additional_links text[],
    presentation_datetime timestamp without time zone,
    presentation_location text,
    presentation_link text,
    nimertis_link text
);


ALTER TABLE public.student_submissions OWNER TO "user";

--
-- TOC entry 234 (class 1259 OID 16561)
-- Name: student_submissions_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.student_submissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.student_submissions_id_seq OWNER TO "user";

--
-- TOC entry 3519 (class 0 OID 0)
-- Dependencies: 234
-- Name: student_submissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.student_submissions_id_seq OWNED BY public.student_submissions.id;


--
-- TOC entry 224 (class 1259 OID 16440)
-- Name: students; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.students (
    id integer NOT NULL,
    user_id integer NOT NULL,
    student_number integer
);


ALTER TABLE public.students OWNER TO "user";

--
-- TOC entry 223 (class 1259 OID 16439)
-- Name: students_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.students_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.students_id_seq OWNER TO "user";

--
-- TOC entry 3520 (class 0 OID 0)
-- Dependencies: 223
-- Name: students_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.students_id_seq OWNED BY public.students.id;


--
-- TOC entry 222 (class 1259 OID 16423)
-- Name: theses; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.theses (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    synopsis text NOT NULL,
    pdf_file text,
    status character varying(50) DEFAULT 'to be assigned'::character varying NOT NULL,
    professor_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    student_id integer,
    grading character varying(20) DEFAULT 'disabled'::character varying,
    meeting_info jsonb
);


ALTER TABLE public.theses OWNER TO "user";

--
-- TOC entry 221 (class 1259 OID 16422)
-- Name: theses_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.theses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.theses_id_seq OWNER TO "user";

--
-- TOC entry 3521 (class 0 OID 0)
-- Dependencies: 221
-- Name: theses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.theses_id_seq OWNED BY public.theses.id;


--
-- TOC entry 233 (class 1259 OID 16545)
-- Name: thesis_cancellations; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.thesis_cancellations (
    id integer NOT NULL,
    thesis_id integer NOT NULL,
    reason text NOT NULL,
    meeting_info text,
    date timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.thesis_cancellations OWNER TO "user";

--
-- TOC entry 232 (class 1259 OID 16544)
-- Name: thesis_cancellations_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.thesis_cancellations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.thesis_cancellations_id_seq OWNER TO "user";

--
-- TOC entry 3522 (class 0 OID 0)
-- Dependencies: 232
-- Name: thesis_cancellations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.thesis_cancellations_id_seq OWNED BY public.thesis_cancellations.id;


--
-- TOC entry 225 (class 1259 OID 16456)
-- Name: thesis_professor_relationship; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.thesis_professor_relationship (
    thesis_id integer NOT NULL,
    professor_id integer NOT NULL,
    role character varying(20) NOT NULL,
    grade numeric,
    CONSTRAINT thesis_professor_relationship_role_check CHECK (((role)::text = ANY ((ARRAY['supervisor'::character varying, 'committee member'::character varying])::text[])))
);


ALTER TABLE public.thesis_professor_relationship OWNER TO "user";

--
-- TOC entry 218 (class 1259 OID 16398)
-- Name: users; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    name character varying(255),
    email character varying(255),
    role character varying(50),
    address character varying(255),
    cell_phone character varying(20),
    home_phone character varying(20)
);


ALTER TABLE public.users OWNER TO "user";

--
-- TOC entry 217 (class 1259 OID 16397)
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO "user";

--
-- TOC entry 3523 (class 0 OID 0)
-- Dependencies: 217
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- TOC entry 3281 (class 2604 OID 16585)
-- Name: announcements id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.announcements ALTER COLUMN id SET DEFAULT nextval('public.announcements_id_seq'::regclass);


--
-- TOC entry 3274 (class 2604 OID 16503)
-- Name: committee_invitations id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.committee_invitations ALTER COLUMN id SET DEFAULT nextval('public.committee_invitations_id_seq'::regclass);


--
-- TOC entry 3276 (class 2604 OID 16527)
-- Name: professor_notes id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.professor_notes ALTER COLUMN id SET DEFAULT nextval('public.professor_notes_id_seq'::regclass);


--
-- TOC entry 3265 (class 2604 OID 16414)
-- Name: professors id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.professors ALTER COLUMN id SET DEFAULT nextval('public.professors_id_seq'::regclass);


--
-- TOC entry 3272 (class 2604 OID 16483)
-- Name: status_history id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.status_history ALTER COLUMN id SET DEFAULT nextval('public.status_history_id_seq'::regclass);


--
-- TOC entry 3280 (class 2604 OID 16565)
-- Name: student_submissions id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.student_submissions ALTER COLUMN id SET DEFAULT nextval('public.student_submissions_id_seq'::regclass);


--
-- TOC entry 3271 (class 2604 OID 16443)
-- Name: students id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.students ALTER COLUMN id SET DEFAULT nextval('public.students_id_seq'::regclass);


--
-- TOC entry 3266 (class 2604 OID 16426)
-- Name: theses id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.theses ALTER COLUMN id SET DEFAULT nextval('public.theses_id_seq'::regclass);


--
-- TOC entry 3278 (class 2604 OID 16548)
-- Name: thesis_cancellations id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.thesis_cancellations ALTER COLUMN id SET DEFAULT nextval('public.thesis_cancellations_id_seq'::regclass);


--
-- TOC entry 3264 (class 2604 OID 16401)
-- Name: users id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- TOC entry 3508 (class 0 OID 16582)
-- Dependencies: 237
-- Data for Name: announcements; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.announcements (id, thesis_id, text, created_at) FROM stdin;
1	22	We are pleased to announce the thesis presentation of dhmos.\n\nThesis Title: "thesis"\n\nCommittee Members:\n- vasilefs (supervisor)\n- leandros (committee member)\n- mpoulasikhs (committee member)\n\nPresentation Details:\nThe presentation will be held in person at pap street ktirio 3.\nDate and Time: 2/10/2025, 7:00:00 AM\n	2025-04-23 08:16:38.242695
\.


--
-- TOC entry 3500 (class 0 OID 16500)
-- Dependencies: 229
-- Data for Name: committee_invitations; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.committee_invitations (id, thesis_id, professor_id, status, invitation_date, response_date) FROM stdin;
5	19	1	accepted	2025-04-05 13:41:29.456992	2025-04-05 13:42:13.245679
6	9	2	accepted	2025-04-06 16:00:58.492088	2025-04-06 16:01:35.811084
9	20	1	accepted	2025-04-09 16:14:49.155321	2025-04-09 16:15:16.349207
12	22	1	accepted	2025-04-14 09:27:26.639792	2025-04-14 09:45:04.06211
13	22	11	accepted	2025-04-14 10:02:46.152326	2025-04-14 10:04:33.952158
11	23	1	accepted	2025-04-10 13:42:04.874619	2025-04-15 08:30:18.050511
17	19	11	accepted	2025-04-15 09:11:52.67181	2025-04-15 09:17:36.486096
18	19	12	canceled	2025-04-15 09:14:01.306424	\N
20	23	11	accepted	2025-04-22 16:08:58.534854	2025-04-22 16:10:08.894667
\.


--
-- TOC entry 3502 (class 0 OID 16524)
-- Dependencies: 231
-- Data for Name: professor_notes; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.professor_notes (id, thesis_id, professor_id, title, note, updated_at) FROM stdin;
5	19	1	blobloblo	sdavvggrvrg	2025-04-06 09:53:00.222959
6	14	1	leandroinin bombobini gizini	leandros	2025-04-06 12:21:44.287544
7	14	2	eggewgegw	btrbbbbbbbbbb	2025-04-06 16:20:02.912721
11	20	1	hello	worlfd	2025-04-10 13:02:44.80612
10	20	1	ya	yahhhergrgrgrgeergergregrrgegerrrrrrrrrrrrrrrrrrrrrnjve ejv eljnernervjerv ervheifhvev vhrivhevvr\nvreinvreivnjubvvurbveiboivbreoivvbervinknvskvsdksvnsvdkdvnsfkjdlfjjfsldfjsfjfjfjfjfjrewnfericrenhnhucernhuegnhugrnhuewgnwhgnhnhugcnngrwgcgrhewoiioegrvrenrehirrowenwroegmnh\neewggrhugrnhugrhgrhhhhhhhhhhh	2025-04-10 13:05:16.558335
12	20	2	spiuniro	spiuniro golubiro	2025-04-10 13:15:27.887066
16	19	2	kalsheepra	dbbddddddddddddddddffdddddddddddddddd	2025-04-15 08:48:35.548903
\.


--
-- TOC entry 3491 (class 0 OID 16411)
-- Dependencies: 220
-- Data for Name: professors; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.professors (id, user_id) FROM stdin;
1	2
2	6
11	10
12	11
13	15
14	16
15	18
16	20
17	108
18	109
19	110
20	111
21	112
22	113
23	114
24	115
25	116
26	117
27	118
28	119
29	120
30	121
31	122
32	123
33	124
34	125
35	126
36	127
37	128
38	129
39	130
40	131
41	132
42	133
43	134
44	135
45	136
46	137
47	138
48	139
49	140
50	141
51	142
52	143
53	144
54	145
55	146
56	147
57	148
58	149
59	150
60	151
\.


--
-- TOC entry 3498 (class 0 OID 16480)
-- Dependencies: 227
-- Data for Name: status_history; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.status_history (id, thesis_id, status, updated_at) FROM stdin;
1	9	to be assigned	2025-03-29 18:46:48.729572
2	12	to be assigned	2025-03-29 18:46:18.308577
3	14	assigned	2025-04-02 14:14:37.648392
4	13	to be assigned	2025-03-31 09:36:38.320684
5	2	to be assigned	2025-04-03 10:32:47.143253
6	10	to be assigned	2025-03-31 09:52:34.485436
7	4	to be assigned	2025-03-31 09:55:57.067585
8	11	to be assigned	2025-03-31 10:28:02.929034
9	3	to be assigned	2025-03-31 13:20:08.706683
10	15	to be assigned	2025-04-03 11:42:33.895281
11	15	assigned	2025-04-03 11:47:03.456228
12	15	to be assigned	2025-04-03 11:47:35.906024
13	16	to be assigned	2025-04-03 11:48:49.727551
14	16	assigned	2025-04-03 13:57:40.978478
15	19	to be assigned	2025-04-04 15:54:07.581404
16	16	to be assigned	2025-04-05 13:03:48.198925
17	19	assigned	2025-04-05 13:37:50.652683
18	19	to be assigned	2025-04-05 14:02:24.370971
19	19	assigned	2025-04-05 14:05:18.947156
21	19	canceled	2025-04-06 11:54:17.680485
23	20	to be assigned	2025-04-06 12:09:45.420589
25	14	under review	2025-04-06 12:41:45.581098
26	9	assigned	2025-04-06 13:06:56.680648
27	21	to be assigned	2025-04-06 15:07:15.966194
28	2	assigned	2025-04-06 15:19:01.868843
29	2	to be assigned	2025-04-06 15:19:33.715399
30	10	assigned	2025-04-06 15:21:01.177314
31	10	to be assigned	2025-04-06 15:25:54.223366
32	20	assigned	2025-04-06 15:32:11.990758
33	4	assigned	2025-04-06 16:11:51.235236
34	4	to be assigned	2025-04-06 16:13:52.70517
35	4	assigned	2025-04-06 16:14:58.621479
36	4	to be assigned	2025-04-06 16:17:26.192397
37	14	in progress	2022-04-06 16:19:15.186696
38	14	canceled	2025-04-06 16:32:03.514474
39	9	in progress	2025-04-06 16:33:49.87767
40	9	under review	2025-04-06 16:35:05.936514
41	22	to be assigned	2025-04-07 11:35:51.250472
42	22	assigned	2025-04-07 11:36:45.469533
43	23	to be assigned	2025-04-07 12:20:09.353279
44	4	assigned	2025-04-08 10:08:41.310953
45	4	to be assigned	2025-04-08 11:24:22.409412
46	4	assigned	2025-04-08 11:25:12.026376
47	4	to be assigned	2025-04-08 11:25:32.172798
48	12	assigned	2025-04-08 11:34:14.351187
49	12	to be assigned	2025-04-08 12:31:48.747011
50	13	assigned	2025-04-08 12:32:37.874102
51	24	to be assigned	2025-04-08 14:16:20.293729
52	13	to be assigned	2025-04-08 14:28:22.31738
53	16	assigned	2025-04-08 14:29:58.101423
54	16	to be assigned	2025-04-08 14:30:04.581454
55	16	assigned	2025-04-08 14:30:20.631179
56	16	to be assigned	2025-04-08 14:30:34.948297
57	16	assigned	2025-04-08 14:30:48.669095
58	16	to be assigned	2025-04-08 14:38:34.055765
59	16	assigned	2025-04-08 14:38:47.905766
60	16	to be assigned	2025-04-08 14:48:36.560803
61	23	assigned	2025-04-08 14:48:57.817863
62	20	in progress	2025-04-09 17:08:14.285601
63	9	in progress	2025-04-10 13:25:09.86427
64	9	under review	2025-04-10 13:27:16.167919
65	22	in progress	2025-04-14 10:04:33.952158
66	22	under review	2025-04-14 10:31:56.33548
67	20	to be assigned	2025-04-15 08:21:40.122052
68	15	assigned	2025-04-15 08:21:46.77653
69	15	to be assigned	2025-04-15 08:24:03.789711
70	9	assigned	2025-04-15 08:40:39.847874
71	14	assigned	2025-04-15 08:42:29.197859
72	14	to be assigned	2025-04-15 08:44:44.486893
73	9	to be assigned	2025-04-15 08:47:49.775628
75	19	canceled	2025-04-15 08:51:13.017072
76	19	in progress	2025-04-15 08:52:24.802294
77	19	under review	2025-04-15 08:52:55.555633
78	19	assigned	2025-04-15 09:11:12.398172
79	19	in progress	2025-04-15 09:17:36.486096
82	19	canceled	2025-04-21 17:02:03.796106
83	19	in progress	2025-04-21 17:09:52.438014
85	23	in progress	2025-04-22 16:10:08.894667
86	23	under review	2025-04-22 16:18:35.448771
87	23	completed	2025-04-22 16:45:06.159962
88	22	under review	2025-04-23 07:49:58.663128
89	19	under review	2025-04-23 17:02:47.434845
90	19	in progress	2025-04-23 17:21:30.2798
91	19	canceled	2025-04-23 17:23:20.637643
92	19	under review	2025-04-23 17:23:59.958244
94	19	under review	2025-04-23 17:27:38.083508
95	19	completed	2025-04-23 17:28:11.858277
96	13	assigned	2025-05-01 10:06:24.449294
\.


--
-- TOC entry 3506 (class 0 OID 16562)
-- Dependencies: 235
-- Data for Name: student_submissions; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.student_submissions (id, thesis_id, draft_file_path, additional_links, presentation_datetime, presentation_location, presentation_link, nimertis_link) FROM stdin;
9	23	/uploads/studentDrafts/e778a427-7ae7-4a86-b7e0-381bfdd3721d.pdf	{}	2026-02-05 13:30:00	\N	https://www.youtube.com/watch?v=FUFWkuMY6xM&list=RDFUFWkuMY6xM&start_radio=1	https://www.youtube.com/watch?v=FUFWkuMY6xM&list=RDFUFWkuMY6xM&start_radio=1
10	19	/uploads/studentDrafts/55172757-2974-4205-acca-860a9197fd0d.pdf	{https://www.youtube.com/watch?v=G23iLGhh9lo&list=RDNco_kh8xJDs&index=2}	2025-10-10 14:00:00	\N	https://www.youtube.com/watch?v=G23iLGhh9lo&list=RDNco_kh8xJDs&index=2	https://www.youtube.com/watch?v=G23iLGhh9lo&list=RDNco_kh8xJDs&index=2
11	22	/uploads/studentDrafts/7a779791-b8ff-4627-9eb1-abc30cabc070.pdf	{https://nemertes.library.upatras.gr/community-list}	2026-11-11 10:00:00	\N	https://nemertes.library.upatras.gr/community-list	https://nemertes.library.upatras.gr/community-list
\.


--
-- TOC entry 3495 (class 0 OID 16440)
-- Dependencies: 224
-- Data for Name: students; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.students (id, user_id, student_number) FROM stdin;
10	21	10433999
11	22	10434000
12	23	10434001
13	24	10434002
14	25	10434003
15	26	10434004
16	27	10434005
17	28	10434006
18	29	10434007
19	30	10434008
20	31	10434009
21	32	10434010
22	33	10434011
23	34	10434012
24	35	10434013
25	36	10434014
26	37	10434015
27	38	10434016
28	39	10434017
29	40	10434018
30	41	10434019
31	42	10434020
32	43	10434021
33	44	10434022
34	45	10434023
35	46	10434024
36	47	10434025
37	48	10434026
38	49	10434027
39	50	10434028
40	51	10434029
41	52	10434030
42	53	10434031
43	54	10434032
44	55	10434033
45	56	10434034
46	57	10434035
47	58	10434036
48	59	10434037
49	60	10434038
50	61	10434039
51	62	10434040
52	63	10434041
53	64	10434042
54	65	10434043
55	66	10434044
56	67	10434045
57	68	10434046
58	69	10434047
59	70	10434048
60	71	10434049
61	72	10434050
62	73	10434051
63	74	10434052
64	75	10434053
65	76	10434054
66	77	10434055
67	78	10434056
68	79	10434057
69	80	10434058
70	81	10434059
71	82	10434060
72	83	10434061
73	84	10434062
74	85	10434063
75	86	10434064
76	87	10434065
77	88	10434066
78	89	10434067
79	90	10434068
80	91	10434069
81	92	10434070
82	93	10434071
83	94	10434072
84	95	10434073
85	96	10434074
86	97	10434075
87	98	10434076
88	99	10434077
89	100	10434078
90	101	10434079
91	102	10434080
92	103	10434081
93	104	10434082
94	105	10434083
95	106	10434084
96	107	10434085
1	3	1
2	5	2
3	7	3
4	8	4
5	9	5
6	13	6
7	14	7
8	17	8
9	19	9
\.


--
-- TOC entry 3493 (class 0 OID 16423)
-- Dependencies: 222
-- Data for Name: theses; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.theses (id, title, synopsis, pdf_file, status, professor_id, created_at, updated_at, student_id, grading, meeting_info) FROM stdin;
24	king bov	type shit an u know cuhhh	/uploads/pdfs/ac805303-c4bc-480c-9a97-263a7bbf58eb.pdf	to be assigned	2	2025-04-08 14:16:20.293729	2025-04-08 14:21:39.817208	\N	disabled	\N
16	test2	22222222222	\N	to be assigned	1	2025-04-03 11:48:49.727551	2025-04-08 14:48:36.560803	\N	disabled	\N
20	yo babakas	yo	\N	to be assigned	2	2025-04-06 12:09:45.420589	2025-04-06 15:32:11.990758	\N	disabled	\N
15	testo history statusooo	im not stronkk	\N	to be assigned	1	2025-04-03 11:42:33.895281	2025-04-15 08:24:03.789711	\N	disabled	\N
14	trigger test	fingers crossed	\N	to be assigned	1	2025-04-02 14:14:37.648392	2025-04-15 08:44:44.486893	\N	disabled	\N
11	schizophrenia	im losing it i swear to god	\N	to be assigned	1	2025-03-28 16:56:14.552194	2025-03-31 10:28:02.929034	\N	disabled	\N
9	what	i have severe alzheimers but i forgot i have so now i remember	\N	to be assigned	1	2025-03-28 16:12:04.042776	2025-04-10 13:27:16.167919	\N	disabled	\N
4	listen here you 	IM GONNA SAY IT IM GONNA DO IT!	/uploads/pdfs/e35b2be1-65c2-441e-8e61-3c019ad5ae94.pdf	to be assigned	1	2025-03-27 16:46:43.941261	2025-04-08 11:25:32.172798	\N	disabled	\N
23	babababababab	3333333333333333333333	\N	completed	2	2025-04-07 12:20:09.353279	2025-04-22 16:18:35.448771	5	enabled	{"date": "2025-02-02T00:00:00.000Z", "number": 4}
12	aaaaaaaaaaaaaaaa	aaaaaaaaaaaaaaaaaaaaa	\N	to be assigned	1	2025-03-28 17:00:07.882587	2025-04-08 12:31:48.747011	\N	disabled	\N
22	thesis 	babababababaababkads	/uploads/pdfs/09daaa64-e853-420f-b40b-f59eb2bf4fa5.pdf	under review	2	2025-04-07 11:35:51.250472	2025-04-14 10:31:56.33548	4	enabled	{"date": "2025-02-02T00:00:00.000Z", "number": 4}
21	new thesis	weqrewrewrerwqeqwr	/uploads/pdfs/6f4b97fb-e251-4a84-95db-60dd70229c71.pdf	to be assigned	1	2025-04-06 15:07:15.966194	2025-04-06 15:07:15.966194	\N	disabled	\N
2	im confuseddd	i have severe alzheimers but i forgot i have so now i remember	\N	to be assigned	1	2025-03-27 15:40:04.45307	2025-04-06 15:19:33.715399	\N	disabled	\N
10	thesis about umm	i have severe alzheimers but i forgot i have so now i remember	\N	to be assigned	1	2025-03-28 16:12:19.70058	2025-04-06 15:25:54.223366	\N	disabled	\N
3	thesis about some shiiiii	blaaaaaaaaaaaaaa	\N	to be assigned	1	2025-03-27 16:44:33.592741	2025-03-31 13:20:08.706683	\N	disabled	\N
19	babakas magkas	ponos	\N	completed	2	2025-04-04 15:54:07.581404	2025-04-23 17:02:47.434845	3	enabled	{"date": "2025-03-24T00:00:00.000Z", "number": 3}
13	im untouchable	BARRACK OBAMAAAAAAAA	\N	assigned	1	2025-03-28 17:05:48.73172	2025-05-01 10:06:24.449294	37	disabled	\N
\.


--
-- TOC entry 3504 (class 0 OID 16545)
-- Dependencies: 233
-- Data for Name: thesis_cancellations; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.thesis_cancellations (id, thesis_id, reason, meeting_info, date) FROM stdin;
1	19	canceled by professor	Meeting Number: 2, Meeting Year: 2025	2025-04-06 11:54:18.590403
2	14	canceled by professor	Meeting Number: 2, Meeting Year: 2025	2025-04-06 16:32:03.624025
3	19	canceled by professor	Meeting Number: 2, Meeting Year: 2025	2025-04-15 08:51:13.072878
6	19	canceled by student	\N	2025-04-23 17:23:20.637643
\.


--
-- TOC entry 3496 (class 0 OID 16456)
-- Dependencies: 225
-- Data for Name: thesis_professor_relationship; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.thesis_professor_relationship (thesis_id, professor_id, role, grade) FROM stdin;
14	1	supervisor	\N
11	1	supervisor	\N
12	1	supervisor	\N
10	1	supervisor	\N
13	1	supervisor	\N
4	1	supervisor	\N
3	1	supervisor	\N
9	1	supervisor	\N
2	1	supervisor	\N
15	1	supervisor	\N
16	1	supervisor	\N
20	2	supervisor	\N
21	1	supervisor	\N
9	2	committee member	\N
24	2	supervisor	\N
20	1	committee member	\N
22	2	supervisor	5.35
22	11	committee member	8.75
23	2	supervisor	7.10
23	1	committee member	8.00
23	11	committee member	5.00
22	1	committee member	6.79
19	2	supervisor	6.00
19	1	committee member	9.20
19	11	committee member	6.20
\.


--
-- TOC entry 3489 (class 0 OID 16398)
-- Dependencies: 218
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.users (id, username, password, name, email, role, address, cell_phone, home_phone) FROM stdin;
1	ninja	$2b$10$q6Z6rbNBx2iautjJYkrk9u/FpSxTfB9Fnn8njqjy.HWA.FyXKTW8y	james mcjamesey	james@gmail.com	adman	\N	\N	\N
2	silencekiller	$2b$10$Q9xYP4KsTn1YyfdsdEIi2ubHRlJ39p4gyuG0IDmmKQfv75F6B705m	leandros	leandros@gmail.com	professor	\N	\N	\N
3	bigT	$2b$10$.iL27bcBViVmb6shfEozROCyfJvHEcNTQFV6Ca8lS.sQfzLJ.Rl.S	niggos	nig@gmail.com	student	\N	\N	\N
4	toVouno	$2b$10$7HEz4chZtMpVW1MGyetI2.xVx70LVlRec6ftajfiR9IHSY/E9NO6.	monsterini	papanos@gmail.com	secretariat	\N	\N	\N
5	iamghost	$2b$10$KlkxBrQl0.9udz0MISLoSeoFKHQMHpNpbTmL3ML5rBC57DKVyvsg.	raptis	rap@gmail.com	student	\N	\N	\N
6	king	$2b$10$OuVcz70KUhIW0bzEktGuIe1hst4xZwCq82O8Eb75.7q10XXssfOkC	vasilefs	vsil@gmail.com	professor	\N	\N	\N
9	mitch	$2b$10$Yn6Qb70mGISxzEju9gnaLO/WrIruuETOZfNRzs/0TAGqte8ivXmRO	mitch	mitch@mitchmail.com	student	\N	\N	\N
37	emma_stone_1361	$2b$10$hxOsCCB5TAdlhuImfl5Jy.qaf2eiG4EKo/.hHLDkLlvaU0x6iD6HC	Emma Stone	st10434015@upnet.gr	student	Poor Str. 3, Paris 34	4455555	2333333
38	jenny_vanou_8038	$2b$10$fAFeN93.ahORhvk0smoTrOawyzalzld.QOLrau.FfwDbD5P7bBLGm	Jenny Vanou	st10434016@upnet.gr	student	Mpouat Str. 23, Athens 10	45	09
39	salma_hayek_1487	$2b$10$Ovj4.vgpCjE5EDIauIf1AOnZ1Q7bymzuqF9zaFl4FTqSZpm6ephS6	Salma Hayek	st10434017@upnet.gr	student	Desperado Str. 24, Madrid 656	221	344
8	greekatos	$2b$10$w1onjS3kIATgqHllVQ7lhucwXKPxKxDkUJyd7EO/YBYbOh6xMDfmu	dhmos	qewr@hotmail.com	student	papa pipi street yee	6969696966	210
10	sicario	$2b$10$npFN4BXgDoeCOx1a1y.5aOi2BT1c8eENgO378awqvgzMCST3gQR8q	mpoulasikhs	wvn@gmail.com	professor	\N	\N	\N
40	julie_delpy_2957	$2b$10$WKYjFc6lvyFSEyYl9oZHwOr6q/XdXxplDmAz8KBXxiopIHjP4Gb2O	Julie Delpy	st10434018@upnet.gr	student	Before Str. 36, Paris 567	3455	1223
7	boss	$2b$10$y6eRCOfwjF5KuKKrwMfqceDREy1uM4lewFyTPKL9qJHML4jSAtoYa	proestakhs	nasdo@gmail.com	student	3223dsdvfvfsvf	3563	63466446663
11	paulos	$2b$10$ekHjACwqAEW6eZn29xhxGOSDbuyChraHqbbX82I/s.IfrPrcQuwaG	papapapp	paulso@gmail.com	professor	\N	\N	\N
12	secretariat	$2b$10$XfzmuRhUjAfbZhN5/QZTeuUURWlvT7TJjxH5RuvZJiPx.1XpLU2pm	secretariat	secretariat@gmail.com	secretariat	\N	\N	\N
13	alice_johnson_5372	$2b$10$YGEfxMdAfz..vBuQ9iztC.ZFOljKVjZNNa/cIBn0n6YWW.lPTvybG	Alice Johnson	alice.johnson@example.com	student	\N	\N	\N
14	bob_martinez_5504	$2b$10$DcZNbgW6DJml1mCYHlMoS.Lv6GEr4rUZf1Vv93bvuB4aQRnXlzAmu	Bob Martinez	bob.martinez@example.com	student	\N	\N	\N
15	dr_carol_smith_4286	$2b$10$IPUa5hwXE3O8LFx028bSwu9GA7UvMj.iFePtukgim3xqiKq1ZaSjy	Dr. Carol Smith	carol.smith@example.com	professor	\N	\N	\N
16	prof_daniel_lee_1040	$2b$10$QA0mB8ytVU9epewDKMJq/u5iYCCfqWpqDoYAKo5oUkg4Udi34D562	Prof. Daniel Lee	daniel.lee@example.com	professor	\N	\N	\N
17	emily_rivera_7968	$2b$10$dY.VJ9fQx0YLN8zw7Gf2I.Q5QmN6QfNACr/XBgNgCEn0IcSn6lvqK	Emily Rivera	emily.rivera@example.com	student	\N	\N	\N
18	professor_john_green_3976	$2b$10$OfyF17kDpeeR/EIEXBq0ueujmUMgG1itMcpp18iabxnlXPGr1Maca	Professor John Green	john.green@example.com	professor	\N	\N	\N
19	sophia_turner_5561	$2b$10$NU2EPWBzJtf8iH169WwIkuGjHIYY5bOAaaPQMAE2pb1owHOfMRB7e	Sophia Turner	sophia.turner@example.com	student	\N	\N	\N
20	dr_henry_wells_9889	$2b$10$C0RJ7d01xRsbpPhbkFTuouYUXH2lcESH7pt7hOVktkTPE6DOK.qTu	Dr. Henry Wells	henry.wells@example.com	professor	\N	\N	\N
21	makis_makopoulos_5524	$2b$10$T1Qk2JtXZOAYHt9xywRVde.cD.s10IVqmn1XL3oQGlo6TlnZ28Uqm	Makis Makopoulos	104333999@students.upatras.gr	student	test street 45, test city 39955	6939096979	2610333000
22	john_lennon_4005	$2b$10$3SQwx0SklQtyYaxmIxGHIOTJ/NAhUOGR8gmsqXAdHc0ddWBUB4X1q	John Lennon	st10434000@upnet.gr	student	Ermou 18, Athens 10431	6970001112	2610123456
23	petros_verikokos_2068	$2b$10$0lTgjId30q4gi2uEzj./F.5oAWJdNFq2CWH3t2.wetBln4RUfkwci	Petros Verikokos	st10434001@upnet.gr	student	Adrianou 20, Thessaloniki 54248	6970001112	2610778899
24	test_name_6994	$2b$10$eM0nXGUTBsOT9Y/0WykqaulaSTSHPE3JazzPK.MUKHTpGVB.Xh2ZS	test name	st10434002@upnet.gr	student	str 1, patra 26222	6912345678	2610123456
25	robert_smith_6246	$2b$10$ldoKiiQdgXIURs3kZdCeCOV3WC7y9mjWOMYBf6XcTJ10eBUOK5Kw6	Robert Smith	st10434003@upnet.gr	student	Fascination 17, London 1989	6902051989	2610251989
26	rex_tyrannosaurus_9129	$2b$10$bUZ.NG1eEVyofWmBj8ZzM.z.doaaIt1XcD2Vjcg25.8jVpGarQd/.	Rex Tyrannosaurus	st10434004@upnet.gr	student	Cretaceous 2, Laramidia 54321	6911231234	2610432121
27	paul_mescal_5437	$2b$10$w6jMQtZkRFK74h1l6ubtJ.CGKoWe8bPOi8/SR2.H004Enb5ZTVJAW	Paul Mescal	st10434005@upnet.gr	student	Smith Str. 33, New York 59	-	-
28	pedro_pascal_7140	$2b$10$BF7paK318GQVct88KQNS0.uL36uaE5RR5odlxLNq6LjYOzCHZ3R3W	Pedro Pascal	st10434006@upnet.gr	student	Johnson 90, New York 70	-	-
29	david_gilmour_3566	$2b$10$ihLaRilh0yleYtnA/iIXPumvJtMt7xHqQzHUFrRmzu7O2hk4ZzAMO	David Gilmour	st10434007@upnet.gr	student	Sortef 29, New York 26	-	-
30	lana_del_rey_8619	$2b$10$UUtCIMwcYTQenHx95M3wuOGknLhHAwt555/aPdj50bqyoiFej5o4i	Lana Del Rey	st10434008@upnet.gr	student	Groove Str. 23, Los Angeles 1	-	-
31	stevie_nicks_9504	$2b$10$2L5pNsTA/nCfbhrINdSC/.V1bNdYfyCE7ojlD95uU/GNj4zvz6qcS	Stevie Nicks	st10434009@upnet.gr	student	Magic Str. 8, New Orleans 35	67	56
32	margaret_qualley_6927	$2b$10$bGNsYKWFk8rF3zM.jBFkXO/aLy5GIcEjrSKQd6SFworGprX1RYmTC	Margaret Qualley	st10434010@upnet.gr	student	Substance Str. 25, Los Angeles 7	90	67
33	mia_goth_6682	$2b$10$HD7jJ9y8RsA9dV6S0YrLiuHlQsavpiTMA2RKRtNPsBQuGICY8AJfm	Mia Goth	st10434011@upnet.gr	student	Pearl Str. 4, Michigan 8	-	-
34	florence_pugh_1876	$2b$10$pm0O/fbYFqAGR6U/0a6wlebHZVkz.VvQcB./QFlIleJxtYBb46Kgu	Florence Pugh	st10434012@upnet.gr	student	Midsommar Str. l 1, Away 24	2	5
35	pj_harvey_1779	$2b$10$wPZxOi9K1n2pJF9s7R6P7eObA/b.WtdPnEOhMP6wqWzGXCENks9Q2	PJ Harvey	st10434013@upnet.gr	student	Lonely Str. 27, Bridport -7	43	56
36	penlope_cruz_7497	$2b$10$44GNLICgVB7PucRaYMuGfuiPPTT1CQvkYje.zE75YMVBWNYxoVsAy	Penélope Cruz	st10434014@upnet.gr	student	Almadovar 55, Madrid 23	4	5
41	giannis_aggelakas_6378	$2b$10$iP1COmZilqHexuauqKlOKeRnziLrsadvh7bJn0l01eGjCIAyQcEQq	Giannis Aggelakas	st10434019@upnet.gr	student	Trypes Str. 3, Athens 2354	45	23
42	eleutheria_arvanitaki_9715	$2b$10$kjBSMwcjWTfij0sCAh0Kvu46nJQ0SegMhthdjTYwqkmehr3EfsmCm	Eleutheria Arvanitaki	st10434020@upnet.gr	student	Entexno Str. 2, Athens 345	345	657
43	marina_spanou_1996	$2b$10$plGG8ONsilLo0pMI4pn1PuVnvnYIr0k1k5Jf0CKq0Rcaty88nBFcW	Marina Spanou	st10434021@upnet.gr	student	Pagkrati Str. 25, Athens 2456	354	897
44	rena_koumioti_9348	$2b$10$5GgvDyKPHyS9Xq9fB6LYi.w1OJ1O7/BXL4bg/QQs8GlW1W090EFmi	Rena Koumioti	st10434022@upnet.gr	student	Mpouat Str. 24, Athens 5749	32453	23557
45	charlotte_aitchison_1759	$2b$10$2m2vMjGDrsPy41t7VniMwus9JyG2mZCJQzahVq03AWA/IoGqTJW2S	Charlotte Aitchison	st10434023@upnet.gr	student	Boiler Room St 365, New York 360	693653365	2610365365
46	rhaenyra_targaryen_7978	$2b$10$pH0nQ32NISMykivLUhEI6.pmwGa82xtR53ry9P.rBY6vGXDjQZhN2	Rhaenyra Targaryen	st10434024@upnet.gr	student	Dragon St 2021, Kings Landing 2021	6910101010	2610101010
47	ben_dover_7770	$2b$10$Ejiw8xRcdrzVd3lEFgOIU.6lXz.WvgGFvKBU3qmhbeUWoBWlRx3ai	Ben Dover	st10434025@upnet.gr	student	Colon Str. 124A, NY 11045	5841852384	2584694587
48	marios_papadakis_3368	$2b$10$03HmXzVcSp15odaLWmQGVuu0nFOM4XpfNgVK9bzblvp//UFs9.xWC	Marios Papadakis	st10434026@upnet.gr	student	Korinthou 266, Patras 26223	+306975562567	+302105562567
49	nicholas_hoult_6052	$2b$10$IfORSO5HAFYqNhAhjim.6.1YtJnH/FavGK7Vq4qTnC87gqELuzMai	Nicholas Hoult	st10434027@upnet.gr	student	Nosferatu Str. 34, London 567	46478	436
50	joo_hyuk_nam_3240	$2b$10$9/Ba5JVxSxL2.0LEQznGlu4d4oIr7JiP1eveVW6kyh6MYSn4lJgzm	Joo Hyuk Nam	st10434028@upnet.gr	student	Kanakari 135, Patra 26440	6978756432	2610443568
51	nikos_peletie_3707	$2b$10$kHJiKqNql9LXzDz//4VLVO/nQwV/QKFKQR7ZFrwvcmL1hZsY4paz6	Nikos Peletie	st10434029@upnet.gr	student	Kolokotroni 6, Athens 34754	6987655433	2104593844
52	nikos_koukos_9487	$2b$10$qU6vzNlKduCOjlDHTLvZp.RK0InDafzccLKZabgKXthwc8vBKrWH6	Nikos Koukos	st10434030@upnet.gr	student	Triton 12, Salamina 12216	6946901012	210553985
53	maria_fouseki_3858	$2b$10$0ey6tYXJK0eIGP.dHIGM8efuf0bVhFM.1XImFg5cO6k93xQ0LBk2m	Maria Fouseki	st10434031@upnet.gr	student	Jason 33, London 44391	6923144642	2109993719
54	nikos_korobos_4804	$2b$10$P9nt4h12j3VVwXN8DZOFJu0.boN5AHTNfMeGnuD8GTmqwc1QDUHyS	Nikos Korobos	st10434032@upnet.gr	student	Masalias 4, Sparti 32095	6948308576	2279036758
55	maria_togia_9402	$2b$10$Q1OUQvDYWezEEf.lCkgyGegpbK9RXkkzUJXkvnEMCT0j3r.qT1HUe	Maria Togia	st10434033@upnet.gr	student	Athinon 4, Athens 28482	6953782102	2100393022
56	giorgos_menegakis_4174	$2b$10$9y6dBIAJOKo.XP3Q2FTmoe0ACNabaF6bX45D2.YwBsLbzKB9Cpxvu	Giorgos Menegakis	st10434034@upnet.gr	student	korinthou 56, patras 56892	6934527125	2610485796
57	trakis_giannakopoulos_9773	$2b$10$SFYCsZx./6Awt71UZkh0EeyzYYlLFFr4WvKOgqJHSiQEX3gN8Qcb.	Trakis Giannakopoulos	st10434035@upnet.gr	student	Othonos kai Amalias 100, Patras 26500	6028371830	2610381393
58	chris_kouvadis_4381	$2b$10$OBwvafoCi2FSF32Liyflq.s85VDSEVKTZEgUWaOIY.Bq.ZNwr06Ai	Chris Kouvadis	st10434036@upnet.gr	student	vanizelou 36, Patras 26500	6947937524	2610995999
59	pafloutsou_kaskarai_9897	$2b$10$OsMSXc7nxyO0CShNrfnpMeM.8Zr8IYaApKuQPaZGNtpawkSRDIfSi	pafloutsou kaskarai	st10434037@upnet.gr	student	kolokotroni 12, Patras 26500	6935729345	2610978423
60	billy_diesel_6888	$2b$10$Oy97wVSwNYLhY2mCxJ8Z8.OrFBBe4LXaiOt/4qBINnsXoqA95Jq4u	Billy Diesel	st10434038@upnet.gr	student	Alexandras Ave 12, Athens 11521	6912345678	2101234567
61	tome_of_madness_5587	$2b$10$BE5yqrtRr3j745U61oey2erkXmdZetKcwH0s4ErNtw6OxUAKhDZQm	Tome of Madness	st10434039@upnet.gr	student	Panepisthmiou 69, Patras 26441	6969966996	2610654321
62	fort_nite_7986	$2b$10$3L/k2Qaa67Om.nL4x/asXO5mX9DINXNipnZJwcxs0dwEdeP38CFSy	fort nite	st10434040@upnet.gr	student	karaiskakis 69, tilted tower 4747	6988112233	2610747474
63	zeus_ikosaleptos_2861	$2b$10$8oUZRWoJOriyO9dNp2JLBeD6vSTkiqMhiLf4VBWOSCR/TItRusAN2	Zeus Ikosaleptos	st10434041@upnet.gr	student	Novi 25, Athens 20033	6900008005	2109090901
64	ag_cook_8204	$2b$10$vZFQFOvyPg3LQQi4K67ob.XvXimjEPVAGW595YetIzIuh90DaR1G2	AG Cook	st10434042@upnet.gr	student	Britpop 7G, London 2021	1212121212	2121212121
65	maria_mahmood_9260	$2b$10$cuhlVYfODwD6hva9Metrn.sPE8xHA9tFU1FNPjwLronWF5AR/LxIG	Maria Mahmood	st10434043@upnet.gr	student	Mouratidi 4, New York 25486	6980081351	2108452666
66	kostas_poupis_5650	$2b$10$jLuLCg.JEvIwR9Aba5wWceHW8D4IsLBHSu/JID69eeV.yRzyFRwLi	Kostas Poupis	st10434044@upnet.gr	student	Ag Kiriakis 11, Papaou 50501	698452154	222609123
67	hugh_jass_7653	$2b$10$0671bKAnHpv9SMiU51i7AO5IqDGAHDbkd1rtIV4xFbUXg0nAfJZ86	Hugh Jass	st10434045@upnet.gr	student	Wall Street 69, Jerusalem 478	696969420	69696969
68	xontro_pigouinaki_6215	$2b$10$pbBhiYn/UIrTRp0yJWTbMOXYJ1TKBd6puFk.sxHBKlmsAyFeedggm	Xontro Pigouinaki	st10434046@upnet.gr	student	Krasopotirou 69, Colarato 14121	4747859625	6913124205
69	aria_nikolaou_9839	$2b$10$PI8DvXw9DFxoe65xqwwwp.6wbPnj320o/kTGGe1id5Ph2vti3qwNe	Μaria Nikolaou	st10434047@upnet.gr	student	Achilleos 21, Athens 10437	6945533213	2109278907
70	eleni_fotiou_3037	$2b$10$ISasXLGJmzV4.QwWcMuGjOq21BfpMHavhUoOPhqThfUW9NoYkzdC2	Eleni Fotiou	st10434048@upnet.gr	student	Adrianou 65, Athens 10556	6978989000	2108745645
71	xara_fanouriou_1209	$2b$10$Z9P2GldEPAYS958vXuVgFegoj7K5qTPu0ebFkHZC.3E83tFv8Vuwq	Xara Fanouriou	st10434049@upnet.gr	student	Chaonias 54, Athens 10441	6945622222	2108724324
72	nikos_panagiotou_2050	$2b$10$6bi7y7PtlGkahYlQUSi.euqOOzieqb1iiWcE9EM1LnSfB2Fl5JCYq	Nikos Panagiotou	st10434050@upnet.gr	student	Chomatianou 32, Athens 10439	6941133333	2107655555
73	petros_daidalos_2181	$2b$10$oPrzs1aFcpB1AbVXre8v3.5vhd0vEb/c103JYgV2d/NfjmF7l9XLW	Petros Daidalos	st10434051@upnet.gr	student	Dafnidos 4, Athens 11364	6976644333	2108534566
74	giannis_ioannou_2728	$2b$10$kWIhrLUGxj49AMTCX0AlBeNSiZ9VLjBavpJsJ9v4NRQI2284PGpOi	Giannis Ioannou	st10434052@upnet.gr	student	Danais 9, Athens 11631	6976565655	2107644999
75	tsili_doghouse_5376	$2b$10$OLf7x/2FV17Nl3QmVb2HqO9ddUS13A1zz/9aEFAfl3JEXwmL8bmJy	Tsili Doghouse	st10434053@upnet.gr	student	novi lane 33, Patras 26478	6999999999	2610420420
76	marialena_antoniou_9568	$2b$10$mbzKzUNUy53zcKX9vcY0YOZ74p.x333o9i/hruZUIJ1UrLt.Wnkv.	Marialena Antoniou	st10434054@upnet.gr	student	Ermou 24, Athens 10563	693-5678901	210-5678901
77	ioannis_panagiotou_5154	$2b$10$XkEhRjgm5RsZmG8Oh0w2XutTb7kw.uynxH09vKDLZ4haGDvc5tHvW	Ioannis Panagiotou	st10434055@upnet.gr	student	Kyprou 42, Patra 26441	698-1234567	2610-123456
78	george_karamalis_9833	$2b$10$wC5pnQy3MB4d0n15fNA7ne9VNpV9gHksH38okvfg/UyUS7sC8pCO.	George Karamalis	st10434056@upnet.gr	student	Kolokotroni 10, Larissa 41222	697-4567890	2410-456789
79	kyriakos_papapetrou_5036	$2b$10$F6dWT5QzsxmFEAfmTDPLKOea8t64/SSuDPMTTBxb6AG0/.sglMm6C	Kyriakos Papapetrou	st10434057@upnet.gr	student	Zakunthou 36, Volos 10654	695-6789012	210-6789012
80	maria_kp_4422	$2b$10$ImJUZ6r/zCP9CI.lYCnMouajCb7ws74.pPz07xfo92r/1peaMn2Um	Maria Kp	st10434058@upnet.gr	student	pelopidas 52, patra 28746	6932323232	2610555555
81	nikos_papadopoulos_3674	$2b$10$InAHwKQppE1V3dgTcMDsa.lS6n/atj0ErUJtxQD.rCjTtdCRJE2cO	Nikos papadopoulos	st10434059@upnet.gr	student	anapafseos 34, patra 26503	69090909	2691045092
82	giannis_molotof_4791	$2b$10$114YCblPOxNVYEbHKkqDhu9LaV.V1gmjLvgTWTcnvZh9pPVFmkd.C	Giannis Molotof	st10434060@upnet.gr	student	Ermou 34, Patras 29438	6943126767	2610254390
83	sagdy_znuts_8141	$2b$10$xffWEU21v1CQb5/kdo0Q/eyBXenZYrh9X2X3iZfFrbfnlHb15ew5W	Sagdy Znuts	st10434061@upnet.gr	student	Grove 12, San Andreas 123456	123456789	123456789
84	mary_poppins_6727	$2b$10$CAIzK6E5YGbtcjFlnA6HDe8uo7qxNGBItr0xIMGYNfx5iS6jrmtr.	Mary Poppins	st10434062@upnet.gr	student	Niktolouloudias 123, Chalkida 23456	6980987654	2613456089
85	tinker_bell_7971	$2b$10$m.vnsxZuPCMYkUT2Zr4lOer3xIOoAozfRMdv8YvNgshWiJkb1ZcVe	Tinker Bell	st10434063@upnet.gr	student	Vatomourias 55, Pano Raxoula 2345	6987543345	2456034567
86	lilly_bloom_5767	$2b$10$670Wg8vED/DzmuIAzgKR0.jXT.xk2ya68HZSptjfAn7n9I5vLXyfO	Lilly Bloom	st10434064@upnet.gr	student	Patnanasis 45, Patra 26440	6987555433	2610435988
87	giorgos_masouras_4320	$2b$10$45Ll1wtmAffFeTZd1AsrR.zBlXasGxYtrq5gzrNdH7ARF5jtXRJ4i	GIORGOS MASOURAS	st10434065@upnet.gr	student	AGIOU IOANNNI RENTI 7, PEIRAIAS 47200	210583603	694837204
88	kendrick_nunn_6412	$2b$10$/AfX.MSun.bwLQV4ctPnuu68iTvvRJ8n1fgwx.wY9ZoHbg8oyrO6.	KENDRICK NUNN	st10434066@upnet.gr	student	OAKA 25, ATHENS 666	6906443321	6982736199
89	depeche_mode_4897	$2b$10$zrUIvTkClve.Y.8VYNIZsO3pS17rDyQtFRMdmmQrm3SoY5bylfppK	Depeche Mode	st10434067@upnet.gr	student	Enjoy The Silence 1990, London 1990	1234567770	1234567890
90	name_surname_3315	$2b$10$YiFb1WtnoPUT4idLfNSUF.W1q2wkBHRcrEBCyXTYZB45nbV.qySXu	name surname	st10434068@upnet.gr	student	your 69, mom 15584	2223	222
91	nikos_kosmopoulos_5698	$2b$10$jnhAB6GSbNMF9TyuFY2fX.uyen4se1p5sfcHHFsAOBpHLnf4yN9P.	Nikos Kosmopoulos	st10434069@upnet.gr	student	Araksou 12, Giotopoli 69420	6978722312	210 9241993
92	aris_poupis_9021	$2b$10$UAx5K5F3uPS0Cb5Z933Dg.rEh5huDMfabfGppg2nNTxKl3P0GbMOC	Aris Poupis	st10434070@upnet.gr	student	Mpofa 10, Kolonia 12345	6935358553	2105858858
93	gerry_banana_1869	$2b$10$UqJRy7OfsptzThVHSC21WOfAtjizl/4uwUyj3QfDjYBqmx8RcuM2.	gerry banana	st10434071@upnet.gr	student	lootlake 12, tilted 26500	2610987632	6947830287
94	grekotsi_parthenios_2935	$2b$10$Jna9uDt5UGjF3tDjVJIosOkKvnutf74QN1spr6Wr7gaWqsIDgml92	grekotsi parthenios	st10434072@upnet.gr	student	kokmotou 69, thessaloniki 20972	2610810763	6947910234
95	mochi_mon_6424	$2b$10$I4rxS29GnpIKOrgHVbjxue5NcEHpmEx/aCFqTj0PHTcsLYb.9bbza	Mochi Mon	st10434073@upnet.gr	student	Novi 55, Maxxwin 99999	6967486832	2610550406
96	nikolaos_serraios_4238	$2b$10$U9yb36TwMi0CALb/.jOnv.6pJfXDoIMXkth3eNpLCZ4O/CBNCOacm	Nikolaos Serraios	st10434074@upnet.gr	student	Papaflessa 12, Patra 26222	6975849305	2610456632
97	xaralampos_mparmaksizoglou_9998	$2b$10$8NSV0Cnzjv.ou/.VIZA3DecRS60KK5m.yq/xWn.h31GtdJVQ5bWmO	Xaralampos Mparmaksizoglou	st10434075@upnet.gr	student	Konstantinoupoleos 32, Athens 16524	6912345678	2109995555
98	kyriakos_pareena_3221	$2b$10$FIj6Slx7Cu3FC3c1mj0sjO2wg454e87upGT8M5kAPeVbg3zdLYAkG	kyriakos pareena	st10434076@upnet.gr	student	karaiskaki 23, patras 23444	6972861212	2214567809
99	tortelino_diagrafino_5923	$2b$10$xREYxXr1q.uGn1yEgiYF1u4nMswNC0pyNVhILtXdwtKswruMtTqvO	Tortelino Diagrafino	st10434077@upnet.gr	student	emp 69, empa 5432	6913121312	2101312000
100	maria_db_1307	$2b$10$HIIeDShETwqfL4bFXtVGguudhprj9ZKTahlj1.qbslBMTZKs0jxsS	Maria Db	st10434078@upnet.gr	student	Spiti sou 3, Patras 26441	6912345678	2610 123456
101	bombardriro_crocodilo_8080	$2b$10$sxhvTAEIUrBExhih/W4Y1ekXPXZMuIIjfdbib3v3riWKlAIToFt9K	Bombardriro Crocodilo	st10434079@upnet.gr	student	Pony Peponi 69, Athens 15344	6909876543	26810 12345
102	balerinna_cappucinna_1028	$2b$10$j/c.jKRhfCEi20hO33biGuT8jw/VdiDZ1Zj6EzO4TorZfXXyvVCj.	Balerinna Cappucinna	st10434080@upnet.gr	student	mimimimi 4, lalalala 23861	6983615882	2610729878
103	ntinos_konstantinos_9388	$2b$10$REX1NfeGt6lQFPXO2nvJLOeg9NAf44Z/sE31Ckp6cunrHtAyzpBHi	Ntinos Konstantinos	st10434081@upnet.gr	student	Valaoritou 1, patras 26225	6988888888	2610222222
104	xara_georgiou_1089	$2b$10$7iJV9YInZT6NOMmojIx.LOlEDuhF0V38zPq6vOKOhtj1hwZF5OorO	Xara Georgiou	st10434082@upnet.gr	student	Psilalonia 12, Patras 26225	6933333333	261000000
105	marios_konstantinou_9215	$2b$10$2ufSejCzb0yfePPn8iypHOKqJS1i.2M.gW91Ob9OUFl2bgzgto5Ta	Marios Konstantinou	st10434083@upnet.gr	student	Kanakari 1, Patras 26225	6944444444	2610777777
106	mina_minopoulou_8299	$2b$10$.XsxOSbWTAtXNh.FEh5NoO42Xx4mxbl0M/2YtekMmhxAsjJPyf3mq	Mina Minopoulou	st10434084@upnet.gr	student	patra 13, patras 12345	699999999	261044444
107	sakis_rouvas_2602	$2b$10$/cFWr9ZhlfMYfWCp5vdJa..0QmswLLVL82fO3QWXaBv8gPO3LLeUu	Sakis Rouvas	st10434085@upnet.gr	student	Raftel 45, Piece 123	66666666	66666666
108	andreas_komninos_9747	$2b$10$bxKL7UUU6.rCB8kW2fLT1u9JFAJxkNqm9ehKxC9CPOdSvUWEcT1wq	Andreas Komninos	akomninos@ceid.upatras.gr	professor	\N	6977998877	2610996915
109	vasilis_foukaras_8401	$2b$10$p0qID0dXIt50p/rkCU3K..oMC6/xsIwu44j7VGjdlqJKZA8LoayYG	Vasilis Foukaras	vasfou@ceid.upatras.gr	professor	\N	6988812345	2610885511
110	basilis_karras_3532	$2b$10$QNPe27Fe6vwPYnx6zclFB.rJxtZHYfCM5Dn9i0Y8IAqyFYNbOx0ym	Basilis Karras	karras@nterti.com	professor	\N	545	23
111	eleni_voyiatzaki_2450	$2b$10$bf.IkYv1UmjzLyvNF2r62.UX3HtUHXQyyr.WrL9heykdsCJMkLNlK	Eleni Voyiatzaki	eleni@ceid.gr	professor	\N	245	34
112	andrew_hozier_byrne_3246	$2b$10$XHaNwlXCmQy8xzCcPAaE.O61hVm9s2UtZ8ZD55jPFrADpRRdGHPRm	Andrew Hozier Byrne	hozier@ceid.upatras.gr	professor	\N	6917031990	2610170390
113	nikos_korobos_4494	$2b$10$AenNmvFFyD3RQj7cZQ6lOOvc2AuXdmDp5C5b2ene5QsLVBm8IurN6	Nikos Korobos	nikos.korobos12@gmail.com	professor	\N	6978530352	2610324365
114	kostas_karanikolos_4668	$2b$10$gIC4nM1lIIWIkWfDIrXGpeHlTUUBtZ4QEBmUZZ8z20UvpMASHSqEK	Kostas Karanikolos	kostkaranik@gmail.com	professor	\N	6934539920	2610324242
115	mpampis_sougias_7487	$2b$10$osvX.2QZHU5nD9xt1Yq0sev16OsTWKuCEeNUm8I4MKwauBnKD/OOC	Mpampis Sougias	mpampis123@gmail.com	professor	\N	6947845334	2610945934
116	daskalos_makaveli_5348	$2b$10$X7BDEq0HKZHcdoDRnIfUtuCUm/euSOM0FYkG5lxMggntcqiORPtWu	Daskalos Makaveli	makavelibet@gmail.com	professor	\N	6929349285	2310231023
117	maria_palami_1415	$2b$10$feeXRTto96DM22rBb.sFIe0YYXXfzX3R7H/85x1GoFr2kh2mvlR.O	Maria Palami	palam@upatras.gr	professor	\N	6988223322	1234567890
118	meni_talaiporimeni_7383	$2b$10$0nvvgK1HvfxvDdzXN7Dk0ufrNqQjem7/nGs/wLW/kSsc7Kyh02Uaa	Meni Talaiporimeni	meniT@upatras.gr	professor	\N	6999990999	2610333999
119	tzouli_alexandratou_8103	$2b$10$wXINdC2tFxiolkVqxeO8AejAZ5.hxDPx0naVen67mdNYpiH38ndgS	Tzouli Alexandratou	tzouli.ax@upatras.gr	professor	\N	6996116921	2264587412
120	karikhs_raftel_2675	$2b$10$Qc4QqR7Ru8jiuS7A/hhvveNT7KUPia865lwB9nIaP4QMpNe/bxxka	Karikhs Raftel	karikhs@yahoo.gr	professor	\N	6945258923	69
121	vlasis_restas_4251	$2b$10$AhnwxBa0Sa0ZJowqPYHUGucPTP202S7QQBo/tNuOZZOXglDZTe2/e	Vlasis Restas	toxrusoftiari@funerals.gr	professor	\N	69696964	78696910
122	fat_banker_2335	$2b$10$MZBqRo1bplzDVMWG3o6Pv.QO1axiOjQ.ijPiCuz98CqgoWyX5MsDG	Fat Banker	fatbanker@kapitalas.gr	professor	\N	6969784205	6942014121
123	hamze_mohamed_1465	$2b$10$0W00Gbf.4pEGizrgNxmHlOFHR6tjtwQSa0sO3Lu4WFzvKADODC/OO	Hamze Mohamed	info@hamzat.gr	professor	\N	1456983270	1245789513
124	stefania_nikolaou_5190	$2b$10$iVCSI19Kf68cec3F/JcG.u9n713yjW3tShiRzZ/XpVBOp1oOhgUA6	Stefania Nikolaou	snikolaou@upatras.gr	professor	\N	6942323452	2106723456
125	petros_danezis_7417	$2b$10$Gzo8Kj3pHyXF.xuH/AIbPeTF3mJNA6e8pGcBlOnKC0ccP1pPfoGia	Petros Danezis	pdanezis@upatras.gr	professor	\N	6971142424	2610908888
126	papadopoulos_eustathios_9513	$2b$10$5/32BIz6L/jIsNNntlSFtO9Kj80bXE5GoLsCu8mO.6dGvAaj/UR.i	Papadopoulos Eustathios	eustratiospap@gmail.com	professor	\N	690-1234567	210-1234567
127	konstantinou_maria_1909	$2b$10$WSUzmc0042irYDhZCO3TP.xPSALqjZGF97HYiGRZ0RC5N9dMN.0fO	Konstantinou Maria	mariakon@gmail.com	professor	\N	694-7654321	2310-7654321
128	jim_nikolaou_2109	$2b$10$3Hjkv3nyao7lP3JMZ/3qAuPblc0XMSKZheqLQNxPbUuySJYRfwF4i	Jim Nikolaou	jimnik@gmail.com	professor	\N	697-9876543	2610-9876543
129	sophia_michailidi_8909	$2b$10$M6vCMZKsP2iGtUxI8it2ReXh0TL7e6/sXXsvMIrONcVw/DF7gkz2W	Sophia Michailidi	sophiamich@gmail.com	professor	\N	698-5432109	2310-5432109
130	michael_papadreou_8877	$2b$10$x5RhzMzWQItmtCWyxhuAOeEPM3sXSJ93zPVgGR1FaNy.nFKQdauF2	Michael Papadreou	michaelpap@gmail.com	professor	\N	697-4455667	2610-4455667
131	elon_musk_7947	$2b$10$hUcWnHg9O.FTVB48hmGIOefRPmzOWT6.Ra3.uJE8bVq5Wv2txsvJi	Elon Musk	elonmusk@gmail.com	professor	\N	Null	1-888-518-3752
132	kostas_kalantas_7459	$2b$10$0rWibZdhg8An.kliBRz2ce5TlCHdmcmAd6Hvn./m5qlKFEIozpPrG	Kostas Kalantas	abcdef@example.com	professor	\N	6912121212	2610121212
133	giorgis_fousekis_4550	$2b$10$MZvT0y0klBKObyqc/xXKSOz.ASwjWINbEAivHhNvsABt9OSyukvca	Giorgis Fousekis	abcdefg@example.com	professor	\N	mob	land
134	nikos_koukos_7855	$2b$10$y1OTHfGYeSeUzLQ/VbP4VeE/DWyzXwBTAxmFafmD3qznrYqq2Bj0e	Nikos Koukos	exxample@example.com	professor	\N	mo	la
135	patrick_xrusopsaros_8751	$2b$10$rZRRcaXJs4g09EyajUQdCu8EE3eD7WO86Ybroqsi8q6ehIu0cwd4W	patrick xrusopsaros	patric@xrusopsaros.com	professor	\N	6952852742	2610567917
136	paraskevas_koutsikos_7324	$2b$10$/NlwxEJZknsNLr3/tr039eh4kSanRODNtPGsT6d8HBcFF26c6S3PC	Paraskevas koutsikos	paraskevas@kobres.ath	professor	\N	6969696969	2298042035
137	ezio_auditore_da_firenze_4484	$2b$10$xrvQ4v/Qc/o9FWciHZ5MrurGXYm8GZ/UflMzVfo2scRuFslbrGfRO	Ezio Auditore da Firenze	masterassassin@upatras.ceid.gr	professor	\N	null	null
138	sotiris_panaikas_7447	$2b$10$Y3H3EfSqF0r6DKas8B/YfuNJV6d5YHY1zUDHj1REje27Fv0fKAtu6	Sotiris Panaikas	spana@hotmail.com	professor	\N	2310521010	1235654899
139	anitta_wynn_2207	$2b$10$sVosSfvBg8XvXFOP5J0ioOOsVI5tpbL7hzc6pQ7kBAg7S3TcEq/8K	Anitta Wynn	anittamaxwynn@cashmoney.com	professor	\N	698888884	2610486396
140	jose_luis_mendilibar_9830	$2b$10$yEgD8qencjRQ6fzUuA8vGe//3Lak0HFK90NlHGzg/agqCBzkdvw2G	Jose Luis Mendilibar	goatmanager@thrylos.gr	professor	\N	6922222222	2105555555
141	liam_payne_3293	$2b$10$eaeQYuCuGPWhsuRVh7lBYeQgeViW4CDqf9Et.lriZNXQgBZZ8Up4y	Liam Payne	liampayne@ceid.upatras.gr	professor	\N	6980847234	2462311345
142	zayn_malik_4009	$2b$10$XL8uZyGVkjUByGcpdhSqPu/k09CBRagsq/SUBXNDPgjyLs2Mq4.Lu	Zayn Malik	zaynmalik@gmail.com	professor	\N	6971006355	2310221234
143	nikos_papas_4007	$2b$10$N8/Ix1tM/KvMMcwDu0YHyeJA/hoQbTqXTF9XQ5yPtEVSYNabHsstW	Nikos Papas	papas2@yahoo.gr	professor	\N	69854512	spiti
144	oikoumenikos_prasinos_9055	$2b$10$Juku0UPGH2Z/IkJvb48aLusldwUM6u6ifuHLs9uGeyh1cSXLO0z1i	Oikoumenikos Prasinos	mavros@bbs.af	professor	\N	69 6 9 69	987546123
145	severus_snape_8642	$2b$10$IajfjW7FhF59uzA4LG/mL.4CReu4hhtlDl8LmIu0PiY0icKS50kam	Severus Snape	ihatepotter@hocusmail.com	professor	\N	6926626226	26210 26441
146	tung_tung_sahur_4177	$2b$10$nCfiRBIeoH/JuT3c8naCH.sy2vO96zN.yceYRsidgSaH0VQbjrCvW	Tung Tung Sahur	tungtungtung@itbr.com	professor	\N	69434619363	210 1425735
147	maria_papadopoulou_4863	$2b$10$XJwqm5l3416AuAkp7MlV.emC1vqoRO6aPfjRK8PUDHlq5gA0xvBZK	Maria Papadopoulou	up1084561@ac.upatras.gr	professor	\N	6912345678	2610123456
148	nikos_georgiou_4863	$2b$10$EgPMmR1aVHFl.XBStawb7u7RK0nMcvRoMI2yS5TFtyHit25OelFgO	Nikos Georgiou	up1234567@ac.upatras.gr	professor	\N	6911111111	2610111111
149	mari_bro_4360	$2b$10$DO8DSxshv569b7PR0xQ9TOzoTF13RPbmUexh1Umy7d5hNp2hxIfj.	MARI BRO	mari-bro@beast.com	professor	\N	666	666
150	a_hrefhttpswwwyoutubecomga_goat_2878	$2b$10$QaVcefA4LTnZi.YUbH1fc.GlQIWgEWP5kuJ5.H67aNbA8qP0dcOfa	<a href="https://www.youtube.com">G</a> Goat	goat@messi.cr	professor	\N	666	666
151	brain_rot_4205	$2b$10$/A2FOn35jEI5MskEBcAxKubmuIF9.P9SsTLXz3tW7JEqcVHWNTtNe	Brain Rot	capucapu@ccino.assassino	professor	\N	6	9
\.


--
-- TOC entry 3524 (class 0 OID 0)
-- Dependencies: 236
-- Name: announcements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.announcements_id_seq', 1, true);


--
-- TOC entry 3525 (class 0 OID 0)
-- Dependencies: 228
-- Name: committee_invitations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.committee_invitations_id_seq', 20, true);


--
-- TOC entry 3526 (class 0 OID 0)
-- Dependencies: 230
-- Name: professor_notes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.professor_notes_id_seq', 16, true);


--
-- TOC entry 3527 (class 0 OID 0)
-- Dependencies: 219
-- Name: professors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.professors_id_seq', 60, true);


--
-- TOC entry 3528 (class 0 OID 0)
-- Dependencies: 226
-- Name: status_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.status_history_id_seq', 96, true);


--
-- TOC entry 3529 (class 0 OID 0)
-- Dependencies: 234
-- Name: student_submissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.student_submissions_id_seq', 11, true);


--
-- TOC entry 3530 (class 0 OID 0)
-- Dependencies: 223
-- Name: students_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.students_id_seq', 96, true);


--
-- TOC entry 3531 (class 0 OID 0)
-- Dependencies: 221
-- Name: theses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.theses_id_seq', 24, true);


--
-- TOC entry 3532 (class 0 OID 0)
-- Dependencies: 232
-- Name: thesis_cancellations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.thesis_cancellations_id_seq', 6, true);


--
-- TOC entry 3533 (class 0 OID 0)
-- Dependencies: 217
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.users_id_seq', 151, true);


--
-- TOC entry 3323 (class 2606 OID 16590)
-- Name: announcements announcements_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.announcements
    ADD CONSTRAINT announcements_pkey PRIMARY KEY (id);


--
-- TOC entry 3310 (class 2606 OID 16507)
-- Name: committee_invitations committee_invitations_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.committee_invitations
    ADD CONSTRAINT committee_invitations_pkey PRIMARY KEY (id);


--
-- TOC entry 3315 (class 2606 OID 16533)
-- Name: professor_notes professor_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.professor_notes
    ADD CONSTRAINT professor_notes_pkey PRIMARY KEY (id);


--
-- TOC entry 3292 (class 2606 OID 16416)
-- Name: professors professors_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.professors
    ADD CONSTRAINT professors_pkey PRIMARY KEY (id);


--
-- TOC entry 3306 (class 2606 OID 16486)
-- Name: status_history status_history_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.status_history
    ADD CONSTRAINT status_history_pkey PRIMARY KEY (id);


--
-- TOC entry 3319 (class 2606 OID 16569)
-- Name: student_submissions student_submissions_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.student_submissions
    ADD CONSTRAINT student_submissions_pkey PRIMARY KEY (id);


--
-- TOC entry 3321 (class 2606 OID 16571)
-- Name: student_submissions student_submissions_thesis_id_key; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.student_submissions
    ADD CONSTRAINT student_submissions_thesis_id_key UNIQUE (thesis_id);


--
-- TOC entry 3298 (class 2606 OID 16445)
-- Name: students students_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_pkey PRIMARY KEY (id);


--
-- TOC entry 3300 (class 2606 OID 16597)
-- Name: students students_student_number_key; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_student_number_key UNIQUE (student_number);


--
-- TOC entry 3294 (class 2606 OID 16433)
-- Name: theses theses_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.theses
    ADD CONSTRAINT theses_pkey PRIMARY KEY (id);


--
-- TOC entry 3317 (class 2606 OID 16553)
-- Name: thesis_cancellations thesis_cancellations_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.thesis_cancellations
    ADD CONSTRAINT thesis_cancellations_pkey PRIMARY KEY (id);


--
-- TOC entry 3303 (class 2606 OID 16461)
-- Name: thesis_professor_relationship thesis_professor_relationship_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.thesis_professor_relationship
    ADD CONSTRAINT thesis_professor_relationship_pkey PRIMARY KEY (thesis_id, professor_id);


--
-- TOC entry 3296 (class 2606 OID 16478)
-- Name: theses unique_student_id; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.theses
    ADD CONSTRAINT unique_student_id UNIQUE (student_id);


--
-- TOC entry 3313 (class 2606 OID 16509)
-- Name: committee_invitations unique_thesis_professor; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.committee_invitations
    ADD CONSTRAINT unique_thesis_professor UNIQUE (thesis_id, professor_id);


--
-- TOC entry 3308 (class 2606 OID 16488)
-- Name: status_history unique_thesis_status; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.status_history
    ADD CONSTRAINT unique_thesis_status UNIQUE (thesis_id, updated_at);


--
-- TOC entry 3286 (class 2606 OID 16409)
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- TOC entry 3288 (class 2606 OID 16405)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 3290 (class 2606 OID 16407)
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- TOC entry 3301 (class 1259 OID 16472)
-- Name: idx_professor_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_professor_id ON public.thesis_professor_relationship USING btree (professor_id);


--
-- TOC entry 3311 (class 1259 OID 16522)
-- Name: idx_professor_id_committee_invitations; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_professor_id_committee_invitations ON public.committee_invitations USING btree (professor_id);


--
-- TOC entry 3304 (class 1259 OID 16498)
-- Name: idx_status_history_thesis_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_status_history_thesis_id ON public.status_history USING btree (thesis_id);


--
-- TOC entry 3342 (class 2620 OID 16521)
-- Name: committee_invitations after_invitation_accepted; Type: TRIGGER; Schema: public; Owner: user
--

CREATE TRIGGER after_invitation_accepted AFTER UPDATE ON public.committee_invitations FOR EACH ROW WHEN (((new.status)::text = 'accepted'::text)) EXECUTE FUNCTION public.insert_committee_member();


--
-- TOC entry 3338 (class 2620 OID 16476)
-- Name: theses insert_supervisor_after_thesis_creation; Type: TRIGGER; Schema: public; Owner: user
--

CREATE TRIGGER insert_supervisor_after_thesis_creation AFTER INSERT ON public.theses FOR EACH ROW EXECUTE FUNCTION public.insert_supervisor_into_relationship();


--
-- TOC entry 3341 (class 2620 OID 16560)
-- Name: thesis_professor_relationship trigger_committee_complete; Type: TRIGGER; Schema: public; Owner: user
--

CREATE TRIGGER trigger_committee_complete AFTER INSERT ON public.thesis_professor_relationship FOR EACH ROW WHEN (((new.role)::text = 'committee member'::text)) EXECUTE FUNCTION public.handle_committee_complete();


--
-- TOC entry 3339 (class 2620 OID 16495)
-- Name: theses trigger_insert_initial_status; Type: TRIGGER; Schema: public; Owner: user
--

CREATE TRIGGER trigger_insert_initial_status AFTER INSERT ON public.theses FOR EACH ROW EXECUTE FUNCTION public.insert_initial_status();


--
-- TOC entry 3340 (class 2620 OID 16497)
-- Name: theses trigger_insert_status_change; Type: TRIGGER; Schema: public; Owner: user
--

CREATE TRIGGER trigger_insert_status_change AFTER UPDATE OF status ON public.theses FOR EACH ROW EXECUTE FUNCTION public.insert_status_change();


--
-- TOC entry 3337 (class 2606 OID 16591)
-- Name: announcements announcements_thesis_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.announcements
    ADD CONSTRAINT announcements_thesis_id_fkey FOREIGN KEY (thesis_id) REFERENCES public.theses(id) ON DELETE CASCADE;


--
-- TOC entry 3328 (class 2606 OID 16467)
-- Name: thesis_professor_relationship fk_professor; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.thesis_professor_relationship
    ADD CONSTRAINT fk_professor FOREIGN KEY (professor_id) REFERENCES public.professors(id) ON DELETE CASCADE;


--
-- TOC entry 3331 (class 2606 OID 16515)
-- Name: committee_invitations fk_professor; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.committee_invitations
    ADD CONSTRAINT fk_professor FOREIGN KEY (professor_id) REFERENCES public.professors(id) ON DELETE CASCADE;


--
-- TOC entry 3333 (class 2606 OID 16539)
-- Name: professor_notes fk_professor; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.professor_notes
    ADD CONSTRAINT fk_professor FOREIGN KEY (professor_id) REFERENCES public.professors(id) ON DELETE CASCADE;


--
-- TOC entry 3329 (class 2606 OID 16462)
-- Name: thesis_professor_relationship fk_thesis; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.thesis_professor_relationship
    ADD CONSTRAINT fk_thesis FOREIGN KEY (thesis_id) REFERENCES public.theses(id) ON DELETE CASCADE;


--
-- TOC entry 3332 (class 2606 OID 16510)
-- Name: committee_invitations fk_thesis; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.committee_invitations
    ADD CONSTRAINT fk_thesis FOREIGN KEY (thesis_id) REFERENCES public.theses(id) ON DELETE CASCADE;


--
-- TOC entry 3334 (class 2606 OID 16534)
-- Name: professor_notes fk_thesis; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.professor_notes
    ADD CONSTRAINT fk_thesis FOREIGN KEY (thesis_id) REFERENCES public.theses(id) ON DELETE CASCADE;


--
-- TOC entry 3324 (class 2606 OID 16417)
-- Name: professors professors_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.professors
    ADD CONSTRAINT professors_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3330 (class 2606 OID 16489)
-- Name: status_history status_history_thesis_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.status_history
    ADD CONSTRAINT status_history_thesis_id_fkey FOREIGN KEY (thesis_id) REFERENCES public.theses(id) ON DELETE CASCADE;


--
-- TOC entry 3336 (class 2606 OID 16572)
-- Name: student_submissions student_submissions_thesis_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.student_submissions
    ADD CONSTRAINT student_submissions_thesis_id_fkey FOREIGN KEY (thesis_id) REFERENCES public.theses(id) ON DELETE CASCADE;


--
-- TOC entry 3327 (class 2606 OID 16446)
-- Name: students students_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3325 (class 2606 OID 16434)
-- Name: theses theses_professor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.theses
    ADD CONSTRAINT theses_professor_id_fkey FOREIGN KEY (professor_id) REFERENCES public.professors(id) ON DELETE SET NULL;


--
-- TOC entry 3326 (class 2606 OID 16451)
-- Name: theses theses_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.theses
    ADD CONSTRAINT theses_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE SET NULL;


--
-- TOC entry 3335 (class 2606 OID 16554)
-- Name: thesis_cancellations thesis_cancellations_thesis_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.thesis_cancellations
    ADD CONSTRAINT thesis_cancellations_thesis_id_fkey FOREIGN KEY (thesis_id) REFERENCES public.theses(id);


-- Completed on 2025-05-01 16:08:20

--
-- PostgreSQL database dump complete
--

