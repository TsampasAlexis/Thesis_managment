////////////////////
// GENERIC STUFF //
window.addEventListener('load', checkLoginAndRedirect);

// Get the hamburger button and sidebar elements
const hamburger = document.getElementById('hamburger');
const sidebar = document.getElementById('sidebar');

// Add click event to toggle the sidebar visibility
hamburger.addEventListener('click', function() {
    sidebar.classList.toggle('open');
});

// Check login status on the dashboard page
function checkLoginAndRedirect() {
    if (!isLoggedIn()) {
        window.location.href = 'index.html'; // Redirect to login page if not logged in
    } else {
        // User is logged in, now show the role-based content
        const username = localStorage.getItem('username');
        document.querySelector('#profile span').innerText = `Welcome, ${username}`;
        displayDashboardContent();
    }
}

// function to check if the user is logged in by looking for the token in localStorage
function isLoggedIn() {
    const token = localStorage.getItem('token');
    return token ? true : false;
}

// Function to display content based on user role
async function displayDashboardContent() {
    const role = localStorage.getItem('role');

    // Show the relevant section based on role
    if (role === 'professor') {
        document.getElementById('thesesToAssignBtn').click(); // reveal first option by default
      return;
    } else {
        window.location.href = 'index.html'
    }
}
function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('role');
    localStorage.removeItem('roleId');

    fetch('http://localhost:5000/logout', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        }
    })
    .then(response => response.json())
    .then(data => {
        // Handle the response, like updating the UI or redirecting
        // console.log(data.message);
        window.location.href = 'index.html';  // Redirect to login page
    })
    .catch(error => {
        console.error('Error logging out:', error);
    });
}

// Function to hide all sections in the professor dashboard
function hideAllSections() {
    document.getElementById('thesesToAssignSection').style.display = 'none';
    document.getElementById('assignThesisToStudentSection').style.display = 'none';
    document.getElementById('cancelThesisAssignmentSection').style.display = 'none';
    document.getElementById('viewMyThesesSection').style.display = 'none';
    document.getElementById('viewCommitteeInvitationsSection').style.display = 'none';
    document.getElementById('statsSection').style.display = 'none';
}

async function safeAlertConfirm(question) {
    try {
        // Attempt to use SweetAlert2 for confirmation
        const result = await Swal.fire({
            title: question,
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'Yes',
            cancelButtonText: 'No',
            confirmButtonColor: '#007bff',  // Set "Yes" button color directly
            cancelButtonColor: '#f44336',  // Set "No" button color directly
        });

        // Return true if the user confirms, false if they cancel
        return result.isConfirmed;
    } catch (error) {
        // If SweetAlert2 fails, use the normal JavaScript confirm
        return confirm(question);
    }
}

async function safeAlert(alertMessage) {
    try {
        // Using SweetAlert to display a simple alert
        await Swal.fire({
            title: 'Alert',
            text: alertMessage,
            icon: 'info',
            confirmButtonText: 'OK',
            confirmButtonColor: '#007bff',  // Set the "OK" button color to blue
        });
    } catch (error) {
        // If SweetAlert fails, fall back to using a normal JavaScript alert
        alert(alertMessage);
    }
}

async function safeAlertSuccess(successMessage) {
    try {
        // Using SweetAlert for success alert
        await Swal.fire({
            title: 'Success!',
            text: successMessage,
            icon: 'success',
            confirmButtonText: 'OK',
            confirmButtonColor: '#007bff', // Custom blue button color
        });
    } catch (error) {
        // Fallback to the standard alert if SweetAlert fails
        alert(successMessage);
    }
}

async function safeAlertError(errorMessage) {
    try {
        // Using SweetAlert for error alert
        await Swal.fire({
            title: 'Error!',
            text: errorMessage,
            icon: 'error',
            confirmButtonText: 'OK',
            confirmButtonColor: '#007bff', // Custom blue button color
        });
    } catch (error) {
        // Fallback to the standard alert if SweetAlert fails
        alert(errorMessage);
    }
}

async function safeAlertPrompt(promptMessage, inputPlaceholder = '') {
    try {
        // Using SweetAlert for prompt
        const { value } = await Swal.fire({
            title: 'Please provide input',
            text: promptMessage,
            input: 'text',
            inputPlaceholder: inputPlaceholder,
            showCancelButton: true,
            confirmButtonText: 'Submit',
            cancelButtonText: 'Cancel',
            confirmButtonColor: '#007bff', // Custom blue button color
        });

        // If a value is entered, return it; otherwise, return null
        return value || null;
    } catch (error) {
        // Fallback to the standard prompt if SweetAlert fails
        const result = prompt(promptMessage, inputPlaceholder);
        return result ? result : null;
    }
}

///////////////////////////////////////
//// THESIS TO BE ASSIGNED OPTION ////

document.getElementById('thesesToAssignBtn').addEventListener('click', async function() {
    // Hide all sections initially
    hideAllSections();
    selectedThesis = null;

    sidebar.classList.remove('open'); //for small screens

    // Show the relevant section when the button is clicked
    document.getElementById('thesesToAssignSection').style.display = 'flex';

    // Fetch and render theses when the professor section is shown
    const theses = await fetchTheses();
    renderThesesList(theses);  // Render the list of theses
});

// Event listener for "New Thesis" button
document.getElementById('newThesisBtn').addEventListener('click', () => {
    showCreateForm(); // Show an empty form for creating a new thesis
  });
  
document.getElementById('editBtn').addEventListener('click', () => {
    enableEditMode(); 
});

// Handle the delete button click event
document.getElementById('deletePdfBtn').addEventListener('click', function(event) {
    event.preventDefault();

    // When the delete button is clicked, update the hidden input to reflect deletion
    document.getElementById('deletePdfStatus').value = 'true';
    document.getElementById('deletePdfBtn').disabled = 'true';
    document.getElementById('createThesisStatus').innerText = 'Pdf will be deleted';
});

document.getElementById('createThesisForm').addEventListener('submit', async (event) => {
    event.preventDefault(); // Prevent the form from reloading the page

    const thesisId = document.getElementById('thesisId').value;

    if (thesisId) {
        // If thesisId exists, call the edit function
        await editThesis(thesisId);
    } else {
        // Otherwise, call the create function
        await createThesis();
    }
});
  
  
  
// Function to fetch theses for the logged-in professor
async function fetchTheses() {
    const token = localStorage.getItem('token');

    if (!token) {
    console.log('You must be logged in to view the theses.');
    return;
    }

    try {
    const response = await fetch('http://localhost:5000/professor/theses', {
        method: 'GET',
        headers: {
        'Authorization': `Bearer ${token}`,
        },
    });
    if (response.ok) {
        const result = await response.json();
        return result;
    } else {
        const error = await response.json();
        console.error('Error fetching theses:', error);
        return [];
    }
    } catch (error) {
    console.error('Error fetching theses:', error);
    return [];
    }
};

// Function to render the list of theses
function renderThesesList(theses) {
    const thesisListContainer = document.getElementById('thesisListContainer'); // Make sure this element exists in your HTML

    // Clear any existing content
    thesisListContainer.innerHTML = '';

    if (theses.message === "No theses to be assigned.") {
        thesisListContainer.innerHTML = '<p>No theses to display.</p>';
        return;
    }

    // Create a <ul> element to hold the list
    const ul = document.createElement('ul');

    // Loop through each thesis and create a <li> for it
    theses.forEach(thesis => {
        const li = document.createElement('li');
        
        // Create a clickable item that displays the title
        const titleElement = document.createElement('span');
        titleElement.textContent = `${thesis.title}`;
        
        // Make the entire li clickable (not just the title)
        li.style.cursor = 'pointer'; // Ensures that the entire li is clickable
        
        // Add a click event to show additional details
        li.addEventListener('click', () => {
            const previousSelectedItem = document.querySelector('.selected-thesis');
            if (previousSelectedItem) {
                previousSelectedItem.classList.remove('selected-thesis');
            }

            // Select the current item
            li.classList.add('selected-thesis');
            selectedThesis = thesis;

            showThesisDetails(thesis);
        });

        // Append the title to the list item
        li.appendChild(titleElement);

        // Append each <li> to the <ul>
        ul.appendChild(li);
    });

    // Append the <ul> to the thesis list container
    thesisListContainer.appendChild(ul);
}

// Function to show additional details of a thesis
function showThesisDetails(thesis) {
    const form = document.getElementById('createThesisForm'); 
    const thesisTitleField = document.getElementById('thesisTitle');
    const thesisSynopsisField = document.getElementById('thesisSynopsis');
    const pdfFileField = document.getElementById('pdfFile');
    const submitButton = form.querySelector('button[type="submit"]'); 
    const oldPdfPath = document.getElementById('oldPdfpath');
    const deletePdfBtn = document.getElementById('deletePdfBtn');
    const editButton = document.getElementById('editBtn'); 
    const createThesisStatus = document.getElementById('createThesisStatus');

    // Show the form
    form.style.display = 'block';

    // Clear any previous status or form data
    createThesisStatus.textContent = '';
    thesisTitleField.value = '';
    thesisSynopsisField.value = '';
    pdfFileField.value = '';
    document.getElementById('deletePdfStatus').value = 'false';
    oldPdfPath.value = '';

    // Set the thesis ID in the hidden field
    const thesisIdField = document.getElementById('thesisId');
    thesisIdField.value = thesis.id;

    // Populate the form with thesis data
    thesisTitleField.value = thesis.title;
    thesisSynopsisField.value = thesis.synopsis;

    // Disable the form fields
    thesisTitleField.disabled = true;
    thesisSynopsisField.disabled = true;
    pdfFileField.disabled = true;
    deletePdfBtn.disabled = true;

    // Hide the submit button
    submitButton.style.display = 'none';
    submitButton.disabled = true;

    // Show the edit button
    editButton.style.display = 'inline-block';

    // Create and display the download link for the PDF
    const pdfLinkContainer = document.createElement('div');
    const pdfLink = document.createElement('a');

    if (thesis.pdf_file) {
        // Provide a link to the PDF if it exists
        pdfLink.href = `http://localhost:5000${thesis.pdf_file}`;
        pdfLink.textContent = 'Download PDF';
        pdfLink.target = '_blank';  // Open in a new tab

        oldPdfPath.value = thesis.pdf_file;
    } else {
        pdfLink.textContent = 'No PDF available';
        pdfLink.href = '#';
        deletePdfBtn.style.display = 'none';
        oldPdfPath.value = '';
    }

    pdfLinkContainer.appendChild(pdfLink);

    // Display the download link
    if (!document.getElementById('pdfLinkContainer')) {
        // Only append the container if it doesn't exist already
        pdfLinkContainer.id = 'pdfLinkContainer';
        form.appendChild(pdfLinkContainer);
    } else {
        // Otherwise, just update the link
        document.getElementById('pdfLinkContainer').innerHTML = '';
        document.getElementById('pdfLinkContainer').appendChild(pdfLink);
    }

    // Optional: Update status if needed
    createThesisStatus.textContent = 'Viewing Thesis Details (fields are disabled)';
}

// Function to enable edit mode for the thesis
function enableEditMode() {
    const form = document.getElementById('createThesisForm'); // Get the form
    const thesisTitleField = document.getElementById('thesisTitle');
    const thesisSynopsisField = document.getElementById('thesisSynopsis');
    const pdfFileField = document.getElementById('pdfFile');
    const deletePdfBtn = document.getElementById('deletePdfBtn');
    const submitButton = form.querySelector('button[type="submit"]'); // Get the submit button
    const editButton = document.getElementById('editBtn'); // Get the edit button container

    // Hide the "Edit" button
    editButton.style.display = 'none';

    // Enable the form fields for editing
    thesisTitleField.disabled = false;
    thesisSynopsisField.disabled = false;
    pdfFileField.disabled = false;
    deletePdfBtn.disabled = false;

    // Clear and hide the PDF download link if it exists
    if (pdfLinkContainer) {
        
        if (pdfLinkContainer.textContent === 'Download PDF'){
            deletePdfBtn.style.display = 'inline';

        }
        pdfLinkContainer.innerHTML = ''; // Remove the link
    }

    // Show the submit button and enable it
    submitButton.style.display = 'inline-block';
    submitButton.disabled = false;

    document.getElementById('createThesisStatus').innerText = 'Editing thesis';
}

// Function to show the form for creating a new thesis
function showCreateForm() {
    document.getElementById('editBtn').style.display = 'none';
    const form = document.getElementById('createThesisForm');
    const thesisTitleField = document.getElementById('thesisTitle');
    const thesisSynopsisField = document.getElementById('thesisSynopsis');
    const pdfFileField = document.getElementById('pdfFile');
    const submitButton = form.querySelector('button[type="submit"]'); // Get the submit button
    const createThesisStatus = document.getElementById('createThesisStatus');
    const pdfLinkContainer = document.getElementById('pdfLinkContainer');

    // Show the form
    form.style.display = 'block';

    // Clear any previous status or form data

    // Reset thesisId (important for new thesis)
    const thesisIdField = document.getElementById('thesisId');
    thesisIdField.value = '';  // Ensure the ID is empty for new thesis

    createThesisStatus.textContent = '';
    thesisTitleField.value = '';
    thesisSynopsisField.value = '';
    pdfFileField.value = '';

    // Clear and hide the PDF download link if it exists
    if (pdfLinkContainer) {
        pdfLinkContainer.innerHTML = ''; // Remove the link
    }

    // Enable the form fields for input (new thesis)
    thesisTitleField.disabled = false;
    thesisSynopsisField.disabled = false;
    pdfFileField.disabled = false;

    // Enable the submit button
    submitButton.style.display = 'inline-block';
    submitButton.disabled = false;

    document.getElementById('createThesisStatus').innerText = 'Adding new thesis';
}

// Function to handle creating a new thesis
async function createThesis() {
    const title = document.getElementById('thesisTitle').value;
    const synopsis = document.getElementById('thesisSynopsis').value;
    const pdfFile = document.getElementById('pdfFile').files[0]; // Get the selected file

    // Get the professor_id from localStorage
    const professorId = localStorage.getItem('roleId');

    if (!professorId) {
        document.getElementById('createThesisStatus').innerText = 'You must be logged in as a professor to submit a thesis.';
        return;
    }

    if (!title || !synopsis) {
        document.getElementById('createThesisStatus').innerText = 'Both title and synopsis are required.';
        return;
    }

    // Create FormData object to send the data
    const formData = new FormData();
    formData.append('title', title);
    formData.append('synopsis', synopsis);
    formData.append('professor_id', professorId); // Append professor_id to FormData
    if (pdfFile) {
        formData.append('pdf_file', pdfFile);
    }

    // Get the token from localStorage
    const token = localStorage.getItem('token');

    if (!token) {
        document.getElementById('createThesisStatus').innerText = 'You must be logged in to submit a thesis.';
        return;
    }

    try {
        const response = await fetch('http://localhost:5000/professor/theses', {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${token}`,
        },
        body: formData,
        });

            if (response.ok) {
            const result = await response.json();

            // hide form
            const form = document.getElementById('createThesisForm');
            form.style.display = 'none';

            document.getElementById('createThesisStatus').innerText = 'Thesis created successfully!';

            // Refresh the list of theses after successful thesis creation
            const theses = await fetchTheses();  // Fetch updated list of theses
            renderThesesList(theses);  // Re-render the list of theses
        } else {
        const error = await response.json();
        document.getElementById('createThesisStatus').innerText = 'Error: ' + error.message;
        }
    } catch (error) {
        console.error('Error:', error);
        document.getElementById('createThesisStatus').innerText = 'An error occurred while submitting the thesis.';
    }
}

// Function to handle editing an existing thesis
async function editThesis(thesisId) {
    const title = document.getElementById('thesisTitle').value;
    const synopsis = document.getElementById('thesisSynopsis').value;
    const pdfFile = document.getElementById('pdfFile').files[0]; // Get the selected file
    const oldPdfPathVal = document.getElementById('oldPdfpath').value; // Get the current PDF path (if any)
    
    // Null if there was no pdf
    let oldPdfPath = oldPdfPathVal;
    if (oldPdfPath === '') {
        oldPdfPath = null
    } else if (oldPdfPath === 'null') {
        oldPdfPath = null
    }
    // Get the value of the deletePdfStatus hidden input
    const deletePdfStatus = document.getElementById('deletePdfStatus').value;

    // Set pdfChanged to true if the user wants to delete the PDF or if a new PDF is selected
    const pdfChanged = (deletePdfStatus === 'true') || (pdfFile ? true : false);

    // Get the token from localStorage
    const token = localStorage.getItem('token');

    if (!token) {
        document.getElementById('createThesisStatus').innerText = 'You must be logged in to edit a thesis.';
        return;
    }

    if (!title || !synopsis) {
        document.getElementById('createThesisStatus').innerText = 'Both title and synopsis are required.';
        return;
    }

    // Create FormData object to send the data
    const formData = new FormData();
    formData.append('title', title);
    formData.append('synopsis', synopsis);
    formData.append('oldPdfPath', oldPdfPath); // Include the old PDF path (or null)
    formData.append('pdfChanged', pdfChanged); // Set pdfChanged flag

    if (pdfFile) {
        formData.append('pdf_file', pdfFile); // Attach the new PDF file if any
    }

    try {
        const response = await fetch(`http://localhost:5000/professor/theses/${thesisId}`, {
        method: 'PUT',
        headers: {
            'Authorization': `Bearer ${token}`,
        },
        body: formData,
        });

        if (response.ok) {
        const result = await response.json();

        // hide form
        const form = document.getElementById('createThesisForm');
        form.style.display = 'none';
        
        document.getElementById('createThesisStatus').innerText = 'Thesis edited successfully!';

        // Refresh the list of theses after successful thesis edit
        const theses = await fetchTheses();  // Fetch updated list of theses
        renderThesesList(theses);  // Re-render the list of theses
        } else {
        const error = await response.json();
        document.getElementById('createThesisStatus').innerText = 'Error: ' + error.message;
        }
    } catch (error) {
        console.error('Error:', error);
        document.getElementById('createThesisStatus').innerText = 'An error occurred while editing the thesis.';
    }
}

//////////////////////////////////////////
//// ASSIGN THESIS TO STUDENT OPTION ////

// Variables to hold selected thesis and student
let selectedThesis = null;
let selectedStudent = null;

document.getElementById('assignThesisToStudentSidebar').addEventListener('click', async function() {
    // Hide all sections initially
    hideAllSections();
    selectedThesis = null;
    selectedStudent= null;

    sidebar.classList.remove('open'); //for small screens

    const previouslySelected = document.querySelector('.selected-student');
    if (previouslySelected) {
        previouslySelected.classList.remove('selected-student');
    }

    // Show the relevant section when the button is clicked
    document.getElementById('assignThesisToStudentSection').style.display = 'block';

    // Fetch and render theses when the professor section is shown
    const theses = await fetchTheses();
    renderThesesToAssign(theses);  // Render the list of theses
});

// Handle search button click event
document.getElementById('searchStudentBtn').addEventListener('click', async function() {
    const query = document.getElementById('studentSearch').value; // Get the search input

    if (!query) {
        alert("Please enter a search term.");
        return;
    }

    try {
        const token = localStorage.getItem('token');  // Get the token from local storage

        if (!token) {
            alert('Please log in first.');
            return;
        }

        // Make the request to the backend
        const response = await fetch(`http://localhost:5000/professor/students/search?query=${encodeURIComponent(query)}`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`,  // Include the JWT token in the Authorization header
                'Content-Type': 'application/json',
            },
        });

        if (response.ok) {
            const students = await response.json();  // Parse the JSON response

            // Render the list of students
            renderStudentsList(students);
        } else {
            const errorData = await response.json();
            alert(errorData.message || 'Error occurred while searching for students.');
            renderStudentsList([]);  // Clear the results if there was an error
        }
    } catch (error) {
        console.error('Error during search request:', error);
        alert('Something went wrong while searching for students.');
    }
});

// Add event listener to the "Assign Thesis" button
document.getElementById('assignThesisBtn').addEventListener('click', async function() {
    if (!selectedThesis || !selectedStudent) {
        alert('Please select both a thesis and a student.');
        return;
    }

    const confirmation = await safeAlertConfirm(
        `Do you want to assign "${selectedThesis.title}" to ${selectedStudent.name} (ID:${selectedStudent.student_id})?`
    );
    if (!confirmation) {
        return
    }

    try {
        // Make the PUT request to assign the thesis
        const response = await fetch(`http://localhost:5000/professor/theses/${selectedThesis.id}/assign`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            },
            body: JSON.stringify({ student_id: selectedStudent.student_id })
        });

        const data = await response.json();

        if (response.status === 200) {
            safeAlertSuccess('Thesis successfully assigned to student!');
            // Optionally, update UI to reflect changes (e.g., show the updated thesis status)
        } else {
            safeAlertError(data.error || 'Failed to assign thesis.');
        }
    } catch (error) {
        console.error('Error assigning thesis:', error);
        safeAlertError('Failed to assign thesis. Please try again.');
    }
});

// Function to render the list of theses for assigning to students
function renderThesesToAssign(theses) {
    const thesisListContainer = document.getElementById('thesisListToAssign'); // The new container in assignThesisToStudentSection

    // Clear any existing content
    thesisListContainer.innerHTML = '';
    if (theses.message === 'No theses to be assigned.') {
        thesisListContainer.innerHTML = '<p>No theses available for assignment.</p>';
        return;
    }

    // Create a <ul> element to hold the list
    const ul = document.createElement('ul');

    // Loop through each thesis and create a <li> for it
    theses.forEach(thesis => {
        const li = document.createElement('li');
        li.classList.add('thesis-item');  // Add class to style the list items

        // Create a clickable item that displays the title
        const titleElement = document.createElement('span');
        titleElement.textContent = `${thesis.title}`;

        // Add the click event listener to the <li> itself
        li.addEventListener('click', () => {
            selectThesisForAssignment(thesis, li);
        });

        // Append the title to the list item
        li.appendChild(titleElement);

        // Append each <li> to the <ul>
        ul.appendChild(li);
    });

    // Append the <ul> to the thesis list container
    thesisListContainer.appendChild(ul);
}

// Function to highlight a selected thesis when clicked
function selectThesisForAssignment(thesis, listItem) {
    // Deselect any previously selected thesis
    const previouslySelected = document.querySelector('.selected-thesis');
    if (previouslySelected) {
        previouslySelected.classList.remove('selected-thesis');
    }

    // Highlight the clicked thesis
    listItem.classList.add('selected-thesis');

    // Store the selected thesis globally (or in a variable) for assignment
    selectedThesis = thesis;

    // Enable the "Assign Thesis" button if both student and thesis are selected
    toggleAssignThesisButton();
}

// Function to render the list of students in the UI
function renderStudentsList(students) {
    const studentListContainer = document.getElementById('studentListContainer');
    
    // Clear any existing content
    studentListContainer.innerHTML = '';

    if (students.length === 0) {
        studentListContainer.innerHTML = '<p>No students found.</p>';
        return;
    }

    // Create a <ul> element to hold the list
    const ul = document.createElement('ul');

    // Loop through each student and create a <li> for it
    students.forEach(student => {
        const li = document.createElement('li');
        li.classList.add('student-item');  // Add the class for styling

        // Create a clickable item that displays the student's name
        const nameElement = document.createElement('span');
        nameElement.textContent = `Name: ${student.name} (ID: ${student.student_id})`;
        nameElement.style.cursor = 'pointer';

        // Add a click event to select the student
        li.addEventListener('click', () => {
            selectStudentForAssignment(student, li);
        });

        // Append the name to the list item
        li.appendChild(nameElement);

        // Append each <li> to the <ul>
        ul.appendChild(li);
    });
    
    // Append the <ul> to the student list container
    studentListContainer.appendChild(ul);
}

// Function to handle student selection for thesis assignment
function selectStudentForAssignment(student, listItem) {
    // Deselect any previously selected student
    const previouslySelected = document.querySelector('.selected-student');
    if (previouslySelected) {
        previouslySelected.classList.remove('selected-student');
    }

    // Highlight the clicked student
    listItem.classList.add('selected-student');

    // Optionally, store the selected student globally for later use
    selectedStudent = student;

    // Enable the "Assign Thesis" button if both student and thesis are selected
    toggleAssignThesisButton();
}

// Function to toggle the "Assign Thesis" button based on selections
function toggleAssignThesisButton() {
    if (selectedThesis && selectedStudent) {
        document.getElementById('assignThesisBtn').style.display = 'inline-block';
    } else {
        document.getElementById('assignThesisBtn').style.display = 'none';
    }
}

//////////////////////////////////////////
//// CANCEL THESIS ASSIGNMENT OPTION ////

let selectedThesisForCancel = null;

document.getElementById('cancelThesisAssignmentBtn').addEventListener('click', async function() {
    // Hide all sections initially
    hideAllSections();
    selectedThesisForCancel = null;

    sidebar.classList.remove('open'); //for small screens

    // Show the relevant section when the button is clicked
    document.getElementById('cancelThesisAssignmentSection').style.display = 'block';

    // Fetch and render theses when the professor section is shown
    const theses = await fetchAssignedTheses();
    renderAssignedThesesList(theses);  // Render the list of theses
});

// Function to fetch assigned theses
async function fetchAssignedTheses() {
    const token = localStorage.getItem('token');
  
    if (!token) {
      console.log('You must be logged in to view assigned theses.');
      return [];
    }
  
    try {
      const response = await fetch('http://localhost:5000/professor/theses/assigned', {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
  
      if (response.ok) {
        const result = await response.json();
        return result;
      } else {
        const error = await response.json();
        console.error('Error fetching assigned theses:', error);
        return [];
      }
    } catch (error) {
      console.error('Error fetching assigned theses:', error);
      return [];
    }
}
  
// Function to render the list of assigned theses
function renderAssignedThesesList(theses) {
    const assignedThesisListContainer = document.getElementById('assignedThesisList');
  
    // Clear any existing content
    assignedThesisListContainer.innerHTML = '';
  
    if (!Array.isArray(theses) || theses.length === 0) {
      assignedThesisListContainer.innerHTML = '<p>No assigned theses to display.</p>';
      return;
    }
  
    // Create a <ul> element to hold the list
    const ul = document.createElement('ul');
  
    // Loop through each thesis and create a <li> for it
    theses.forEach(thesis => {
        const li = document.createElement('li');
    
        // Create a clickable span element that displays the title
        const titleElement = document.createElement('span');
        titleElement.textContent = `Title: ${thesis.title}`;
        titleElement.style.cursor = 'pointer';  // Make sure the cursor is a pointer
        
        // To make the whole span clickable, ensure it behaves like a block element
        titleElement.style.display = 'block';  // Makes the span take up the full width of the li
        
        // Add a click event to select the thesis for canceling assignment
        li.addEventListener('click', () => {
            selectThesisToCancel(thesis, li);
        });
    
        // Append the title to the list item
        li.appendChild(titleElement);
    
        // Append each <li> to the <ul>
        ul.appendChild(li);
    });
  
    // Append the <ul> to the thesis list container
    assignedThesisListContainer.appendChild(ul);
}
  
// Function to highlight a selected thesis for cancellation
function selectThesisToCancel(thesis, listItem) {
    // Deselect any previously selected thesis
    const previouslySelected = document.querySelector('.selected-thesis');
    if (previouslySelected) {
      previouslySelected.classList.remove('selected-thesis');
    }
  
    // Highlight the clicked thesis
    listItem.classList.add('selected-thesis');
  
    // Store the selected thesis globally (or in a variable) for cancellation
    selectedThesisForCancel = thesis;
  
    // Enable the "Cancel Assignment" button
    document.getElementById('cancelAssignmentBtn').style.display = 'inline-block';
}
  
// Function to cancel the thesis assignment
async function cancelThesisAssignment() {
    if (!selectedThesisForCancel) {
      console.log('No thesis selected for cancellation');
      return;
    }

    const confirmation = await safeAlertConfirm('Are you sure you want to cancel the assignment of this thesis?');
    if (!confirmation) {
        return;
    }
    // console.log(selectedThesisForCancel)
  
    const token = localStorage.getItem('token');
    
    try {
      const response = await fetch(`http://localhost:5000/professor/theses/${selectedThesisForCancel.id}/cancel`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ status: 'assigned' }) // Assuming you need to reset the status to 'assigned'
      });
  
      if (response.ok) {
        const result = await response.json();
        await safeAlertSuccess('Thesis assignment canceled!');
        // console.log('Thesis assignment canceled:', result);
        // Update the UI to reflect the cancellation
        renderAssignedThesesList(await fetchAssignedTheses());
      } else {
        const error = await response.json();
        console.error('Error canceling thesis assignment:', error);
      }
    } catch (error) {
      console.error('Error canceling thesis assignment:', error);
    }
}

////////////////////////////////
//// VIEW MY THESES OPTION ////

let offset = 0;
const limit = 50;

document.getElementById('viewMyThesesBtn').addEventListener('click', async function() {
    // Hide all sections initially
    hideAllSections();
    selectedThesis = null;

    sidebar.classList.remove('open'); //for small screens

    // Show the relevant section when the button is clicked
    document.getElementById('viewMyThesesSection').style.display = 'block';

    // Call function to fetch and display theses
    fetchAndDisplayTheses();
});

document.getElementById('statusFilter').addEventListener('change', () => {
    resetToDefault();
    fetchAndDisplayTheses();
});
  
  document.getElementById('roleFilter').addEventListener('change', () => {
    resetToDefault();
    fetchAndDisplayTheses();
});

document.getElementById('viewDetailsBtn').addEventListener('click', () => {
    if (selectedThesis) {
        openModal(selectedThesis); // Open the modal for the selected thesis
    }
});

// Add an event listener for the "Download All" button
document.getElementById('downloadAllBtn').addEventListener('click', downloadAllDetails);

async function fetchAndDisplayTheses() {
    const token = localStorage.getItem('token');
    const professorId = localStorage.getItem('roleId');

    const status = document.getElementById('statusFilter').value;
    const role = document.getElementById('roleFilter').value;

    try {
        const response = await fetch(`http://localhost:5000/professor/theses/all?status=${status}&role=${role}&limit=${limit}&offset=${offset}`, {
            method: 'GET',  // Keep GET method
            headers: {
                'Authorization': `Bearer ${token}`,  // Pass the token in Authorization header
                'professor_id': professorId,  // Pass the professor_id in the header
            },
        });
        const data = await response.json();

        if (response.ok) {
            // console.log('thesis data: ' , data);
            displayTheses(data);
        } else {
            document.getElementById('myThesisListContainer').innerHTML = `<p>${data.message}</p>`;
            document.getElementById('downloadAllBtn').disabled = 'true';
        }
    } catch (error) {
        console.error('Error fetching theses:', error);
        document.getElementById('myThesisListContainer').innerHTML = '<p>Failed to load theses.</p>';
    }
}

// Display theses in the list
function displayTheses(theses) {
    const container = document.getElementById('myThesisListContainer');
    container.innerHTML = ''; // Clear previous content

    if (theses.length === 0) {
        container.innerHTML = '<p>No theses found.</p>';
    } else {
        // Create an unordered list
        const thesisList = document.createElement('ul');
        
        // Create the list of theses with only the title
        theses.forEach(thesis => {
            const thesisItem = document.createElement('li');
            thesisItem.classList.add('thesis-item');
            thesisItem.textContent = thesis.title; // Only display the title

            // Set the thesis_id as a data attribute for later use
            thesisItem.setAttribute('data-thesis-id', thesis.thesis_id);
            thesisItem.setAttribute('data-thesis-status', thesis.status);  // Store status
            thesisItem.setAttribute('data-thesis-role', thesis.role);      // Store role
            thesisItem.setAttribute('data-thesis-grading', thesis.grading);
            
            // Add event listener to select the thesis on click
            thesisItem.addEventListener('click', () => {
                // Deselect previously selected item
                const previousSelectedItem = document.querySelector('.selected-thesis');
                if (previousSelectedItem) {
                    previousSelectedItem.classList.remove('selected-thesis');
                }

                // Select the current item
                thesisItem.classList.add('selected-thesis');
                selectedThesis = thesis;

                // Show the "View Details" button
                document.getElementById('viewDetailsBtn').style.display = 'block';

                resetAllFeatureContents();
                handleDynamicFunctionality();
            });

            thesisList.appendChild(thesisItem);
        });
        
        // Append the list to the container
        container.appendChild(thesisList);
    }
}

async function getThesisDetails(thesisId) {
    const token = localStorage.getItem('token');  // Get token from localStorage

    try {
        // Make a GET request to fetch thesis details from the backend
        const response = await fetch(`http://localhost:5000/professor/theses/${thesisId}/details`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`,  // Include the JWT token in the Authorization header
            },
        });

        if (!response.ok) {
            throw new Error('Failed to fetch thesis details');
        }

        // Parse the response as JSON
        const thesisDetails = await response.json();
        return thesisDetails;  // Return the thesis details
    } catch (error) {
        console.error('Error fetching thesis details:', error);
        return null;  // Return null in case of error
    }
}


// Function to open the modal and display thesis details
async function openModal(thesis) {
    // Get modal elements
    const modal = document.getElementById('thesisModal');
    const thesisTitle = document.getElementById('modalThesisTitle');
    const thesisStatus = document.getElementById('thesisStatus');
    const thesisRole = document.getElementById('thesisRole');
    const thesisSynopsis = document.getElementById('thesisSynopsis');
    const thesisStudent = document.getElementById('thesisStudent');
    const thesisProfessorsList = document.getElementById('thesisProfessorsList');
    const statusTimelineList = document.getElementById('statusTimelineList');
    const thesisDetails = document.getElementById('thesisDetails');  // Wrapper div
    const showDetailsBtn = document.getElementById('showDetailsBtn');  // Show Details button
    
    // Set initial modal content (basic info)
    thesisTitle.textContent = thesis.title;
    thesisStatus.textContent = `Status: ${thesis.status}`;
    thesisRole.textContent = `My role: ${thesis.role}`;

    // Clear previous data in the modal
    thesisSynopsis.textContent = '';
    thesisStudent.textContent = '';
    thesisProfessorsList.innerHTML = '';  // Clear the list
    statusTimelineList.innerHTML = '';    // Clear the timeline

    // Hide the thesis details section initially
    thesisDetails.classList.add('hidden');

    // Add an event listener to the Show Details button
    showDetailsBtn.onclick = async () => {
        // Fetch thesis details (including professors and status history)
        const thesisDetailsData = await getThesisDetails(thesis.thesis_id);  // Get all details: thesis, professors, and status history
    
        if (thesisDetailsData) {
            // Populate the modal with fetched thesis details
            thesisSynopsis.textContent = thesisDetailsData.synopsis || 'No synopsis available';
            thesisStudent.textContent = (`${thesisDetailsData.student_name} ${thesisDetailsData.student_email}`) || 'No student assigned';
            
            // Display the professors and their roles
            thesisProfessorsList.innerHTML = '';  // Clear previous entries (if any)
            thesisDetailsData.professors.forEach(professor => {
                const professorItem = document.createElement('li');
                professorItem.textContent = `${professor.professor_name} ${professor.professor_email} (${professor.role})`;  // Corrected professor name
                thesisProfessorsList.appendChild(professorItem);
            });
            
            // Display the status change history timeline
            statusTimelineList.innerHTML = '';  // Clear previous status timeline (if any)
            thesisDetailsData.status_history.forEach(statusChange => {
                const statusItem = document.createElement('li');
                statusItem.textContent = `${statusChange.status} - ${new Date(statusChange.updated_at).toLocaleString()}`;
                statusTimelineList.appendChild(statusItem);
            });

             // Add PDF download link if the PDF file exists
             const thesisPdfLink = document.getElementById('thesisPdfLink');
             thesisPdfLink.innerHTML = ''; // Clear previous PDF link (if any)
 
             if (thesisDetailsData.pdf_file) {
                 const pdfLink = document.createElement('a');
                 pdfLink.href = `http://localhost:5000${thesisDetailsData.pdf_file}`;  // Add the correct path to your PDF file
                 pdfLink.textContent = 'Download PDF';
                 pdfLink.target = '_blank';  // Open in a new tab
                 thesisPdfLink.appendChild(pdfLink);
             }

             if (thesisDetailsData.status === 'completed') {            
                // Show the completed div
                document.getElementById('completed').style.display = 'block';
            
                // Final grade calculation (average of professor grades)
                const grades = thesisDetailsData.professors.map(p => parseFloat(p.grade));
                const avgGrade = grades.length > 0 ? (grades.reduce((sum, g) => sum + g, 0) / grades.length).toFixed(2) : 'N/A';
                document.getElementById('finalGrade').textContent = avgGrade;
            
                // Nimertis link (make sure it exists)
                const nimertisLink = thesisDetailsData.nimertis_link;
                if (nimertisLink) {
                    const linkElem = document.getElementById('nimertisLink');
                    linkElem.href = nimertisLink;
                    linkElem.style.display = 'inline';
                } else {
                    document.getElementById('nimertisLink').textContent = 'Not Available';
                }
                localStorage.setItem('thesisId' , thesis.thesis_id)
            }
            
    
            // Once the data is populated, remove the 'hidden' class to show the content
            thesisDetails.classList.remove('hidden');
        }
    };

    // Display the modal
    modal.style.display = 'block';

    // Close modal when clicking the close button (×)
    const closeBtn = document.getElementById('thesisModalCloseBtn')
    closeBtn.onclick = () => {
        modal.style.display = 'none';
    };

    // Close modal when clicking outside the modal
    window.onclick = (event) => {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    };
}

// Download all thesis details in the selected format (CSV or JSON)
async function downloadAllDetails() {
    const format = document.getElementById('dataFormat').value; // Get selected format

    const thesisItems = document.querySelectorAll('.thesis-item');
    const thesisDetailsPromises = [];

    // Fetch details for each thesis
    thesisItems.forEach(thesisItem => {
        const thesisTitle = thesisItem.textContent;
        // Assuming thesisTitle can be mapped to thesis_id, you might need to adjust this part
        const thesisId = thesisItem.getAttribute('data-thesis-id');
        thesisDetailsPromises.push(getThesisDetails(thesisId));
    });

    try {
        const thesisDetailsArray = await Promise.all(thesisDetailsPromises);
        
        // Trigger the download in selected format
        downloadData(thesisDetailsArray, format);
    } catch (error) {
        console.error('Error fetching thesis details for all theses:', error);
    }
}

// Function to download data in JSON or CSV format
function downloadData(data, format) {
    let dataStr;
    let fileExtension;

    if (format === 'json') {
        // Convert data to JSON string
        dataStr = JSON.stringify(data, null, 2); // Pretty format JSON
        fileExtension = 'json';
    } else if (format === 'csv') {
        // Convert data to CSV string
        dataStr = convertToCSV(data);
        fileExtension = 'csv';
    }

    // Create a Blob from the data
    const blob = new Blob([dataStr], { type: 'text/plain;charset=utf-8' });
    
    // Create a download link
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `theses_details.${fileExtension}`; // File name
    link.click(); // Trigger download
}

// Function to convert JSON data to CSV format
function convertToCSV(data) {
    const headers = Object.keys(data[0]);
    const rows = data.map(item => headers.map(header => item[header]).join(','));

    return [headers.join(','), ...rows].join('\n');
}

////////////////////////////////////////////
//// VIEW COMMITTEE INVITATIONS OPTION ////

document.getElementById('viewCommitteeInvitationsBtn').addEventListener('click', async function() {
    // Hide all sections initially
    hideAllSections();

    sidebar.classList.remove('open'); //for small screens

    // Show the relevant section when the button is clicked
    document.getElementById('viewCommitteeInvitationsSection').style.display = 'block';

    // Call the function to fetch and display committee invitations
    fetchCommitteeInvitations();
});

// Function to fetch committee invitations from the backend
async function fetchCommitteeInvitations() {
    // Get the token and professorId from localStorage
    const token = localStorage.getItem('token');
    const professorId = localStorage.getItem('roleId');

    if (!token || !professorId) {
        alert("You must be logged in as a professor to view invitations.");
        return;
    }

    try {
        // Make the API call to get the committee invitations
        const response = await fetch(`http://localhost:5000/professor/invitations/${professorId}`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });

        // Parse the JSON data
        const invitations = await response.json();
        // Display the invitations
        displayCommitteeInvitations(invitations);
    } catch (error) {
        console.error('Error fetching committee invitations:', error);
        alert('An error occurred while fetching the invitations.');
    }
}

// Function to display committee invitations on the page
function displayCommitteeInvitations(invitations) {
    const listContainer = document.getElementById('committeeInvitationsList');
    listContainer.innerHTML = ''; // Clear previous content

    if (invitations.message === 'No pending invitations found for this professor') {
        listContainer.innerHTML = `<p>No pending invitations found for this professor</p>`;
        return;
    }

    invitations.forEach(invitation => {
        // Create a new element for each invitation
        const invitationElement = document.createElement('div');
        invitationElement.classList.add('invitation');

        invitationElement.innerHTML = `
            <h3>${invitation.title}</h3>
            <p><strong>Supervisor: </strong>${invitation.supervisor.professor_name} - ${invitation.supervisor.professor_email}</p>
            <p><strong>Student: </strong>${invitation.student.student_name} - ${invitation.student.student_email}</p>
            
            <!-- Buttons for Accept, Reject, and Details -->
            <div class="buttons-container">
                <div class="accept-reject-btns">
                    <button class="accept-btn" data-thesis-id="${invitation.thesis_id}">Accept</button>
                    <button class="reject-btn" data-thesis-id="${invitation.thesis_id}">Reject</button>
                </div>
            </div>
        `;

        // Append the invitation to the list container
        listContainer.appendChild(invitationElement);
    });

     // Now attach event listeners for the Accept/Reject buttons after they are added to the DOM
     document.querySelectorAll('.accept-btn').forEach(button => {
        button.addEventListener('click', function() {
            const thesisId = this.getAttribute('data-thesis-id');
            handleInvitationResponse(thesisId, 'accepted');
        });
    });

    document.querySelectorAll('.reject-btn').forEach(button => {
        button.addEventListener('click', function() {
            const thesisId = this.getAttribute('data-thesis-id');
            handleInvitationResponse(thesisId, 'rejected');
        });
    });
}

// Common function to handle Accept/Reject actions
async function handleInvitationResponse(thesisId, action) {
    // Get token and professorId from localStorage
    const token = localStorage.getItem('token');
    const professorId = localStorage.getItem('roleId');

    if (!token || !professorId) {
        alert("You must be logged in to perform this action.");
        return;
    }

    // Confirm the action with the user
    const confirmMessage = action === 'accepted' 
        ? "Are you sure you want to accept this invitation?" 
        : "Are you sure you want to reject this invitation?";

    const userConfirmed = await safeAlertConfirm(confirmMessage); // Show the confirmation dialog

    if (!userConfirmed) {
        return; // If the user cancels, do nothing
    }

    // Make the request to accept/reject the invitation
    try {
        const response = await fetch(`http://localhost:5000/professor/invitation/response`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                thesis_id: thesisId,
                professor_id: professorId,
                status: action // either 'accepted' or 'rejected'
            })
        });

        if (!response.ok) {
            throw new Error('Failed to update invitation status');
        }

        // Notify the user and refresh the invitations list or perform other actions
        await safeAlertSuccess(`Invitation has been ${action === 'accepted' ? 'accepted' : 'rejected'}.`);
        fetchCommitteeInvitations(); // Refresh the invitations list after action
    } catch (error) {
        console.error('Error processing invitation:', error);
        await safeAlertError('An error occurred while updating the invitation status.');
    }
}

/////////////////////////////////
//// HANDLE DYNAMIC OPTIONS ////

function handleDynamicFunctionality() {
    resetToDefault();

    // Get the selected thesis item
    const selectedThesisItem = document.querySelector('.selected-thesis');
    if (!selectedThesisItem) return; // If no thesis is selected, exit

    // Retrieve the thesis status and role from the data attributes of the selected item
    const statusValue = selectedThesisItem.getAttribute('data-thesis-status');
    const roleValue = selectedThesisItem.getAttribute('data-thesis-role');

    // Handle functionality based on the status
    if (statusValue === 'assigned') {
        enableAssignedThesisFeatures();
    } else if (statusValue === 'in progress') {
        enableInProgressFeatures();
    } else if (statusValue === 'under review') {
        enableUnderReviewFeatrues();
    }

    // Handle functionality based on both status and role
    if (statusValue === 'assigned' && roleValue === 'supervisor') {
        enableAssignedSupervisorFeatures();
    } else if (statusValue === 'in progress' && roleValue === 'supervisor') {
        enableInProgressSupervisorFeatures();
    }  else if (statusValue === 'under review' && roleValue === 'supervisor') {
        enableUnderReviewSupervisorFeatures();
    }
}


function resetToDefault() {
    document.getElementById('assignedFeatures').style.display = 'none';
    document.getElementById('assignedSupervisorFeatures').style.display = 'none';
    document.getElementById('inProgressFeatures').style.display = 'none';
    document.getElementById('inProgressSupervisorFeatures').style.display = 'none';
    document.getElementById('underReviewFeatures').style.display = 'none';
    document.getElementById('underReviewSupervisorFeatures').style.display = 'none';
}

function resetAllFeatureContents() {
    // Select all feature elements (those containing the feature title and content)
    const features = document.querySelectorAll('.feature');
    
    features.forEach(feature => {
        const featureTitle = feature.querySelector('.feature-title');
        
        if (!featureTitle) {
            return;
        }

        const featureContent = feature.querySelector('.feature-content');
        const arrow = featureTitle.querySelector('.arrow');
        if (featureContent) {
            // Reset the content display to 'none'
            featureContent.style.display = 'none';
            
            // Reset the arrow to point to the right (rotate back to 0deg)
            arrow.style.transform = 'rotate(0deg)';
        }
    });
}
  
function enableAssignedThesisFeatures() {
    document.getElementById('assignedFeatures').style.display = 'block';

    // Add event listener to each feature item (li.feature) instead of just the title span
    const featureItems = document.querySelectorAll('#assignedFeatures li.feature');
    featureItems.forEach(item => {
        item.addEventListener('click', toggleFeatureContent);
    });
}

function enableAssignedSupervisorFeatures() {
    document.getElementById('assignedSupervisorFeatures').style.display = 'block';

    const featureItems = document.querySelectorAll('#assignedSupervisorFeatures li.feature');
    featureItems.forEach(item => {
        item.addEventListener('click', toggleFeatureContent);
    });
}

function enableInProgressFeatures() {
    document.getElementById('inProgressFeatures').style.display = 'block';

    const featureItems = document.querySelectorAll('#inProgressFeatures li.feature');
    featureItems.forEach(item => {
        item.addEventListener('click', toggleFeatureContent);
    });
}

function enableInProgressSupervisorFeatures() {
    document.getElementById('inProgressSupervisorFeatures').style.display = 'block';

    const featureItems = document.querySelectorAll('#inProgressSupervisorFeatures li.feature');
    featureItems.forEach(item => {
        item.addEventListener('click', toggleFeatureContent);
    });
}

function enableUnderReviewFeatrues() {
    document.getElementById('underReviewFeatures').style.display = 'block';

    // Add event listener to each feature item (li.feature) instead of just the title span
    const featureItems = document.querySelectorAll('#underReviewFeatures li.feature');
    featureItems.forEach(item => {
        item.addEventListener('click', toggleFeatureContent);
    });
}

function enableUnderReviewSupervisorFeatures() {
    // hide enable grading option if its already enabled
    const selectedThesis = document.querySelector('.selected-thesis');
    if (selectedThesis && selectedThesis.getAttribute('data-thesis-grading') === 'enabled') {        
        document.getElementById('enableGradingFeature').style.display = 'none';
    }

    document.getElementById('underReviewSupervisorFeatures').style.display = 'block';

    // Add event listener to each feature item (li.feature) instead of just the title span
    const featureItems = document.querySelectorAll('#underReviewSupervisorFeatures li.feature');
    featureItems.forEach(item => {
        item.addEventListener('click', toggleFeatureContent);
    });
}

function toggleFeatureContent(event) {
    // Stop bubbling just in case
    event.stopPropagation();

    // Find the closest .feature li no matter where we clicked
    const featureItem = event.target.closest('.feature');

    if (!featureItem) return;

    const featureTitle = featureItem.querySelector('.feature-title');
    const featureContent = featureItem.querySelector('.feature-content');
    const arrow = featureItem.querySelector('.arrow');

    if (!featureTitle) return;

    const featureName = featureTitle.getAttribute('data-feature-name');

    // Always fetch feature data
    fetchFeatureData(featureName);

    if (featureContent && arrow) {
        const isVisible = featureContent.style.display === 'block';

        featureContent.style.display = isVisible ? 'none' : 'block';
        arrow.style.transform = isVisible ? 'rotate(0deg)' : 'rotate(90deg)';
    }
}


function fetchFeatureData(featureName) {
    // Fetch data based on the feature clicked (currently only "Other Professors")
    if (featureName === 'Other Professors') {
        fetchOtherProfessors();
    } else if (featureName === 'cancel assignment') {
        document.getElementById('cancelThesisAssignmentBtn').click();
    } else if (featureName === 'my notes') {
        fetchProfessorNotes();
    } else if (featureName === 'cancel assignment permanently') {
        cancelAssignmentPermanently();
    } else if (featureName === 'start review process') {
        startReviewProcess();
    } else if (featureName === 'view thesis draft') {
        fetchThesisDraft();
    } else if (featureName === 'presentation details') {
        fetchPresentationDetails();
    }  else if (featureName === 'enable grading') {
        enableGrading();
    }   else if (featureName === 'grades') {
        fetchGrades();
    }
}

async function fetchOtherProfessors() {
    // Check if a thesis is selected
    if (!selectedThesis) {
        alert("No thesis selected.");
        return;
    }

    // Get the token and professorId from localStorage
    const token = localStorage.getItem('token');
    const professorId = localStorage.getItem('roleId');

    if (!token || !professorId) {
        alert("You must be logged in as a professor to view the other professors.");
        return;
    }

    try {
        // Make the API call to get other professors, passing thesis_id and professorId
        const response = await fetch(`http://localhost:5000/professor/assigned/otherProfessors?thesis_id=${selectedThesis.thesis_id}&professor_id=${professorId}`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });

        // Parse the JSON data
        const data = await response.json();

        renderOtherProfessorsList(data);

        // You can update your UI or do further actions with 'data' here

    } catch (error) {
        // Handle errors during the fetch
        console.error('Error fetching other professors:', error);
        alert("An error occurred while fetching the other professors.");
    }
}

function renderOtherProfessorsList(data) {
    const professorsList = document.getElementById('otherProfessorsList');
    const invitationsList = document.getElementById('invitationsList');
    
    // Clear both lists before rendering new data
    professorsList.innerHTML = '';
    invitationsList.innerHTML = '';

    // Render Other Professors if any
    if (data.otherProfessors && data.otherProfessors.length > 0) {
        // Add a label for professors
        professorsList.innerHTML = '<strong>Other Professors:</strong>';

        data.otherProfessors.forEach(professor => {
            const listItem = document.createElement('li');

            // Add professor details to the list item
            listItem.innerHTML = `
                <div>
                    <strong>Name:</strong> ${professor.name} <br>
                    <strong>Email:</strong> ${professor.email} <br>
                    <strong>Role:</strong> ${professor.role ? professor.role : 'N/A'}
                </div>
            `;
            professorsList.appendChild(listItem);
        });
    } else {
        // If no other professors, show a message
        professorsList.innerHTML = '<li>No other professors found for this thesis.</li>';
    }

    // Render Committee Invitations if any
    if (data.invitations && data.invitations.length > 0) {
        // Add a label for invitations
        invitationsList.innerHTML = '<strong>Committee Invitations:</strong>';

        data.invitations.forEach(invite => {
            const inviteItem = document.createElement('li');

            // Add invitation details to the list item
            inviteItem.innerHTML = `
                <div>
                    <strong>Name:</strong> ${invite.name} <br>
                    <strong>Email:</strong> ${invite.email} <br>
                    <strong>Status:</strong> ${invite.status} <br>
                    <strong>Invited:</strong> ${invite.invitation_date} <br>
                    <strong>Response Date:</strong> ${invite.response_date ? invite.response_date : 'N/A'}
                </div>
            `;
            invitationsList.appendChild(inviteItem);
        });
    } else {
        // If no committee invitations, show a message
        invitationsList.innerHTML = '<li>No committee invitations found for this thesis.</li>';
    }
}

// IN PROGRESS FEATURES / professor notes feature

async function fetchProfessorNotes() {
    // Get the token from localStorage for authorization
    const token = localStorage.getItem('token');
    const professor_id = localStorage.getItem('roleId');
    const thesis_id = selectedThesis ? selectedThesis.thesis_id : null;
    if (!token || !professor_id || !thesis_id) {
        alert("You must be logged in and provide a thesis must be selected to view the notes.");
        return;
    }

    try {
        // Make the GET request to fetch professor notes
        const response = await fetch(`http://localhost:5000/professor/inProgress/getNotes?thesis_id=${thesis_id}&professor_id=${professor_id}`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });

        // Parse the response JSON
        const data = await response.json();

        // Call a function to render the notes in the UI (if you want to display them)
        renderProfessorNotes(data);

    } catch (error) {
        // Handle any errors that occur during the fetch
        console.error('Error fetching professor notes:', error);
        alert("An error occurred while fetching the notes.");
    }
}

function renderProfessorNotes(data) {
    const notesList = document.getElementById('myNotesList');  // Get the UL element

    // Clear any existing content inside the list
    notesList.innerHTML = '';

    // Check if there is a message indicating no notes were found
    if (data.message) {
        // Display the message in the list if no notes found
        const messageItem = document.createElement('li');
        messageItem.classList.add('no-notes-message');
        messageItem.textContent = data.message;  // Display the message from the backend

        // Append the message to the list
        notesList.appendChild(messageItem);
    } else if (data.notes && data.notes.length > 0) {
        // If there are notes, loop through and create HTML elements for each note
        data.notes.forEach(note => {
            const noteItem = document.createElement('li');
            noteItem.classList.add('note-item');
            // noteItem.textContent = note.title; // Display only the title
            noteItem.textContent = `📝 ${note.title}`;
        
            // Add an event listener to open the modal when the note item is clicked
            noteItem.addEventListener('click', function() {
                event.stopPropagation(); // Prevent the click from bubbling up to the feature
                openNoteModal(note);
            });
        
            // Append the note item to the notes list
            notesList.appendChild(noteItem);
        });
    }
}

// Show the modal when the "New Note" button is clicked
document.getElementById('newNote').addEventListener('click', () => {
    event.stopPropagation(); // Prevent the click from bubbling up to the feature
    // Open the modal
    document.getElementById('notesModal').style.display = 'block';

    // Clear all fields
    document.getElementById('noteTitle').value = '';
    document.getElementById('noteContent').value = '';
    document.getElementById('noteId').value = '';

    // Enable the fields (make them editable)
    document.getElementById('noteTitle').disabled = false;
    document.getElementById('noteContent').disabled = false;

    // Hide the "Edit" and "Delete" buttons
    document.getElementById('editNoteBtn').style.display = 'none';
    document.getElementById('deleteNoteBtn').style.display = 'none';

    // Show the "Submit" button
    document.getElementById('submitNoteBtn').style.display = 'inline-block';
});

document.getElementById('noteContent').addEventListener('input', function() {
    // Get the textarea and character count display elements
    const textarea = document.getElementById('noteContent');
    const charCount = document.getElementById('charCount');

    // Set the initial character count
    const maxLength = 300;
    charCount.textContent = `${maxLength} characters remaining`;

    const currentLength = textarea.value.length;
    const remainingChars = maxLength - currentLength;

    // Update the character count text
    charCount.textContent = `${remainingChars} characters remaining`;

    // Optionally change the color if the character count is low
    if (remainingChars <= 50) {
        charCount.style.color = 'red';  // Change text to red if remaining chars are <= 50
    } else {
        charCount.style.color = '';  // Reset to default color if greater than 50
    }

    // Prevent exceeding the limit by enforcing the maxlength attribute
    if (currentLength >= maxLength) {
        textarea.value = textarea.value.substring(0, maxLength);  // Trim the text to the max length
    }
});

document.getElementById('editNoteBtn').addEventListener('click', () => {
    event.stopPropagation(); // Prevent the click from bubbling up to the feature

    
    // Enable the input fields (make them editable)
    document.getElementById('noteTitle').disabled = false;
    document.getElementById('noteContent').disabled = false;

    // Show the "Submit" button (for saving the edited note)
    document.getElementById('submitNoteBtn').style.display = 'inline-block';

    // Hide the "Edit" and "Delete" buttons
    document.getElementById('editNoteBtn').style.display = 'none';
    document.getElementById('deleteNoteBtn').style.display = 'none';
});

// modal stuff
document.getElementById('notesCloseBtn').addEventListener('click', function() {
    event.stopPropagation(); // Prevent the click from bubbling up to the feature
    document.getElementById('notesModal').style.display = 'none';
});
window.addEventListener('click', function(event) {
    event.stopPropagation(); // Prevent the click from bubbling up to the feature
    if (event.target === document.getElementById('notesModal')) {
        document.getElementById('notesModal').style.display = 'none';
    }
});

function openNoteModal(note) {
    // Open the modal
    document.getElementById('notesModal').style.display = 'block';

    // Populate the fields with the note data
    document.getElementById('noteId').value = note.id;
    document.getElementById('noteTitle').value = note.title;
    document.getElementById('noteContent').value = note.note;
    
    // Display the last updated timestamp
    const lastUpdated = document.getElementById('lastUpdated');
    lastUpdated.textContent = `Last Updated: ${new Date(note.updated_at).toLocaleString()}`;

    // Disable the fields (make them read-only)
    document.getElementById('noteTitle').disabled = true;
    document.getElementById('noteContent').disabled = true;

    // Hide the "Submit" button
    document.getElementById('submitNoteBtn').style.display = 'none';

    // Show the "Edit" and "Delete" buttons
    document.getElementById('editNoteBtn').style.display = 'inline-block';
    document.getElementById('deleteNoteBtn').style.display = 'inline-block';
}

// Handle the submit button click event
document.getElementById('noteForm').addEventListener('submit', (event) => {
    event.stopPropagation(); // Prevent the click from bubbling up to the feature
    event.preventDefault();  // Prevent form submission

    // Get the note data
    const noteId = document.getElementById('noteId').value;
    const noteTitle = document.getElementById('noteTitle').value;
    const noteContent = document.getElementById('noteContent').value;

    // Check if there is a note ID (which means we're editing an existing note)
    if (noteId) {
        // Call the function to edit the note
        editNote(noteId, noteTitle, noteContent);
        fetchProfessorNotes();
    } else {
        // Call the function to add a new note
        addNote(noteTitle, noteContent);
        fetchProfessorNotes();
    }

    // Close the modal after submitting
    document.getElementById('notesModal').style.display = 'none';
});

// Function to add a new note
function addNote(title, content) {
    console.log("Adding new note:", title, content);
    // Implement your note adding logic here (e.g., making an API call)
}

async function addNote(title, content) {
    // Get the JWT token, professor id (roleId), and thesis id from localStorage or global variable
    const token = localStorage.getItem('token'); // Assuming the token is stored as 'token' in localStorage
    const professorId = localStorage.getItem('roleId'); // Assuming professorId is stored as 'roleId'
    const thesisId = selectedThesis.thesis_id; // Assuming selectedThesis is a global object with thesis_id

    // Check if any required data is missing
    if (!token || !professorId || !thesisId) {
        console.error("Missing required data: token, professorId, or thesisId");
        return;
    }

    try {
        // Get the JWT token, professor id (roleId), and thesis id from localStorage or global variable
        const token = localStorage.getItem('token'); // Assuming the token is stored as 'token' in localStorage
        const professorId = localStorage.getItem('roleId'); // Assuming professorId is stored as 'roleId'
        const thesisId = selectedThesis.thesis_id; // Assuming selectedThesis is a global object with thesis_id

        // Check if any required data is missing
        if (!token || !professorId || !thesisId) {
            console.error("Missing required data: token, professorId, or thesisId");
            return;
        }

        // Create the payload to be sent in the request
        const data = {
            title: title,
            note: content
        };

        // Send a POST request to the backend API
        const response = await fetch(`http://localhost:5000/professor/inProgress/addNote/${thesisId}/${professorId}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}` // Include the JWT token in the authorization header
            },
            body: JSON.stringify(data) // Send the title and note data in the request body
        });

        // Check if the response is successful (status code 200)
        if (!response.ok) {
            const errorData = await response.json();
            console.error("Error adding note:", errorData.message);
            return;
        }

        // Parse the response JSON
        const result = await response.json();

        if (result.message === 'Note successfully added') {
            // Optionally, handle the successful note addition, like closing the modal or updating the UI
            fetchProfessorNotes();
        } else {
            console.error("Unexpected response:", result);
        }

    } catch (error) {
        console.error("Error making request:", error);
    }
}

async function editNote(id, title, content) {
    // Get the JWT token from localStorage
    const token = localStorage.getItem('token'); 

    if (!token) {
        console.error("Missing JWT token");
        return;
    }

    try {
        // Get the JWT token from localStorage
        const token = localStorage.getItem('token'); 

        if (!token) {
            console.error("Missing JWT token");
            return;
        }

        // Create the payload for the request
        const data = {
            title: title,
            note: content
        };

        // Send a PUT request to update the note
        const response = await fetch(`http://localhost:5000/professor/notes/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}` // Include the JWT token for authorization
            },
            body: JSON.stringify(data) // Send the note data in the body
        });

        // Handle the response
        if (!response.ok) {
            const errorData = await response.json();
            console.error("Error updating note:", errorData.error);
            return;
        }

        const result = await response.json();

        if (result.message === 'Note updated successfully') {
            // Optionally, update the UI to reflect the changes
            document.getElementById('notesModal').style.display = 'none'; // Close the modal
            fetchProfessorNotes();
        } else {
            console.error("Unexpected response:", result);
        }

    } catch (error) {
        console.error("Error making request:", error);
    }
}

// Adding the delete button event listener
document.getElementById('deleteNoteBtn').addEventListener('click', async () => {
    event.stopPropagation(); // Prevent the click from bubbling up to the feature
    // Confirm deletion with the user
    const userConfirmed = await safeAlertConfirm("Are you sure you want to delete this note?");
    if (!userConfirmed) {
        return;
    }

    const noteId = document.getElementById('noteId').value; // Get the note ID from the hidden input (or wherever it's stored)
    
    if (noteId) {
        try {
            // Get the JWT token from localStorage
            const token = localStorage.getItem('token');
            if (!token) {
                console.error("Missing JWT token");
                return;
            }

            // Send a DELETE request to delete the note
            const response = await fetch(`http://localhost:5000/professor/notes/${noteId}`, {
                method: 'DELETE',
                headers: {
                    'Authorization': `Bearer ${token}` // Include the JWT token for authorization
                }
            });

            // Handle the response
            if (!response.ok) {
                const errorData = await response.json();
                console.error("Error deleting note:", errorData.error);
                return;
            }

            const result = await response.json();

            if (result.message === 'Note deleted successfully') {
                // Optionally, update the UI (e.g., remove the note from the list, close modal, etc.)
                // For example, you can close the modal or reset the form
                document.getElementById('notesModal').style.display = 'none'; // Close the modal
                fetchProfessorNotes();
            } else {
                console.error("Unexpected response:", result);
            }

        } catch (error) {
            console.error("Error making request:", error);
        }
    } else {
        console.error("No note ID found for deletion.");
    }
});

// IN PROGRESS SUPERVISOR FEATURES / professor notes feature
async function cancelAssignmentPermanently() {
    // Step 1: Fetch values from localStorage and selectedThesis
    const thesisId = selectedThesis.thesis_id;  // Thesis ID from selectedThesis
    const professorId = localStorage.getItem('roleId');  // Professor ID from localStorage
    const token = localStorage.getItem('token');  // Token from localStorage

    if (!thesisId || !professorId || !token) {
        alert("Required data (Thesis ID, Professor ID, or Token) is missing. Please make sure you are logged in and have selected a thesis.");
        return;
    }

    // Step 2: Prompt for meeting info (meeting number and year)
    const meetingNumber = await safeAlertPrompt("Please enter the meeting number where the cancelation was approved:");
    if(!meetingNumber) {
        return;
    }

    const meetingYear = await safeAlertPrompt("Please enter the meeting year where the cancelation was approved:");

    // Step 3: Validate the meeting info
    if (!meetingNumber || !meetingYear || isNaN(meetingNumber) || isNaN(meetingYear)) {
        await safeAlert("Invalid meeting number or year. Please ensure both fields are filled in with valid values.");
        return;
    }

    // Step 4: Confirm cancellation
    const confirmCancel = await safeAlertConfirm(`Are you sure you want to permanently cancel the assignment for thesis ID ${thesisId}?`);
    
    if (!confirmCancel) {
        await safeAlert("Cancelation process has been aborted.");
        return;
    }

    // Step 5: Proceed with the cancelation

    try {
        // Make the request to cancel the thesis
        const response = await fetch(`http://localhost:5000/professor/cancelThesis/${thesisId}/${professorId}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({
                meeting_info: `Meeting Number: ${meetingNumber}, Meeting Year: ${meetingYear}`
            })
        });

        const data = await response.json();

        if (response.ok) {
            await safeAlertSuccess("Thesis has been successfully canceled.");
            // console.log("Cancelation success:", data);
        } else {
            await safeAlertError(`Error: ${data.error || "An error occurred."}`);
            console.error("Cancelation error:", data.error);
        }
    } catch (error) {
        await safeAlertError("There was an error while canceling the thesis. Please try again.");
        console.error("Error making cancel request:", error);
    }
}    

async function startReviewProcess() {
    try {
        // Confirm with the user that the thesis status will change to "Under Review"
        const confirmation = await safeAlertConfirm(
            'Are you sure you want to start the review process? This will change the thesis status to "Under Review".'
        );

        if (confirmation) {
            // Get the thesis_id and token from local storage
            const thesisId = selectedThesis.thesis_id; // Make sure selectedThesis is set
            const token = localStorage.getItem('token'); // Get token from local storage

            // Prepare the API endpoint and headers
            const url = `http://localhost:5000/professor/startReviewProcess/${thesisId}`;
            const headers = {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            };

            // Make the PUT request to start the review process
            const response = await fetch(url, {
                method: 'PUT',
                headers: headers,
            });

            const data = await response.json();

            if (data.message) {
                // Success: Notify the user about the successful status change
                await safeAlertSuccess('The status of the thesis has been successfully changed to "Under Review".');
                // Optionally, refresh the page or update the UI here to reflect the status change
            } else {
                // Error: Show the error message from the backend
                await safeAlertError(data.error || 'Failed to start the review process.');
            }
        }
    } catch (error) {
        console.error('Error during review process start:', error);
        await safeAlertError('An error occurred while starting the review process.');
    }
}

// UNDER REVIEW FEATURES //
document.getElementById('gradeThesisBtn').addEventListener('click', function () {
    event.stopPropagation();

    document.getElementById('gradingModal').style.display = 'block';
});

// modal stuff
document.getElementById('gradingCloseBtn').addEventListener('click', function() {
    event.stopPropagation(); // Prevent the click from bubbling up to the feature
    document.getElementById('gradingModal').style.display = 'none';
});

document.getElementById('gradingForm').addEventListener('submit', async function(event) {
    event.preventDefault(); // Prevent form from reloading the page

    // Get token and user data
    const token = localStorage.getItem('token');
    const professor_id = localStorage.getItem('roleId');
    const thesis_id = selectedThesis.thesis_id; // Make sure selectedThesis is accessible in this scope

    // Get and parse the input values
    const c1 = parseFloat(document.getElementById('criteria1').value);
    const c2 = parseFloat(document.getElementById('criteria2').value);
    const c3 = parseFloat(document.getElementById('criteria3').value);
    const c4 = parseFloat(document.getElementById('criteria4').value);

    // Calculate the final weighted grade
    const weightedGrade = (
        (c1 * 0.6) +
        (c2 * 0.15) +
        (c3 * 0.15) +
        (c4 * 0.10)
    ).toFixed(2);

    // Ask for confirmation
    const confirmed = await safeAlertConfirm(`The final calculated grade is ${weightedGrade}/10. Do you want to confirm this grade?`);

    if (!confirmed) {
        console.log("User canceled the grade confirmation.");
        return;
    }

    // Prepare the data to send
    const data = {
        thesis_id: thesis_id,
        professor_id: professor_id,
        grade: weightedGrade
    };

    try {
        const response = await fetch('http://localhost:5000/professor/gradeThesis', {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify(data)
        });

        if (!response.ok) {
            throw new Error(`Server error: ${response.statusText}`);
        }

        const result = await response.json();
        await safeAlertSuccess("Grade submitted successfully");
        resetToDefault();
        document.getElementById('gradingCloseBtn').click();
    } catch (error) {
        await safeAlertError("Error submitting grade:");
        console.log(error);
    }
});

async function fetchThesisDraft() {
    // Get the token from localStorage for authorization
    const token = localStorage.getItem('token');
    const thesis_id = selectedThesis ? selectedThesis.thesis_id : null;

    try {
        // Make the GET request to fetch professor notes
        const response = await fetch(`http://localhost:5000/professor/theses/draft/${thesis_id}`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });

        // Parse the response JSON
        const data = await response.json();

        // Call a function to render the notes in the UI (if you want to display them)
        renderThesisDraft(data);

    } catch (error) {
        // Handle any errors that occur during the fetch
        console.error('Error fetching draft:', error);
        await safeAlertError("An error occurred while fetching the draft.");
    }
}

function renderThesisDraft(data) {
    const draftLinkContainer = document.getElementById('draftLinkContainer');
    const additionalLinksList = document.getElementById('additionalLinksList');
  
    // Clear previous content
    draftLinkContainer.innerHTML = '';
    additionalLinksList.innerHTML = '';
  
    // Display the draft link
    if (data.draft) {
      const draftLink = document.createElement('a');
      draftLink.href = `http://localhost:5000${data.draft}`;
      draftLink.textContent = 'View Thesis Draft';
      draftLink.target = '_blank';
      draftLinkContainer.appendChild(draftLink);
    } else {
      draftLinkContainer.textContent = 'No draft available.';
    }
  
    // Display additional links (if any)
    if (data.links && data.links.length > 0) {
      data.links.forEach(url => {
        const li = document.createElement('li');
        const link = document.createElement('a');
        link.href = url;
        link.textContent = url;
        link.target = '_blank';
        li.appendChild(link);
        additionalLinksList.appendChild(li);
      });
    } else {
      const noLinksItem = document.createElement('li');
      noLinksItem.textContent = 'No additional resources provided.';
      additionalLinksList.appendChild(noLinksItem);
    }
}


async function fetchGrades() {
    const thesisId = selectedThesis?.thesis_id;
    const token = localStorage.getItem('token');

    if (!thesisId || !token) {
        alert("Missing thesis ID or token.");
        return;
    }

    try {
        const response = await fetch(`http://localhost:5000/professor/thesisGrades/${thesisId}`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json',
            }
        });

        const data = await response.json();

        if (response.ok) {
            renderGrades(data);
        } else {
            await safeAlertError(data.error || "Failed to fetch grades.");
        }

    } catch (err) {
        console.error("Fetch error:", err);
        await safeAlertError("An error occurred while fetching grades.");
    }
}

function renderGrades(data) {
    console.log(data);
    const roleId = parseInt(localStorage.getItem('roleId'), 10);
    const myGradeElem = document.getElementById('myGrade');
    const otherGradesList = document.getElementById('otherGradesList');
    const gradeThesisBtn = document.getElementById('gradeThesisBtn');
    const finalGradeElem = document.getElementById('finalGrade');

    // Clear previous content
    myGradeElem.textContent = '';
    otherGradesList.innerHTML = '';

    // Check if grading is enabled
    if (data.grading !== 'enabled') {
        myGradeElem.textContent = 'Grading has not been enabled yet.';
        return;
    }

    let totalGrades = 0;
    let gradeSum = 0;

    data.grades.forEach(gradeInfo => {
        const gradeDisplay = gradeInfo.grade !== null ? gradeInfo.grade : 'No grade submitted yet.';
        if (gradeInfo.grade !== null) {
            totalGrades++;
            gradeSum += parseFloat(gradeInfo.grade);
        }

        if (gradeInfo.professor_id === roleId) {
            
            myGradeElem.textContent = `Your Grade: ${gradeDisplay}`;
            if (gradeInfo.grade === null) {
                gradeThesisBtn.style.display = 'block';
            } else {
                gradeThesisBtn.style.display = 'none';
            }
        } else {
            const li = document.createElement('li');
            li.textContent = `${gradeInfo.name}'s Grade: ${gradeDisplay}`;
            otherGradesList.appendChild(li);
            
        }
    });

    // If all 3 professors have graded, show the final average grade
    if (totalGrades === 3) {
        const averageGrade = (gradeSum / 3).toFixed(2);
        finalGradeElem.innerHTML = `<strong>Final Grade: ${averageGrade}</strong>`;
    }
}

 
// UNDER REVIEW SUPERVISOR //
async function fetchPresentationDetails() {
    const token = localStorage.getItem('token');
    const thesis_id = selectedThesis ? selectedThesis.thesis_id : null;
  
    if (!thesis_id) {
      console.error('No thesis ID found.');
      return;
    }
  
    try {
      const response = await fetch(`http://localhost:5000/professor/theses/presentation/${thesis_id}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
  
      const data = await response.json();
  
      renderPresentationDetails(data);
  
    } catch (error) {
      console.error('Error fetching presentation details:', error);
      await safeAlertError("An error occurred while fetching presentation info.");
    }
}

function renderPresentationDetails(data) {
    const dateTimeElem = document.getElementById('presentationDateTime');
    const locationElem = document.getElementById('presentationLocation');
    const linkElem = document.getElementById('presentationLink');
  
    const dateTimeContainer = document.getElementById('presentationDateTimeContainer');
    const locationContainer = document.getElementById('presentationLocationContainer');
    const linkContainer = document.getElementById('presentationLinkContainer');

    const studentNameElem = document.getElementById('studentName');
    const committeeListElem = document.getElementById('committeeList');
    const thesisTitleElem = document.getElementById('thesisTitleInfo');
  
    // Check if there's any data
    const hasDetails = data.presentation_datetime || data.presentation_location || data.presentation_link;
  
    if (!hasDetails) {
        document.getElementById('presentationDetailsDisplay').textContent = 'The student has not submitted presentation details yet.';
        return;
    }

    // Reveal the button since there are details
    document.getElementById('createAnnouncementBtn').style.display = 'inline-block';

    // Populate the student and committee info
    if (data.student_name) {
        studentNameElem.textContent = data.student_name;
    }

    if (data.committee && data.committee.length > 0) {
        data.committee.forEach(professor => {
            const li = document.createElement('li');
            li.textContent = `${professor.name} (${professor.role})`;
            committeeListElem.appendChild(li);
        });
    }

    if (data.thesis_title) {
        thesisTitleElem.textContent = data.thesis_title;
    }

    // Format and display the Date & Time if available
    if (data.presentation_datetime) {
      const dt = new Date(data.presentation_datetime);
      dateTimeElem.textContent = dt.toLocaleString();  // Show Date & Time without a label
      dateTimeContainer.style.display = 'block';  // Show the Date & Time container
    }
  
    // Format and display the Location if available
    if (data.presentation_location) {
      locationElem.textContent = data.presentation_location;  // Show Location without a label
      locationContainer.style.display = 'block';  // Show the Location container
    }
  
    // Format and display the Link if available
    if (data.presentation_link) {
      const a = document.createElement('a');
      a.href = data.presentation_link;
      a.target = '_blank';
      a.textContent = 'Join Online Presentation';  // Only show the link text
      linkElem.appendChild(a);
      linkContainer.style.display = 'block';  // Show the Link container
    }
}

document.getElementById('createAnnouncementBtn').addEventListener('click', function () {
    const studentName = document.getElementById('studentName').textContent;
    const committeeMembers = document.getElementById('committeeList').children;
    const presentationDate = document.getElementById('presentationDateTime').textContent;
    const presentationLocation = document.getElementById('presentationLocation').textContent;
    const presentationLink = document.getElementById('presentationLink').textContent;

    // Get the thesis title from the text content of the selected thesis element
    const thesisIdElement = document.querySelector('.thesis-item.selected-thesis');
    const thesis_title = thesisIdElement ? thesisIdElement.textContent.trim() : null;

    // Begin building the announcement text
    let announcementText = ``;
    announcementText += `We are pleased to announce the thesis presentation of ${studentName}.\n\n`;
    announcementText += `Thesis Title: "${thesis_title}"\n\n`;

    // Add the committee members
    announcementText += `Committee Members:\n`;
    for (let i = 0; i < committeeMembers.length; i++) {
        announcementText += `- ${committeeMembers[i].textContent}\n`;
    }

    announcementText += `\nPresentation Details:\n`;

    // Add the presentation details (Location/Link)
    if (presentationLocation) {
        announcementText += `The presentation will be held in person at ${presentationLocation}.\n`;
    } else if (presentationLink) {
        announcementText += `The presentation will be held online. You can join via the following link: ${presentationLink}\n`;
    }

    // Add the scheduled time
    announcementText += `Date and Time: ${presentationDate}\n`;

    // Set the announcement text in the modal
    document.getElementById('announcementText').textContent = announcementText;
    
    // Show the modal with the formatted announcement
    document.getElementById('announcementModal').style.display = 'block';
});

document.getElementById('publishAnnouncementBtn').addEventListener('click', async function () {
    const token = localStorage.getItem('token');
    const announcementText = document.getElementById('announcementText').textContent;

    if (!token) {
        await safeAlert('You must be logged in to publish an announcement.');
        return;
    }

    if (!selectedThesis || !selectedThesis.thesis_id) {
        alert('No thesis selected.');
        return;
    }

    const thesis_id = selectedThesis.thesis_id;

    try {
        const response = await fetch('http://localhost:5000/professor/announcements', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({
                thesis_id: thesis_id,
                text: announcementText
            })
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || 'Failed to publish announcement.');
        }

        const data = await response.json();
        await safeAlertSuccess('Announcement published successfully!');
        document.getElementById('announcementModal').style.display = 'none';
    } catch (error) {
        console.error('Error publishing announcement:', error);
        await safeAlertError(`Error: ${error.message}`);
    }
});

// modal stuff
document.getElementById('announcementCloseBtn').addEventListener('click', function() {
    event.stopPropagation(); // Prevent the click from bubbling up to the feature
    document.getElementById('announcementModal').style.display = 'none';
});
  
async function enableGrading() {
    // Step 1: Fetch values from localStorage and selectedThesis
    const thesisId = selectedThesis.thesis_id;  // Thesis ID from selectedThesis
    const token = localStorage.getItem('token');  // Token from localStorage

    if (!thesisId || !token) {
        alert("Required data (Thesis ID, or Token) is missing. Please make sure you are logged in and have selected a thesis.");
        return;
    }

    // Step 4: Confirm cancellation
    const confirm = await safeAlertConfirm('Are you sure you want to enable grading for this thesis?');
    
    if (!confirm) {
        return;
    }

    // Step 5: Proceed with the cancelation

    try {
        // Make the request to cancel the thesis
        const response = await fetch(`http://localhost:5000/professor/enableGrading/${thesisId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
        });

        const data = await response.json();

        if (response.ok) {
            await safeAlertSuccess("Thesis grading has been enabled.");
            document.getElementById('viewMyThesesBtn').click();
        } else {
            await safeAlertError(`Error: ${data.error || "An error occurred."}`);
            console.error("Error:", data.error);
        }
    } catch (error) {
        await safeAlertError("There was an error. Please try again.");
        console.error("Error making request:", error);
    }
}

////////////////
//// STATS ////
document.getElementById('viewStatisticsBtn').addEventListener('click', async function() {
    // Hide all sections initially
    hideAllSections();
    selectedThesis = null;

    sidebar.classList.remove('open'); //for small screens

    // Show the relevant section when the button is clicked
    document.getElementById('statsSection').style.display = 'flex';

    // Fetch and render theses when the professor section is shown
    fetchStatsData();
});

async function fetchStatsData() {
    const token = localStorage.getItem('token');
    const roleId = localStorage.getItem('roleId'); // Assuming this is where professor ID is stored

    if (!token || !roleId) {
        console.error('Token or roleId not found in local storage.');
        return;
    }

    try {
        const response = await fetch(`http://localhost:5000/professor/${roleId}/stats/`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (!response.ok) {
            throw new Error(`Failed to fetch stats: ${response.statusText}`);
        }

        const data = await response.json();
        // Process the data
        const processedData = processData(data);
        const stats = calculateStats(processedData);
        renderStats(stats);
        
    } catch (error) {
        console.error('Error fetching professor stats:', error);
    }
}

function processData(data) {
    const { professorId, completedTheses } = data.completedTheses;
  
    // Iterate over each thesis
    completedTheses.forEach(thesis => {
      // Find the matching professor in the professor_details array
      const matchingProfessor = thesis.professor_details.find(professor => professor.professor_id === parseInt(professorId));
      
      if (matchingProfessor) {
        // If a matching professor is found, add the role to the thesis object
        thesis.matchedRole = matchingProfessor.role;
      } else {
        thesis.matchedRole = null; // No match found
      }
    });
    console.log(completedTheses);
    return completedTheses; // Return the modified completedTheses array
}

// New function to calculate stats for both Supervisor and Committee Member roles
function calculateStats(completedTheses) {
    let supervisorCount = 0;
    let committeeMemberCount = 0;
    let totalTimeSupervisor = 0;
    let totalTimeCommittee = 0;
    let totalGradeSupervisor = 0;
    let totalGradeCommittee = 0;
  
    completedTheses.forEach(thesis => {
      // Calculate statistics for Supervisor role
      if (thesis.matchedRole === 'supervisor') {
        supervisorCount++;
  
        // Calculate time to completion (in days)
        const assignedDate = new Date(thesis.assignedDate);
        const completedDate = new Date(thesis.completedDate);
        const timeToCompletion = (completedDate - assignedDate) / (1000 * 3600 * 24); // Convert to days
        totalTimeSupervisor += timeToCompletion;
  
        // Calculate the average grade for the supervisor's thesis
        const grades = thesis.professor_details.map(professor => parseFloat(professor.grade));
        const averageGrade = grades.reduce((sum, grade) => sum + grade, 0) / grades.length;
        totalGradeSupervisor += averageGrade;
      }
  
      // Calculate statistics for Committee Member role
      if (thesis.matchedRole === 'committee member') {
        committeeMemberCount++;
  
        // Calculate time to completion (in days)
        const assignedDate = new Date(thesis.assignedDate);
        const completedDate = new Date(thesis.completedDate);
        const timeToCompletion = (completedDate - assignedDate) / (1000 * 3600 * 24); // Convert to days
        totalTimeCommittee += timeToCompletion;
  
        // Calculate the average grade for the committee member's thesis
        const grades = thesis.professor_details.map(professor => parseFloat(professor.grade));
        const averageGrade = grades.reduce((sum, grade) => sum + grade, 0) / grades.length;
        totalGradeCommittee += averageGrade;
      }
    });
  
    // Calculate average time to completion and average grade for each role
    const avgTimeSupervisor = supervisorCount > 0 ? totalTimeSupervisor / supervisorCount : 0;
    const avgTimeCommittee = committeeMemberCount > 0 ? totalTimeCommittee / committeeMemberCount : 0;
    const avgGradeSupervisor = supervisorCount > 0 ? totalGradeSupervisor / supervisorCount : 0;
    const avgGradeCommittee = committeeMemberCount > 0 ? totalGradeCommittee / committeeMemberCount : 0;
  
    return {
      supervisorCount,
      committeeMemberCount,
      avgTimeSupervisor,
      avgTimeCommittee,
      avgGradeSupervisor,
      avgGradeCommittee
    };
}
  
function renderStats(stats) {
    // Ensure the stats object has all necessary properties
    if (!stats) {
        console.error('No stats provided');
        return;
    }

    try {
        // Total Theses Chart
        const totalThesesCtx = document.getElementById('totalThesesChart').getContext('2d');
        new Chart(totalThesesCtx, {
            type: 'bar',  
            data: {
                labels: ['Supervisor', 'Committee Member'],  
                datasets: [{
                    label: 'Total Theses Participated In',
                    data: [stats.supervisorCount, stats.committeeMemberCount],  
                    backgroundColor: ['#007bff', '#ffc107'],
                    borderColor: ['#0056b3', '#e6a800'],  
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        // Duration Chart
        const durationCtx = document.getElementById('durationChart').getContext('2d');
        new Chart(durationCtx, {
            type: 'bar',
            data: {
                labels: ['Supervisor', 'Committee Member'],  
                datasets: [{
                    label: 'Average Time to Completion (Days)',
                    data: [stats.avgTimeSupervisor, stats.avgTimeCommittee],  
                    backgroundColor: ['#28a745', '#ffc107'],
                    borderColor: ['#218838', '#e6a800'],  
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        // Grade Chart
        const gradeCtx = document.getElementById('gradeChart').getContext('2d');
        new Chart(gradeCtx, {
            type: 'bar',
            data: {
                labels: ['Supervisor', 'Committee Member'],
                datasets: [{
                    label: 'Average Grade',
                    data: [stats.avgGradeSupervisor, stats.avgGradeCommittee],
                    backgroundColor: ['#007bff', '#ffc107'],
                    borderColor: ['#0056b3', '#e6a800'],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

    } catch (err) {
        console.error('Error rendering charts:', err);
    }
}
