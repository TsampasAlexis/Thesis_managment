////////////////////
// GENERIC STUFF //
window.addEventListener('load', checkLoginAndRedirect);

// Get the hamburger button and sidebar elements
const hamburger = document.getElementById('hamburger');
const sidebar = document.getElementById('sidebar');

// Add click event to toggle the sidebar visibility
hamburger.addEventListener('click', function() {
    sidebar.classList.toggle('open');
});

// Check login status on the dashboard page
function checkLoginAndRedirect() {
    if (!isLoggedIn()) {
        window.location.href = 'index.html'; // Redirect to login page if not logged in
    } else {
        // User is logged in, now show the role-based content
        const username = localStorage.getItem('username');
        document.querySelector('#profile span').innerText = `Welcome, ${username}`;
        displayDashboardContent();
    }
}

// function to check if the user is logged in by looking for the token in localStorage
function isLoggedIn() {
    const token = localStorage.getItem('token');
    return token ? true : false;
}

// Function to display content based on user role
async function displayDashboardContent() {
    const role = localStorage.getItem('role');

    // Show the relevant section based on role
    if (role === 'student') {
        document.getElementById('viewMyThesisBtn').click(); // reveal first option by default
      return;
    } else {
        window.location.href = 'index.html'
    }
}
function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('role');
    localStorage.removeItem('roleId');
    localStorage.removeItem('username');
    localStorage.removeItem('status');

    fetch('http://localhost:5000/logout', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        }
    })
    .then(response => response.json())
    .then(data => {
        // Handle the response, like updating the UI or redirecting
        // console.log(data.message);
        window.location.href = 'index.html';  // Redirect to login page
    })
    .catch(error => {
        console.error('Error logging out:', error);
    });
}

function hideAllTheSections() {    
    document.getElementById('viewMyThesisSection').style.display = 'none';
    document.getElementById('editProfileSection').style.display = 'none';
    document.getElementById('manageThesisSection').style.display = 'none';
}

async function safeAlertConfirm(question) {
    try {
        // Attempt to use SweetAlert2 for confirmation
        const result = await Swal.fire({
            title: question,
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'Yes',
            cancelButtonText: 'No',
            confirmButtonColor: '#007bff',  // Set "Yes" button color directly
            cancelButtonColor: '#f44336',  // Set "No" button color directly
        });

        // Return true if the user confirms, false if they cancel
        return result.isConfirmed;
    } catch (error) {
        // If SweetAlert2 fails, use the normal JavaScript confirm
        return confirm(question);
    }
}

async function safeAlert(alertMessage) {
    try {
        // Using SweetAlert to display a simple alert
        await Swal.fire({
            title: 'Alert',
            text: alertMessage,
            icon: 'info',
            confirmButtonText: 'OK',
            confirmButtonColor: '#007bff',  // Set the "OK" button color to blue
        });
    } catch (error) {
        // If SweetAlert fails, fall back to using a normal JavaScript alert
        alert(alertMessage);
    }
}

async function safeAlertSuccess(successMessage) {
    try {
        // Using SweetAlert for success alert
        await Swal.fire({
            title: 'Success!',
            text: successMessage,
            icon: 'success',
            confirmButtonText: 'OK',
            confirmButtonColor: '#007bff', // Custom blue button color
        });
    } catch (error) {
        // Fallback to the standard alert if SweetAlert fails
        alert(successMessage);
    }
}

async function safeAlertError(errorMessage) {
    try {
        // Using SweetAlert for error alert
        await Swal.fire({
            title: 'Error!',
            text: errorMessage,
            icon: 'error',
            confirmButtonText: 'OK',
            confirmButtonColor: '#007bff', // Custom blue button color
        });
    } catch (error) {
        // Fallback to the standard alert if SweetAlert fails
        alert(errorMessage);
    }
}

async function safeAlertPrompt(promptMessage, inputPlaceholder = '') {
    try {
        // Using SweetAlert for prompt
        const { value } = await Swal.fire({
            title: 'Please provide input',
            text: promptMessage,
            input: 'text',
            inputPlaceholder: inputPlaceholder,
            showCancelButton: true,
            confirmButtonText: 'Submit',
            cancelButtonText: 'Cancel',
            confirmButtonColor: '#007bff', // Custom blue button color
        });

        // If a value is entered, return it; otherwise, return null
        return value || null;
    } catch (error) {
        // Fallback to the standard prompt if SweetAlert fails
        const result = prompt(promptMessage, inputPlaceholder);
        return result ? result : null;
    }
}

////////////////////////////////
//// VIEW MY THESIS OPTION //// 

document.getElementById('viewMyThesisBtn').addEventListener('click', async function() {
    // Hide all sections initially
    hideAllTheSections();

    sidebar.classList.remove('open'); //for small screens    

    // Fetch and render theses when the professor section is shown
    getMyThesis();
});

async function getMyThesis() {
    // Get the student ID (roleId) and token from local storage
    const studentId = localStorage.getItem('roleId');  // Assuming the student ID is stored as 'roleId'
    const token = localStorage.getItem('token');  // Token from local storage

    if (!studentId || !token) {
        await safeAlertError('You must be logged in to view your thesis.');
        return;
    }
    
    try {
        

        // Make the request to get the thesis using the student's ID
        const url = `http://localhost:5000/student/myThesis/${studentId}`;
        const headers = {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
        };

        // Fetch the data from the backend
        const response = await fetch(url, {
            method: 'GET',
            headers: headers,
        });

        // Parse the response
        const data = await response.json();

        if (data.message) {
            // Success: Show the thesis details
            displayMyThesis(data);
        } else {
            // Error: Show the error message from the backend
            await safeAlertError(data.error || 'Failed to get thesis details.');
        }
    } catch (error) {
        console.error('Error fetching thesis:', error);
        await safeAlertError('An error occurred while fetching your thesis.');
    }
}

function displayMyThesis(data) {
    const thesis = data.thesis;
    const professors = data.professors || [];
    const assignedDate = new Date(data.assignedDate).toLocaleDateString();

    // Set text content for each element
    document.getElementById('thesisTitle').textContent = thesis.title;
    document.getElementById('thesisSynopsis').textContent = thesis.synopsis;
    document.getElementById('thesisStatus').textContent = thesis.status;
    document.getElementById('thesisAssignedDate').textContent = assignedDate;
    

    // PDF link handling
    const pdfSpan = document.getElementById('thesisPDF');
    if (thesis.pdf_file) {
        const link = document.createElement('a');
        link.href = `http://localhost:5000${thesis.pdf_file}`;
        link.textContent = 'View PDF';
        link.target = '_blank';
        pdfSpan.innerHTML = ''; // Clear any previous content
        pdfSpan.appendChild(link);
    } else {
        pdfSpan.textContent = 'No file uploaded';
    }

    // Populate professors list
    const profList = document.getElementById('professorsList');
    profList.innerHTML = ''; // Clear existing list
    professors.forEach((prof) => {
        const li = document.createElement('li');
        li.textContent = `${prof.name} (${prof.email}) - ${prof.role}`;
        profList.appendChild(li);
    });

    document.getElementById('viewMyThesisSection').style.display = 'block';
}

//////////////////////////////
//// EDIT PROFILE OPTION ////
document.getElementById('editProfileSectionBtn').addEventListener('click', async function() {
    // Hide all sections initially
    hideAllTheSections();

    sidebar.classList.remove('open'); //for small screens    

    getUserData();
    
    document.getElementById('contactInfoForm').style.display = 'none';
    document.getElementById('contactInfo').style.display = 'block';
    document.getElementById('editProfileBtn').style.display = 'inline-block';
});

document.getElementById('editProfileBtn').addEventListener('click', () => {
    // Hide static contact info
    document.getElementById('contactInfo').style.display = 'none';

    // Show form
    document.getElementById('contactInfoForm').style.display = 'block';

    // Hide the edit button
    document.getElementById('editProfileBtn').style.display = 'none';

    // Optionally, pre-fill the form with current values
    document.getElementById('editName').value = document.getElementById('name').textContent !== 'N/A' ? document.getElementById('name').textContent : '';
    document.getElementById('editEmail').value = document.getElementById('email').textContent !== 'N/A' ? document.getElementById('email').textContent : '';
    document.getElementById('editAddress').value = document.getElementById('address').textContent !== 'N/A' ? document.getElementById('address').textContent : '';
    document.getElementById('editCellPhone').value = document.getElementById('cellPhone').textContent !== 'N/A' ? document.getElementById('cellPhone').textContent : '';
    document.getElementById('editHomePhone').value = document.getElementById('homePhone').textContent !== 'N/A' ? document.getElementById('homePhone').textContent : '';


});


async function getUserData() {
    // Get the student ID (roleId) and token from local storage
    const studentId = localStorage.getItem('roleId');  // Assuming the student ID is stored as 'roleId'
    const token = localStorage.getItem('token');  // Token from local storage

    if (!studentId || !token) {
        console.error('You must be logged in to fetch user data.');
        return;
    }

    try {
        // Make the request to get the user profile data using the student's ID
        const url = `http://localhost:5000/student/profile/${studentId}`;
        const headers = {
            'Authorization': `Bearer ${token}`,  // JWT token for authorization
            'Content-Type': 'application/json'
        };

        // Fetch the data from the backend
        const response = await fetch(url, {
            method: 'GET',
            headers: headers,
        });

        // Parse the response
        const data = await response.json();

        if (data && data.profile) {
            // Success: Log the profile data
            displayUserProfile(data.profile);
        } else {
            // Error: Handle the case when no profile data is returned
            await safeAlertError('Failed to retrieve user profile data.');
        }
    } catch (error) {
        console.error('Error fetching user data:', error);
    }
}

function displayUserProfile(profileData) {
    // Check if the data is available and valid
    if (profileData) {
        // Populate profile info
        document.getElementById('username').textContent = profileData.username || 'N/A';
        document.getElementById('role').textContent = profileData.role || 'N/A';

        // Populate contact info
        document.getElementById('name').textContent = profileData.name || 'N/A';
        document.getElementById('email').textContent = profileData.email || 'N/A';
        document.getElementById('address').textContent = profileData.address || 'N/A';
        document.getElementById('cellPhone').textContent = profileData.cell_phone || 'N/A';
        document.getElementById('homePhone').textContent = profileData.home_phone || 'N/A';

        // Display the profile section
        document.getElementById('editProfileSection').style.display = 'block';
    } else {
        console.error("Invalid profile data.");
    }
}

document.getElementById('contactInfoForm').addEventListener('submit', async (e) => {
    e.preventDefault();

    const token = localStorage.getItem('token');
    const studentId = localStorage.getItem('roleId');

    if (!token || !studentId) {
        await safeAlertError('You must be logged in to update your profile.');
        return;
    }

    const updatedData = {
        name: document.getElementById('editName').value,
        email: document.getElementById('editEmail').value,
        address: document.getElementById('editAddress').value,
        cell_phone: document.getElementById('editCellPhone').value,
        home_phone: document.getElementById('editHomePhone').value,
    };

    try {
        const response = await fetch(`http://localhost:5000/student/updateContact/${studentId}`, {
            method: 'PUT',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(updatedData)
        });

        const result = await response.json();

        if (response.ok) {
            await safeAlertSuccess('Contact info updated successfully!');

            // Update the visible info
            document.getElementById('name').textContent = updatedData.name || 'N/A';
            document.getElementById('email').textContent = updatedData.email || 'N/A';
            document.getElementById('address').textContent = updatedData.address || 'N/A';
            document.getElementById('cellPhone').textContent = updatedData.cell_phone || 'N/A';
            document.getElementById('homePhone').textContent = updatedData.home_phone || 'N/A';

            // Hide form, show info and button again
            document.getElementById('contactInfoForm').style.display = 'none';
            document.getElementById('contactInfo').style.display = 'block';
            document.getElementById('editProfileBtn').style.display = 'inline-block';

        } else {
            await safeAlertError(result.error || 'Failed to update contact info.');
        }
    } catch (error) {
        console.error('Error updating contact info:', error);
        await safeAlertError('An error occurred while updating contact info.');
    }
});

///////////////////////////////
//// MANAGE THESIS OPTION ////
document.getElementById('manageThesisBtn').addEventListener('click', async function() {
    // Hide all sections initially
    hideAllTheSections();

    sidebar.classList.remove('open'); //for small screens    

    // Fetch and render theses when the professor section is shown
    fetchStatusBasedData();
});

async function fetchStatusBasedData() {
    const studentId = localStorage.getItem('roleId');
    const token = localStorage.getItem('token');

    if (!studentId || !token) {
        await safeAlertError('You must be logged in to view this data.');
        return;
    }

    try {
        const response = await fetch(`http://localhost:5000/student/status-data/${studentId}`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json',
            },
        });

        const result = await response.json();

        if (result.status) {
            // console.log("Current Thesis Status:", result.status);
            // console.log("Full Data Returned:", result);
            localStorage.setItem('thesisId', result.thesis_id);

            if (result.status === 'assigned') {
                // Reveal the assigned subsection
                document.getElementById('assgignedSubsection').style.display = 'flex';
        
                // Pass invitations to the display function
                populateInvitationsList(result.invitations);
            } else if (result.status === 'in progress') {
                document.getElementById('inProgessSubsection').style.display = 'block';
            } else if (result.status === 'under review') {
                document.getElementById('underReviewSubsection').style.display = 'block';
                getUnderReviewData();
            } else if (result.status === 'completed') {
                document.getElementById('completedSubsection').style.display = 'block';
                renderCompletedSubsection(result.completed_data)
            }
            document.getElementById('manageThesisSection').style.display = 'block';
        } else {
            await safeAlertError(result.error || "Failed to retrieve thesis status.");
        }
    } catch (err) {
        console.error("Error fetching status data:", err);
        await safeAlertError("An unexpected error occurred.");
    }
}

// ASSIGNED STATUS //
document.getElementById('createInvitationBtn').addEventListener('click', async function (event) {
    const token = localStorage.getItem('token');
    const thesisId = localStorage.getItem('thesisId');

    const selectedItem = document.querySelector('.search-result-item.selected');
    let selectedProfessorId;
    if (selectedItem) {
        selectedProfessorId = selectedItem.getAttribute('data-professor-id');
        // console.log('Selected Professor ID:', selectedProfessorId);
    }

    // Check if any required data is missing
    if (!token || !selectedItem || !thesisId) {
        await safeAlertError("Missing required data: token, selected professor, or thesisId");
        return;
    }

    // Create the payload to be sent in the request
    const data = {
        thesis_id: thesisId,
        professor_id: selectedProfessorId
    };

    try {
        // Send a POST request to the backend API
        const response = await fetch(`http://localhost:5000/student/inviteProfessor`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}` // Include the JWT token in the authorization header
            },
            body: JSON.stringify(data) 
        });

        if (response.status === 201) {
            await safeAlertSuccess('An invitation has been sent!');
            fetchStatusBasedData();
        } else {
            await safeAlertError(data.error || 'Failed to send ivitation.');
        }
    } catch (error) {
        await safeAlertError('Failed send ivitation. Please try again.');
    }
});

function populateInvitationsList(invitations) {
    const container = document.getElementById('invitationListContainer');
    container.innerHTML = ''; // Clear previous content

    if (!invitations || invitations.length === 0) {
        container.innerHTML = '<p>No invitations found.</p>';
        return;
    }

    const list = document.createElement('ul');
    list.style.listStyle = 'none';
    list.style.padding = '0';

    invitations.forEach(inv => {
        const listItem = document.createElement('li');
        // Apply base class and status-based class
        listItem.classList.add('invitation', inv.status); // e.g. 'invitation pending'

        listItem.innerHTML = `
            <strong>${inv.professor_name} ${inv.professor_email}</strong>
            <p><strong>Invitation Status:</strong> ${inv.status}</p>
            <p><strong>Invitation Date:</strong> ${new Date(inv.invitation_date).toLocaleString()}</p>
            <p><strong>Response Date:</strong> ${inv.response_date ? new Date(inv.response_date).toLocaleString() : 'Pending'}</p>
        `;

        list.appendChild(listItem);
    });

    container.appendChild(list);
}

// Function to handle the search action
document.getElementById("searchProfessorBtn").addEventListener("click", async function() {
    const token = localStorage.getItem('token'); 

    // Check if the token is available
    if (!token) {
        console.error("No authentication token found.");
        return;
    }

    const searchTerm = document.getElementById("searchProfessors").value;

    if (!searchTerm) {
        // Optionally show a warning if no search term is entered
        return safeAlertError('Please enter a search term!');
    }

    try {
        const response = await fetch(`http://localhost:5000/searchProfessors?query=${searchTerm}`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}` // Send the token in the Authorization header
            }
        });
        const result = await response.json();

        if (response.ok) {
            // Call function to display the search results only
            displaySearchResults(result.professors);
        } else {
            await safeAlertError(result.error || 'Something went wrong with the search.');
        }
    } catch (error) {
        console.error('Error during search:', error);
        await safeAlertError('An error occurred while searching.');
    }
});

// Function to display search results separately from the invitation list
function displaySearchResults(professors) {
    const resultsContainer = document.getElementById('searchResultsContainer');
    resultsContainer.innerHTML = ''; // Clear any previous results

    if (professors.length === 0) {
        resultsContainer.innerHTML = '<p>No professors found matching the search criteria.</p>';
        return;
    }

    professors.forEach(professor => {
        const listItem = document.createElement('li');
        listItem.classList.add('search-result-item');

        // Store the professor's id as a custom attribute (data-professor-id)
        listItem.setAttribute('data-professor-id', professor.id);

        // Format the result as "name email (id="id")"
        listItem.innerHTML = `
            ${professor.professor_name} ${professor.professor_email} (id="${professor.id}")
        `;

        // Add a click event to log the professor's id when clicked
        listItem.addEventListener('click', function() {
            const professorId = listItem.getAttribute('data-professor-id');

            // Add the 'selected' class to the clicked item
            listItem.classList.add('selected');

            // Remove the 'selected' class from any previously selected item
            const selectedItems = resultsContainer.querySelectorAll('.search-result-item.selected');
            selectedItems.forEach(item => {
                if (item !== listItem) {
                    item.classList.remove('selected');
                }
            });

            document.getElementById('createInvitationBtn').style.display = 'block';
        });

        resultsContainer.appendChild(listItem);
    });
}

// UDNDER REVIEW STATUS //
let isEditing;
let currentDraftURL = '';
let currentLinks = [];
let currentPresentation = {
    datetime: '',
    location: '',
    link: ''
};

document.getElementById('presentationType').addEventListener('change', function () {
    const type = this.value;
    const locationContainer = document.getElementById('locationInputContainer');
    const linkContainer = document.getElementById('linkInputContainer');

    if (type === 'in_person') {
        locationContainer.style.display = 'block';
        linkContainer.style.display = 'none';
    } else if (type === 'online') {
        linkContainer.style.display = 'block';
        locationContainer.style.display = 'none';
    }
});

document.getElementById('addLinkBtn').addEventListener('click', (e) => {
    e.preventDefault(); // prevent default form submission
    const container = document.getElementById('linksContainer');
    const div = document.createElement('div');
    div.className = 'link-input';
    div.innerHTML = `<input type="url" name="links[]" placeholder="https://example.com">`;
    container.appendChild(div);
});

document.getElementById('draftUploadForm').addEventListener('submit', async function (e) {
    e.preventDefault();

    if (isEditing) {
        editDraft(); // You’ll define this separately
    } else {
        uploadDraft();
    }
});

async function uploadDraft() {
    const token = localStorage.getItem('token');
    const thesisId = localStorage.getItem('thesisId');
    const fileInput = document.getElementById('thesisDraft');
    const file = fileInput.files[0];

    if (!file) {
        await safeAlert('Please select a file first.');
        return;
    }

    const formData = new FormData();
    formData.append('thesis_id', thesisId);
    formData.append('thesisDraft', file);

    const linkInputs = document.querySelectorAll('input[name="links[]"]');
    linkInputs.forEach(input => {
        if (input.value.trim()) {
            formData.append('links[]', input.value.trim());
        }
    });

    const presentationDateTime = document.getElementById('presentationDateTime').value;
    const presentationType = document.getElementById('presentationType').value;
    const location = document.getElementById('presentationLocation').value.trim();
    const link = document.getElementById('presentationLink').value.trim();

    if (presentationDateTime) formData.append('presentation_datetime', presentationDateTime);

    if (presentationType === "in_person" && !location) {
        await safeAlert("Please provide the presentation location.");
        return;
    } else if (location) {
        formData.append('presentation_location', location);
    }

    if (presentationType === "online" && !link) {
        await safeAlert("Please provide the online meeting link.");
        return;
    } else if (link) {
        formData.append('presentation_link', link);
    }

    try {
        const response = await fetch('http://localhost:5000/student/uploadDraft', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${token}`,
            },
            body: formData,
        });

        if (response.ok) {
            const result = await response.json();
            await safeAlertSuccess('Draft uploaded successfully!');
            document.getElementById('manageThesisBtn').click();
        } else {
            alert('Failed to upload draft.');
        }
    } catch (err) {
        console.error('Error uploading draft:', err);
        alert('An error occurred while uploading.');
    }
}

document.getElementById('editBtn').addEventListener('click', () => {
    isEditing = true;
    document.getElementById('draftLinkContainer').style.display = 'none';
    document.getElementById('draftUploadForm').style.display = 'block';

    const fileLabel = document.querySelector('label[for="thesisDraft"]');
    if (fileLabel) {
        fileLabel.textContent = 'Change Thesis Draft (PDF):';
    }

    const fileInput = document.getElementById('thesisDraft');
    fileInput.required = false;

    // === Set Date/Time ===
    if (currentPresentation.datetime) {
        const iso = new Date(currentPresentation.datetime).toISOString().slice(0, 16);
        document.getElementById('presentationDateTime').value = iso;
    } else {
        document.getElementById('presentationDateTime').value = '';
    }

    // === Set Location and Link ===
    const locationInput = document.getElementById('presentationLocation');
    const linkInput = document.getElementById('presentationLink');

    locationInput.value = currentPresentation.location;
    linkInput.value = currentPresentation.link;

    // === Set Dropdown & Show/Hide Containers ===
    const presentationType = document.getElementById('presentationType');

    if (currentPresentation.location && !currentPresentation.link) {
        presentationType.value = 'in_person';
        document.getElementById('locationInputContainer').style.display = 'block';
        document.getElementById('linkInputContainer').style.display = 'none';
    } else if (currentPresentation.link && !currentPresentation.location) {
        presentationType.value = 'online';
        document.getElementById('locationInputContainer').style.display = 'none';
        document.getElementById('linkInputContainer').style.display = 'block';
    } else {
        // fallback: hide both
        document.getElementById('locationInputContainer').style.display = 'none';
        document.getElementById('linkInputContainer').style.display = 'none';
    }

    // === Additional Links ===
    const linksContainer = document.getElementById('linksContainer');
    linksContainer.innerHTML = '<label>Additional Resources:</label>'; // clear all

    currentLinks.forEach(link => {
        const div = document.createElement('div');
        div.classList.add('link-input');

        const input = document.createElement('input');
        input.type = 'url';
        input.name = 'links[]';
        input.placeholder = 'https://example.com';
        input.value = link;

        div.appendChild(input);
        linksContainer.appendChild(div);
    });

    // Ensure at least one input is there (in case it's empty)
    if (currentLinks.length === 0) {
        const div = document.createElement('div');
        div.classList.add('link-input');

        const input = document.createElement('input');
        input.type = 'url';
        input.name = 'links[]';
        input.placeholder = 'https://example.com';

        div.appendChild(input);
        linksContainer.appendChild(div);
    }
});

async function editDraft() {
    const token = localStorage.getItem('token');
    const thesisId = localStorage.getItem('thesisId');
    const fileInput = document.getElementById('thesisDraft');
    const file = fileInput.files[0];

    const formData = new FormData();
    formData.append('thesis_id', thesisId);

    // Only include draft if a new one is selected
    if (file) {
        formData.append('thesisDraft', file);
    }

    // Additional resource links
    const linkInputs = document.querySelectorAll('input[name="links[]"]');
    linkInputs.forEach(input => {
        if (input.value.trim()) {
            formData.append('links[]', input.value.trim());
        }
    });

    const presentationDateTime = document.getElementById('presentationDateTime').value;
    const presentationType = document.getElementById('presentationType').value;
    const location = document.getElementById('presentationLocation').value.trim();
    const link = document.getElementById('presentationLink').value.trim();

    if (presentationDateTime) formData.append('presentation_datetime', presentationDateTime);

    if (presentationType === "in_person" && !location) {
        await safeAlert("Please provide the presentation location.");
        return;
    } else if (location) {
        formData.append('presentation_location', location);
    }

    if (presentationType === "online" && !link) {
        await safeAlert("Please provide the online meeting link.");
        return;
    } else if (link) {
        formData.append('presentation_link', link);
    }

    try {
        const response = await fetch('http://localhost:5000/student/editDraft', {
            method: 'PUT',
            headers: {
                'Authorization': `Bearer ${token}`,
            },
            body: formData,
        });

        if (response.ok) {
            const result = await response.json();
            await safeAlertSuccess('Draft updated successfully!');
            document.getElementById('manageThesisBtn').click();
        } else {
            alert('Failed to update draft.');
        }
    } catch (err) {
        console.error('Error editing draft:', err);
        alert('An error occurred while editing.');
    }
}

async function getUnderReviewData() {
    // Get the student ID (roleId) and token from local storage
    const thesisId = localStorage.getItem('thesisId');  // Assuming the student ID is stored as 'roleId'
    const token = localStorage.getItem('token');  // Token from local storage

    if (!thesisId) {
        await safeAlertError('No thesis id found.');
        return;
    }
    
    try {
        

        // Make the request to get the thesis using the student's ID
        const url = `http://localhost:5000/student/myThesisDraft/${thesisId}`;
        const headers = {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
        };

        // Fetch the data from the backend
        const response = await fetch(url, {
            method: 'GET',
            headers: headers,
        });

        // Parse the response
        const data = await response.json();
        console.log(data);

        if (response.status === 404) {
            document.getElementById('draftUploadForm').style.display = 'block';
        }else if (response.status === 200) {
            document.getElementById('draftUploadForm').style.display = 'none';
        
            const preGradingDiv = document.getElementById('preGrading');
            const postGradingDiv = document.getElementById('postGrading');
        
            // Determine based on message
            if (data.message === "Post grading data retrieved successfully.") {
                renderPostGradingData(data, postGradingDiv, preGradingDiv);
            } else {
                renderPreGradingData(data, preGradingDiv, postGradingDiv);
            }
        }
         else {
            // Error: Show the error message from the backend
            await safeAlertError(data.error || 'Failed to get thesis draft.');
        }
    } catch (error) {
        console.error('Error fetching thesis:', error);
        await safeAlertError('An error occurred while fetching your thesis draft.');
    }
}

function renderPreGradingData(data, preGradingDiv, postGradingDiv) {
    preGradingDiv.style.display = 'block';
    postGradingDiv.style.display = 'none';

    const link = document.getElementById('draftLink');
    link.href = `http://localhost:5000${data.draft}`;
    link.textContent = 'View Draft';
    document.getElementById('draftLinkContainer').style.display = 'block';

    const additionalLinks = data.links || [];
    const linksList = document.getElementById('additionalLinksList');
    linksList.innerHTML = '';

    additionalLinks.forEach(url => {
        const li = document.createElement('li');
        const a = document.createElement('a');
        a.href = url;
        a.textContent = url;
        a.target = '_blank';
        li.appendChild(a);
        linksList.appendChild(li);
    });

    if (additionalLinks.length > 0) {
        document.getElementById('additionalLinksContainer').style.display = 'block';
    }

    if (data.presentation_datetime || data.presentation_location || data.presentation_link) {
        const presDetails = [];

        if (data.presentation_datetime) {
            presDetails.push(`<strong>Date & Time:</strong> ${new Date(data.presentation_datetime).toLocaleString()}`);
        }

        if (data.presentation_location) {
            presDetails.push(`<strong>Location:</strong> ${data.presentation_location}`);
        }

        if (data.presentation_link) {
            presDetails.push(`<strong>Meeting Link:</strong> <a href="${data.presentation_link}" target="_blank">${data.presentation_link}</a>`);
        }

        const presDiv = document.getElementById('presentationDetails');
        presDiv.innerHTML = presDetails.join('<br>');
        presDiv.style.display = 'block';

        // Update global variables
        currentDraftURL = data.draft;
        currentLinks = data.links;
        currentPresentation.datetime = data.presentation_datetime || '';
        currentPresentation.location = data.presentation_location || '';
        currentPresentation.link = data.presentation_link || '';
    }
}

function renderPostGradingData(data, postGradingDiv, preGradingDiv) {
    preGradingDiv.style.display = 'none';
    postGradingDiv.style.display = 'block';

    const nimertisLink = document.getElementById('nimertisLink');
    const examReportLink = document.getElementById('examReportLink');
    const nimertisSubmitContainer = document.getElementById('nimertisSubmitContainer');

    // Show exam report link
    examReportLink.href = `/examinationReport.html`;

    if (data.nimertis_link) {
        nimertisLink.href = data.nimertis_link;
        nimertisLink.style.display = 'inline';
        nimertisLink.textContent = 'See Final Thesis';
        nimertisSubmitContainer.style.display = 'none';
    } else {
        nimertisLink.style.display = 'none';
        nimertisSubmitContainer.style.display = 'block';
    }
}

document.getElementById('submitNimertisBtn').addEventListener('click', async () => {
    const nimertisInput = document.getElementById('nimertisInput');
    const nimertisLink = nimertisInput.value.trim();
    const token = localStorage.getItem('token');
    const thesisId = localStorage.getItem('thesisId');
  
    if (!nimertisLink) {
      await safeAlertError('Please enter a valid URL.');
      return;
    }
  
    try {
      const response = await fetch(`http://localhost:5000/student/nimertisLink/${thesisId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ nimertis_link: nimertisLink })
      });
  
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to submit Nimertis link.');
      }
  
      await safeAlertSuccess('Final thesis link submitted successfully.');
  
      // Update UI
      document.getElementById('nimertisLink').href = nimertisLink;
      document.getElementById('nimertisLink').textContent = 'See Final Thesis';
      document.getElementById('nimertisLink').style.display = 'inline';
      document.getElementById('nimertisSubmitContainer').style.display = 'none';
  
    } catch (err) {
      console.error('Error submitting final thesis link:', err);
      await safeAlertError(err.message);
    }
});  

function renderCompletedSubsection(completedData) {
    const subsection = document.getElementById('completedSubsection');
    subsection.style.display = 'block';
  
    const { professors, status_history, nimertis_link } = completedData;
  
    // Final Grade (average)
    const grades = professors.map(p => parseFloat(p.grade));
    const avg = grades.length > 0 ? (grades.reduce((a, b) => a + b, 0) / grades.length).toFixed(2) : 'N/A';
    document.getElementById('finalGrade').textContent = avg;
  
    // Populate Professors List
    const profList = document.getElementById('completedProfessorsList');
    profList.innerHTML = ''; // Clear previous items
    professors.forEach(({ professor_name, professor_email, grade }) => {
      const li = document.createElement('li');
      li.textContent = `${professor_name} ${professor_email} — Grade: ${parseFloat(grade).toFixed(2)}`;
      profList.appendChild(li);
    });
  
    // Populate Status History
    const historyList = document.getElementById('statusHistoryList');
    historyList.innerHTML = '';
    status_history.forEach(({ status, updated_at }) => {
      const li = document.createElement('li');
      const date = new Date(updated_at).toLocaleString();
      li.textContent = `${status} → ${date}`;
      historyList.appendChild(li);
    });
  
    // Nimertis Link
    const nimLink = document.getElementById('nimertisLink2');
    if (nimertis_link) {
      nimLink.href = nimertis_link;
      console.log(nimLink.href);
      nimLink.style.display = 'inline';
    } else {
      nimLink.style.display = 'none';
    }
}  