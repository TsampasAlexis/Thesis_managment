////////////////////
// GENERIC STUFF //
window.addEventListener('load', checkLoginAndRedirect);

// Get the hamburger button and sidebar elements
const hamburger = document.getElementById('hamburger');
const sidebar = document.getElementById('sidebar');

// Add click event to toggle the sidebar visibility
hamburger.addEventListener('click', function() {
    sidebar.classList.toggle('open');
});

// Check login status on the dashboard page
function checkLoginAndRedirect() {
    if (!isLoggedIn()) {
        window.location.href = 'index.html'; // Redirect to login page if not logged in
    } else {
       const username = localStorage.getItem('username');
        document.querySelector('#profile span').innerText = `Welcome, ${username}`;
        displayDashboardContent();
    }
}

// function to check if the user is logged in by looking for the token in localStorage
function isLoggedIn() {
    const token = localStorage.getItem('token');
    return token ? true : false;
}

// Function to display content based on user role
async function displayDashboardContent() {
    const role = localStorage.getItem('role');

    // Show the relevant section based on role
    if (role === 'secretariat') {
        document.getElementById('viewActiveThesesBtn').click(); // reveal first option by default
      return;
    } else {
        window.location.href = 'index.html'
    }
}

function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('role');
    localStorage.removeItem('roleId');
    localStorage.removeItem('username');
    localStorage.removeItem('status');

    fetch('http://localhost:5000/logout', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        }
    })
    .then(response => response.json())
    .then(data => {
        // Handle the response, like updating the UI or redirecting
        // console.log(data.message);
        window.location.href = 'index.html';  // Redirect to login page
    })
    .catch(error => {
        console.error('Error logging out:', error);
    });
}

function hideAllTheSections() {    
    document.getElementById('viewActiveThesesSection').style.display = 'none';
    document.getElementById('enterUserInfoSection').style.display = 'none';
}

async function safeAlertConfirm(question) {
    try {
        // Attempt to use SweetAlert2 for confirmation
        const result = await Swal.fire({
            title: question,
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'Yes',
            cancelButtonText: 'No',
            confirmButtonColor: '#007bff',  // Set "Yes" button color directly
            cancelButtonColor: '#f44336',  // Set "No" button color directly
        });

        // Return true if the user confirms, false if they cancel
        return result.isConfirmed;
    } catch (error) {
        // If SweetAlert2 fails, use the normal JavaScript confirm
        return confirm(question);
    }
}

async function safeAlert(alertMessage) {
    try {
        // Using SweetAlert to display a simple alert
        await Swal.fire({
            title: 'Alert',
            text: alertMessage,
            icon: 'info',
            confirmButtonText: 'OK',
            confirmButtonColor: '#007bff',  // Set the "OK" button color to blue
        });
    } catch (error) {
        // If SweetAlert fails, fall back to using a normal JavaScript alert
        alert(alertMessage);
    }
}

async function safeAlertSuccess(successMessage) {
    try {
        // Using SweetAlert for success alert
        await Swal.fire({
            title: 'Success!',
            text: successMessage,
            icon: 'success',
            confirmButtonText: 'OK',
            confirmButtonColor: '#007bff', // Custom blue button color
        });
    } catch (error) {
        // Fallback to the standard alert if SweetAlert fails
        alert(successMessage);
    }
}

async function safeAlertError(errorMessage) {
    try {
        // Using SweetAlert for error alert
        await Swal.fire({
            title: 'Error!',
            text: errorMessage,
            icon: 'error',
            confirmButtonText: 'OK',
            confirmButtonColor: '#007bff', // Custom blue button color
        });
    } catch (error) {
        // Fallback to the standard alert if SweetAlert fails
        alert(errorMessage);
    }
}

async function safeAlertPrompt(promptMessage, inputPlaceholder = '') {
    try {
        // Using SweetAlert for prompt
        const { value } = await Swal.fire({
            title: 'Please provide input',
            text: promptMessage,
            input: 'text',
            inputPlaceholder: inputPlaceholder,
            showCancelButton: true,
            confirmButtonText: 'Submit',
            cancelButtonText: 'Cancel',
            confirmButtonColor: '#007bff', // Custom blue button color
        });

        // If a value is entered, return it; otherwise, return null
        return value || null;
    } catch (error) {
        // Fallback to the standard prompt if SweetAlert fails
        const result = prompt(promptMessage, inputPlaceholder);
        return result ? result : null;
    }
}

/////////////////////////////////////
//// VIEW ACTIVE THESES SECTION ////

let allTheses = [];


document.getElementById('searchInput').addEventListener('input', () => {
    renderActiveTheses(allTheses);
});

document.getElementById('statusFilter').addEventListener('change', () => {
    renderActiveTheses(allTheses);
});

document.getElementById('viewActiveThesesBtn').addEventListener('click', async () => {
    hideAllTheSections();

    const token = localStorage.getItem('token');

    try {
        const response = await fetch('http://localhost:5000/secretariat/activeTheses', {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });

        const data = await response.json();
        // console.log('Active theses:', data);
        allTheses = data;
        renderActiveTheses(data);
    } catch (error) {
        console.error('Error fetching active theses:', error);
        alert('Failed to fetch active theses. Please try again.');
    }
});

function renderActiveTheses(data) {
    const section = document.getElementById('viewActiveThesesSection');
    section.style.display = 'block';

    const thesisList = document.getElementById('thesisList');
    thesisList.innerHTML = '';

    const searchInput = document.getElementById('searchInput').value.toLowerCase();
    const selectedStatus = document.getElementById('statusFilter').value;

    // Filter based on title and status
    const filteredData = data.filter(thesis => {
        const matchesTitle = thesis.title.toLowerCase().includes(searchInput);
        const matchesStatus = selectedStatus === 'all' || thesis.status.toLowerCase() === selectedStatus;
        return matchesTitle && matchesStatus;
    });

    if (filteredData.length === 0) {
        thesisList.innerHTML = '<li>No active theses found.</li>';
        return;
    }

    filteredData.forEach(thesis => {
        const li = document.createElement('li');

        const titleSpan = document.createElement('span');
        titleSpan.textContent = thesis.title;

        li.appendChild(titleSpan);
        li.addEventListener('click', () => openModal(thesis));

        thesisList.appendChild(li);
    });
}


function openModal(thesis) {
    // Fill title, synopsis, status
    document.getElementById('modalThesisTitle').textContent = thesis.title;
    document.getElementById('modalSynopsis').textContent = thesis.synopsis || '—';
    document.getElementById('modalStatus').textContent = thesis.status;
    document.getElementById('timeSinceAssignment').textContent = thesis.time_since_assignment;
    
    const meetingInfoSpan = document.getElementById('modalMeetingInfo');

    if (thesis.meeting_info) {
        const { number, date } = thesis.meeting_info;
        const formattedDate = new Date(date).toLocaleDateString(); 
        meetingInfoSpan.textContent = `#${number} on ${formattedDate}`;
    } else {
        meetingInfoSpan.textContent = '—';
    }

    // PDF file
    const pdfLink = document.getElementById('modalPdfLink');
    if (thesis.pdf_file) {
        pdfLink.href = `http://localhost:5000${thesis.pdf_file}`;
        pdfLink.innerText = 'Download PDF';
    } else {
        pdfLink.innerText = 'No PDF file found.';
        pdfLink.href = '#';
    }

    // Student info
    document.getElementById('modalStudentInfo').textContent = `${thesis.student_name} ${thesis.student_email}`;

    // Professors list
    const profList = document.getElementById('modalProfessorsList');
    profList.innerHTML = '';
    thesis.professors.forEach(prof => {
        const li = document.createElement('li');
        const grade = prof.grade ? prof.grade : 'No grade submitted';
        li.textContent = `${prof.professor_name} ${prof.professor_email} (${prof.role}) Grade: ${grade}`;
        profList.appendChild(li);
    });

    // Management buttons
    const buttonsContainer = document.getElementById('modalManagementButtons');
    buttonsContainer.innerHTML = ''; // Clear previous buttons

    if (thesis.status.toLowerCase() === 'in progress') {
        if (thesis.meeting_info == null) {
            const meetingBtn = document.createElement('button');
            meetingBtn.textContent = 'Enter Meeting Info';
            meetingBtn.onclick = () => handleSetMeetingInfo(thesis.id);
            buttonsContainer.appendChild(meetingBtn);
        }


        const cancelBtn = document.createElement('button');
        cancelBtn.textContent = 'Cancel Assignment';
        cancelBtn.onclick = () => handleCancelAssignment(thesis.id);
        buttonsContainer.appendChild(cancelBtn);
    } else if (thesis.status.toLowerCase() === 'under review') {
        const allGradesSubmitted = thesis.professors.every(
            prof => prof.grade !== null && prof.grade !== undefined
        );
    
        if (allGradesSubmitted && thesis.nimertis_link) {
            const completeBtn = document.createElement('button');
            completeBtn.textContent = 'Mark as Completed';
            completeBtn.onclick = () => handleMarkAsCompleted(thesis.id);
            buttonsContainer.appendChild(completeBtn);
        } else {
            const infoMsg = document.createElement('p');
            infoMsg.textContent = 'All grades must be submitted by the professors, and the nimertis link must be submitted by the student before completion.';
            infoMsg.style.color = '#aa0000'; // optional: red color to indicate a warning
            buttonsContainer.appendChild(infoMsg);
        }
    }    

    // Show modal
    document.getElementById('activeThesisModal').style.display = 'block';
}

document.getElementById('modalCloseBtn').addEventListener('click', () => {
    document.getElementById('activeThesisModal').style.display = 'none';
});

async function handleSetMeetingInfo(thesisId) {
    document.getElementById('activeThesisModal').style.display = 'none';

    const token = localStorage.getItem('token');
    if (!token) {
        await safeAlertError('Authorization token not found.');
        return;
    }

    // Prompt for meeting number
    const meetingNumberInput = await safeAlertPrompt('Enter meeting number:');
    const meetingNumber = parseInt(meetingNumberInput, 10);

    if (isNaN(meetingNumber)) {
        await safeAlertError('Valid meeting number is required.');
        return;
    }

    // Prompt for meeting date
    const meetingDate = await safeAlertPrompt('Enter meeting date (YYYY-MM-DD):');

    if (!meetingDate || isNaN(Date.parse(meetingDate))) {
        await safeAlertError('Valid meeting date is required.');
        return;
    }

    const meetingInfo = {
        number: meetingNumber,
        date: meetingDate
    };

    try {
        const response = await fetch(`http://localhost:5000/secretariat/${thesisId}/setMeetingInfo`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ meeting_info: meetingInfo })
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || 'Failed to update meeting info.');
        }

        await safeAlertSuccess('Meeting info updated successfully!');
        document.getElementById('viewActiveThesesBtn').click();
    } catch (error) {
        await safeAlertError(error.message);
    }
}

async function handleCancelAssignment(thesisId) {
    const confirmed = await safeAlertConfirm('Are you sure you want to cancel this assignment?');

    if (!confirmed) return;

    const token = localStorage.getItem('token');
    if (!token) {
        await safeAlertError('Authorization token not found.');
        return;
    }

    try {
        const response = await fetch(`http://localhost:5000/secretariat/${thesisId}/cancel`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            }
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || 'Failed to cancel thesis assignment.');
        }

        await safeAlertSuccess('Thesis assignment canceled successfully.');
        document.getElementById('viewActiveThesesBtn').click(); // reveal first option by default
    } catch (error) {
        await safeAlertError(error.message);
    }
}

// Assuming you're using Fetch API in the frontend to make the PUT request
async function handleMarkAsCompleted(thesisId) {
    let confirmation = await safeAlertConfirm('Are you sure you want to mark this thesis as completed?')
    if (!confirmation) {
        return;
    }
    try {
        const token = localStorage.getItem('token');  // Assuming the token is stored in localStorage

        const response = await fetch(`http://localhost:5000/secretariat/${thesisId}/complete`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`,  // Sending the token for authorization
            },
        });

        if (response.ok) {
            const data = await response.json();
            console.log("Thesis marked as completed:", data);
            await safeAlertSuccess("Thesis successfully marked as completed!");
            document.getElementById('viewActiveThesesBtn').click();
        } else {
            const errorData = await response.json();
            console.error("Error:", errorData);
            await safeAlertError("Failed to mark the thesis as completed.");
        }
    } catch (error) {
        console.error("An error occurred:", error);
        await safeAlertError("Error marking thesis as completed.");
    }
};

//////////////////////////////////
//// ENTER USER INFO SECTION ////
document.getElementById('enterUserInfoBtn').onclick = () => {
    hideAllTheSections();
    document.getElementById('enterUserInfoSection').style.display = 'block';
};

let createdUsers = []; // store temporarily for download

document.getElementById('submitUserJson').addEventListener('click', async () => {
    const fileInput = document.getElementById('userJsonUpload');
    const status = document.getElementById('uploadStatus');
    const file = fileInput.files[0];

    if (!file) {
        status.textContent = 'Please select a JSON file first.';
        status.style.color = 'red';
        return;
    }

    try {
        const text = await file.text();
        const jsonData = JSON.parse(text);

        // Validate...
        const requiredFields = ['name', 'email', 'role'];
        const validRoles = ['professor', 'student'];
        const invalidUsers = [];

        jsonData.forEach((user, index) => {
            const missingFields = requiredFields.filter(field => !user[field]);
            if (missingFields.length > 0 || !validRoles.includes(user.role)) {
                invalidUsers.push({ index, missingFields });
            }
        });

        if (invalidUsers.length > 0) {
            status.textContent = `Invalid data at user index(es): ${invalidUsers.map(u => u.index).join(', ')}`;
            status.style.color = 'red';
            return;
        }

        const token = localStorage.getItem('token');
        if (!token) {
            status.textContent = 'Authorization token not found in localStorage.';
            status.style.color = 'red';
            return;
        }

        const response = await fetch('http://localhost:5000/secretariat/createUsers', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify(jsonData)
        });

        const result = await response.json();

        if (!response.ok) {
            throw new Error(result.message || 'Server error');
        }

        // Filter created users only
        createdUsers = result.results.filter(user => user.status === 'success');

        if (createdUsers.length > 0) {
            document.getElementById('userCreationResult').style.display = 'block';
        }

        status.textContent = 'Users uploaded successfully!';
        status.style.color = 'green';

    } catch (err) {
        console.error('Error submitting JSON:', err);
        status.textContent = `Upload failed: ${err.message}`;
        status.style.color = 'red';
    }
});

document.getElementById('downloadUserJson').addEventListener('click', (event) => {
    event.preventDefault(); // Prevent the default action (which might be a redirect)
    if (createdUsers.length === 0) return;

    const blob = new Blob([JSON.stringify(createdUsers, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);

    const link = document.createElement('a');
    link.href = url;
    link.download = 'created_users.json';
    link.click();
    document.body.removeChild(link);  // Clean up by removing the link after download

    URL.revokeObjectURL(url);
});