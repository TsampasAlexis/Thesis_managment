window.addEventListener('load', checkLoginAndRedirect);

// Check login status on the dashboard page
function checkLoginAndRedirect() {
    if (!isLoggedIn()) {
        window.location.href = 'index.html'; // Redirect to login page if not logged in
    } else {
      // User is logged in, now show the role-based content
        const username = localStorage.getItem('username');
        document.querySelector('#profile span').innerText = `Welcome, ${username}`;
        displayDashboardContent();
    }
}

// function to check if the user is logged in by looking for the token in localStorage
function isLoggedIn() {
    const token = localStorage.getItem('token');
    return token ? true : false;
}

// Function to display content based on user role
async function displayDashboardContent() {
    const role = localStorage.getItem('role');

    // Show the relevant section based on role
    if (role === 'professor') {
      return;
    } else {
        window.location.href = 'index.html'
    }
}

function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('role');
    localStorage.removeItem('roleId');

    fetch('http://localhost:5000/logout', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        }
    })
    .then(response => response.json())
    .then(data => {
        // Handle the response, like updating the UI or redirecting
        // console.log(data.message);
        window.location.href = 'index.html';  // Redirect to login page
    })
    .catch(error => {
        console.error('Error logging out:', error);
    });
}