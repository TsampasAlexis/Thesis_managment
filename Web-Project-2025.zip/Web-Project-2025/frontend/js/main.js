// function to check if the user is logged in by looking for the token in localStorage
function isLoggedIn() {
  const token = localStorage.getItem('token');
  return token ? true : false;
}

window.addEventListener('load', updateUIBasedOnLoginStatus); //καλουμε μεθοδο addEventListener στο παραθυρο & load updateUIBasesOnLoginStatus 

// Function to manage UI elements based on login status
function updateUIBasedOnLoginStatus() {
  if (isLoggedIn()) {
    document.getElementById('loginSection').style.display = 'none';
    document.getElementById('logoutButton').style.display = 'inline';
  } else {
    document.getElementById('loginSection').style.display = 'block';
    document.getElementById('logoutButton').style.display = 'none';
  }
  initAnnouncementsSection();
}

function initAnnouncementsSection() {
  const filterSelect = document.getElementById('announcementTimeFilter');
  const announcementsList = document.getElementById('announcementsList');
  const modal = document.getElementById('announcementViewModal');
  const closeModalBtn = document.getElementById('announcementViewCloseBtn');
  const modalTitle = document.getElementById('announcementModalTitle');
  const modalDate = document.getElementById('announcementModalDate');
  const modalText = document.getElementById('announcementModalText');

  if (!filterSelect || !announcementsList || !modal || !closeModalBtn) { //Προστασια απο σφαλματα στο DOM=Document Object Model
    console.warn('Announcements section or modal not found in DOM.');
    return;
  }

  filterSelect.addEventListener('change', () => { //ξαναφορτωνει το filterSelect με καθε επιλογη 
    fetchAnnouncements(filterSelect.value);
  });

  closeModalBtn.addEventListener('click', () => { //κλεισιμο modal με Χ
    modal.style.display = 'none';
  });

  window.addEventListener('click', (e) => { //Αν πατησω οπουδηποτε αλλου κλεινει το modal που εχει ανακοινωση
    if (e.target === modal) {
      modal.style.display = 'none';
    }
  });

  fetchAnnouncements('all'); //ζητα την εμφανιση των  ανακοινωσεων

  async function fetchAnnouncements(timeFilter) {
    try {
      const url = new URL('http://localhost:5000/public/announcements');
      const now = new Date();
      let fromDate = null;

      switch (timeFilter) {
        case 'today':
          fromDate = new Date();
          fromDate.setHours(0, 0, 0, 0);
          break;
        case 'week':
          fromDate = new Date();
          fromDate.setDate(fromDate.getDate() - 7);
          break;
        case 'month':
          fromDate = new Date();
          fromDate.setMonth(fromDate.getMonth() - 1);
          break;
        case 'year':
          fromDate = new Date();
          fromDate.setFullYear(fromDate.getFullYear() - 1);
          break;
      }

      if (fromDate) {
        url.searchParams.set('from', fromDate.toISOString()); //Παιρνει την ημερομηνια και την κανει"2025-09-11T00:00:00.000Z") 
      }

      const res = await fetch(url); //κανουμε HTTP request ΣΤΟ URL
      if (!res.ok) throw new Error('Failed to load announcements'); //ΑΝ δεν ειναι οκ η απαντηση βγαζει ERROR
      const announcements = await res.json();//ΑΝ ειναι ΟΚ διαβαζει το json(ARRAY)

      announcementsList.innerHTML = ''; //καθαρισμα λιστας

      if (announcements.length === 0) {
        announcementsList.innerHTML = '<li>No announcements found.</li>'; // Αν ειναι κενο βγαζει μνμ
        return;
      }

      announcements.forEach(item => {                 //φτιαχνει λιστα ανακοινωσεων
        const li = document.createElement('li'); //Δημιουργει καινουριο HTML στοιχειο
        li.classList.add('announcement-item'); // Προσθετει στη λιστα το CSS class annoucnment-item
        li.style.cursor = 'pointer';   //clikable item(χερακι)
        li.innerHTML = `
          <strong>${item.title}</strong> <span style="color: #888;">(${new Date(item.created_at).toLocaleDateString()})</span>
        `;  //Strong=Εντονη γραφη/${item}:JS κωδικας για ονομα διπλωματικης

        li.addEventListener('click', () => {  //Οταν πατησω σο li θα τρεξει η συναρτηση click
          modalTitle.textContent = item.title; //Βάζει τον τίτλο της ανακοίνωσης στο modal.
          modalDate.textContent = new Date(item.created_at).toLocaleDateString();
          modalText.innerHTML = item.text.replace(/\n/g, '<br>'); //αλλαγη γραμμης
          modal.style.display = 'block'; //εμφανισει modal
        });

        announcementsList.appendChild(li); // παιρνει ετοιμο <li> και το βαζει στην λιστα announcementsList
      });
    } catch (err) {
      console.error('Error fetching announcements:', err);
      announcementsList.innerHTML = '<li>Could not load announcements.</li>'; //Αν αποτυχει το fetch,log στο console και update UI
    }
  }
}

// Δενει submit handler στη φορμα login
document.getElementById('loginForm').addEventListener('submit', async (event) => {
  event.preventDefault(); // Prevent the form from reloading the page
  const username = document.getElementById('loginUsername').value;
  const password = document.getElementById('loginPassword').value;

  if (!username || !password) {
      document.getElementById('loginStatus').innerText = 'Please enter both username and password.';
      return;
  }

  const loginData = { username, password };

  try {
    const response = await fetch('http://localhost:5000/login', { //request http backend
      method: 'POST', //μεθοδος να στειλω data στο internet
      headers: { 'Content-Type': 'application/json' }, //Ενημερωνουμε το server οτι στελνουμε JSON ΜΟΡΦΗ
      body: JSON.stringify(loginData)
    });

    if (response.ok) {
      const result = await response.json();
      const token = result.token;
      const role = result.role;  // Get the role from the response
      const roleId = result.roleId;  // Get the roleId from the response
      const username = result.username
      
      // Store the token, role,username and roleId in localStorage
      localStorage.setItem('token', token);
      localStorage.setItem('username', username);
      localStorage.setItem('role', role); 
      if (roleId) {
        localStorage.setItem('roleId', roleId);  // Store the roleId for later use
      }
      

      // Clear the login form fields
      document.getElementById('loginUsername').value = '';
      document.getElementById('loginPassword').value = '';
      document.getElementById('loginStatus').innerText = 'Login successful!'; //μνμ επιτυχους συνδεσης
      
      if (role === 'student' ) {
        window.location.href = 'studentDashboard.html';  // Redirect to the studentdashboard page

      } else if (role === 'professor') {
        window.location.href = 'professorDashboard.html'; //professorDashboard
      } else if (role === 'secretariat') {
        
        window.location.href = 'secretariatDashboard.html'; //secretariatDashboard
      }
      
      
    } else {
      const error = await response.json();  //αποτυχια login απο backend
      document.getElementById('loginStatus').innerText = 'Error: ' + error.message;
    }
  } catch (error) {                         //σφαλμα στο δικτυο(serverdown)
    console.error('Error:', error);
    document.getElementById('loginStatus').innerText = 'An error occurred during login.';
  }
});

// Handle Logout
document.getElementById('logoutButton').addEventListener('click', () => {
  // clear local storage
  localStorage.removeItem('token'); //Σβηνει τα στοιχεια τησ συνδεσης
  localStorage.removeItem('role');
  localStorage.removeItem('roleId');
  localStorage.removeItem('username');

  document.getElementById('loginStatus').innerText = '';  //Καθαριζει απο loginStatus

  // Send a request to the backend to logout (clear the session)
  fetch('http://localhost:5000/logout', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    }
  })
    .then(response => response.json()) //μετατροπη απαντησης σε JSON
    .then(data => {
      
      console.log(data.message); //μνμ οτι αποσυνδεθηκε του backend
      updateUIBasedOnLoginStatus(); // Update UI after logout
      // window.location.href = 'index.html'; // redirect for pages other than index
    })
    .catch(error => {
      console.error('Error logging out:', error); //Αν υπαρξει error στο logged out πχ κακο JSON/server down
    });
});