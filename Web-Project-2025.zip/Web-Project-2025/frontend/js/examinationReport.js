document.addEventListener('DOMContentLoaded', async () => {
    const token = localStorage.getItem('token');
    const thesisId = localStorage.getItem('thesisId');
    const role = localStorage.getItem('role'); // 'student', 'secretariat', etc.
  
    if (!token || !thesisId) {
      alert('Missing token or thesis ID. Please log in again.');
      return;
    }
  
    try {
      const response = await fetch(`http://localhost:5000/${role}/${thesisId}/examinationReport`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
  
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to fetch examination report.');
      }
  
      const data = await response.json();
      console.log('Examination report data:', data);
  
      renderExaminationReportData(data)
    } catch (err) {
      console.error('Error fetching examination report:', err);
      alert('An error occurred while loading the examination report.');
    }
  });

  function renderExaminationReportData(data) {
    // Destructure necessary data
    const { thesis, professors, presentation_details } = data;

    
    document.getElementById('meetingRoom').textContent = presentation_details.presentation_location || presentation_details.presentation_link;
    document.getElementById('meetingDate').textContent = formatDateTime(presentation_details.presentation_datetime);
    document.getElementById('meetingDay').textContent = formatDay(presentation_details.presentation_datetime);
    document.getElementById('meetingTime').textContent = formatTime(presentation_details.presentation_datetime);
    document.getElementById('appointmentMeetingNumber').textContent = thesis.meeting_info.number;

    // Assigning professors' names to the list items
    document.getElementById('member1').textContent = professors[0].professor_name;
    document.getElementById('member2').textContent = professors[1].professor_name;
    document.getElementById('member3').textContent = professors[2].professor_name;


    // 2. Fill thesis and student information
    document.getElementById('studentName').textContent = thesis.student_name;
    document.getElementById('thesisTitleLine1').textContent = thesis.title.split(' ').slice(0, Math.ceil(thesis.title.split(' ').length / 2)).join(' ');
    document.getElementById('thesisTitleLine2').textContent = thesis.title.split(' ').slice(Math.ceil(thesis.title.split(' ').length / 2)).join(' ');

    // 3. Fill supervisor name (find the professor with the role 'supervisor')
    const supervisor = professors.find(prof => prof.role === 'supervisor');
    if (supervisor) {
        document.getElementById('supervisorName').textContent = supervisor.professor_name;
        document.getElementById('rapporteurName').textContent = supervisor.professor_name;
    } else {
        document.getElementById('supervisorName').textContent = 'N/A';
    }
    document.getElementById('studentNameRepeat').textContent = thesis.student_name;

    // 4. Fill members of the committee (sorted alphabetically)
    const sortedProfessors = professors.sort((a, b) => a.professor_name.localeCompare(b.professor_name));
    console.log(sortedProfessors);
    
    // Assigning professors' names to the list items
    document.getElementById('vote1').textContent = sortedProfessors[0].professor_name;
    document.getElementById('vote2').textContent = sortedProfessors[1].professor_name;
    document.getElementById('vote3').textContent = sortedProfessors[2].professor_name;

    // 5. Fill final grade and vote
    const finalGrade = calculateAverageGrade(professors);
    document.getElementById('finalGrade').textContent = finalGrade;
    document.getElementById('finalGradeRepeat').textContent = finalGrade;

    // 6. Fill grading table with each professor's grade
    professors.forEach((professor, index) => {
        const gradeNameCell = document.getElementById(`gradeName${index + 1}`);
        const gradeRoleCell = document.getElementById(`gradeRole${index + 1}`);
        const gradeScoreCell = document.getElementById(`gradeScore${index + 1}`);

        gradeNameCell.textContent = professor.professor_name;
        gradeRoleCell.textContent = professor.role;
        gradeScoreCell.textContent = professor.grade;
    });

    // 7. Fill student's name for final statement
    document.getElementById('studentNameApproval').textContent = thesis.student_name;
    document.getElementById('studentNameGrade').textContent = thesis.student_name;
    document.getElementById('studentNameDiploma').textContent = thesis.student_name;
}

// Helper functions
function formatDateTime(dateTimeString) {
    const date = new Date(dateTimeString);
    return date.toLocaleDateString();
}

function formatDay(dateTimeString) {
    const date = new Date(dateTimeString);
    return date.toLocaleString('en-us', { weekday: 'long' });
}

function formatTime(dateTimeString) {
    const date = new Date(dateTimeString);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

function calculateAverageGrade(professors) {
    const grades = professors.map(professor => parseFloat(professor.grade));
    const sum = grades.reduce((acc, grade) => acc + grade, 0);
    return (sum / grades.length).toFixed(2);
}
  