const bcrypt = require('bcrypt');
const pool = require('../db/db');  // DB connection

const saltRounds = 10;

// Register user function
const registerUser = async (req, res) => {
  const { username, password, name, email, role } = req.body;
  // Log the incoming data to see what you're receiving

  try {
    // Hash the password
    const hashedPassword = await bcrypt.hash(password, saltRounds);

    // Store the user in the database
    const result = await pool.query(
      'INSERT INTO users (username, password, name, email, role) VALUES ($1, $2, $3, $4, $5) RETURNING id',
      [username, hashedPassword, name, email, role]
    );

    res.status(201).json({ message: 'User registered successfully!', userId: result.rows[0].id });
  } catch (error) {
    res.status(500).json({ message: 'Error registering user', error: error.message });
  }
}

const createUsers = async (req, res) => {
  const users = req.body;

  if (!Array.isArray(users)) {
      return res.status(400).json({ message: 'Expected an array of users in request body.' });
  }

  const results = [];

  for (const user of users) {
      const { name, email, role } = user;

      if (!name || !email || !role || !['professor', 'student'].includes(role)) {
          results.push({ email, status: 'failed', reason: 'Missing or invalid fields' });
          continue;
      }

      try {
          // Generate unique username
          const username = await generateUniqueUsername(name);

          const password = generateRandomPassword(); // Generate the raw password
          // Hash password
          const hashedPassword = await bcrypt.hash(password, saltRounds);

          // Insert user
          const userResult = await pool.query(
              'INSERT INTO users (username, password, name, email, role) VALUES ($1, $2, $3, $4, $5) RETURNING id',
              [username, hashedPassword, name, email, role]
          );

          const userId = userResult.rows[0].id;

          // Insert into role-specific table
          if (role === 'student') {
              await pool.query('INSERT INTO students (user_id) VALUES ($1)', [userId]);
          } else {
              await pool.query('INSERT INTO professors (user_id) VALUES ($1)', [userId]);
          }

          results.push({ email, username, password, status: 'success'});

      } catch (error) {
          console.error(`Error creating user ${email}:`, error.message);
          results.push({ email, status: 'failed', reason: error.message });
      }
  }

  return res.status(207).json({
      message: 'User creation process complete',
      results
  });
};

function generateRandomPassword(length = 12) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()-_=+[]{}';
    let password = '';
    for (let i = 0; i < length; i++) {
        const randIndex = Math.floor(Math.random() * chars.length);
        password += chars[randIndex];
    }
    return password;
}


const generateUniqueUsername = async (name) => {
  const base = name.toLowerCase().replace(/\s+/g, '_').replace(/[^\w]/g, '');
  let username;
  let isUnique = false;
  let attempts = 0;

  while (!isUnique && attempts < 100) {
      const suffix = Math.floor(1000 + Math.random() * 9000); // 4-digit random
      username = `${base}_${suffix}`;

      const existing = await pool.query(
          'SELECT 1 FROM users WHERE username = $1',
          [username]
      );

      if (existing.rowCount === 0) {
          isUnique = true;
      }

      attempts++;
  }

  if (!isUnique) {
      throw new Error('Unable to generate a unique username. Try again.');
  }

  return username;
};


module.exports = { registerUser, createUsers };