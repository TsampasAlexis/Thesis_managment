const path = require('path');
const fs = require('fs');
const pool = require('../db/db'); // Database setup for interaction (PostgreSQL pool)
const { v4: uuidv4 } = require('uuid'); // For generating unique file names (optional but recommended)

/////////////////////////////////////////
//// ROUTES FOR INITIALIZING THESIS ////
const createThesis = async (req, res) => {
  const { title, synopsis, professor_id } = req.body;

  // Check if the professor is making the request (we already ensure professor role in the middleware)
  if (!title) {
    return res.status(400).json({ message: 'Title is required.' });
  }

  // Handle PDF file upload (if provided)
  let pdfFilePath = null;
  if (req.files && req.files.pdf_file) {
    const pdfFile = req.files.pdf_file;
    const fileExtension = path.extname(pdfFile.name); // e.g., '.pdf'
    const fileName = `${uuidv4()}${fileExtension}`; // Create unique file name
    const uploadPath = path.join(__dirname, '../uploads/pdfs', fileName); // Path where we save the PDF

    try {
      // Ensure the folder exists, otherwise create it
      if (!fs.existsSync(path.join(__dirname, '../uploads/pdfs'))) {
        fs.mkdirSync(path.join(__dirname, '../uploads/pdfs'), { recursive: true });
      }

      // Move the uploaded file to the server directory
      pdfFile.mv(uploadPath, (err) => {
        if (err) {
          return res.status(500).json({ message: 'Error uploading file.' });
        }
      });

      // Set the PDF file path to store in the database
      pdfFilePath = `/uploads/pdfs/${fileName}`;
    } catch (err) {
      return res.status(500).json({ message: 'Error processing the PDF file.' });
    }
  }

  // Insert the new thesis into the database
  try {
    const query = `
      INSERT INTO theses (title, synopsis, pdf_file, professor_id)
      VALUES ($1, $2, $3, $4)
      RETURNING *;
    `;
    const values = [title, synopsis, pdfFilePath, professor_id];
    
    // Execute the query using pool.query
    const result = await pool.query(query, values); // Use pool.query, not db.query
    const newThesis = result.rows[0];

    return res.status(201).json({ message: 'Thesis created successfully.', thesis: newThesis });
  } catch (err) {
    console.error('Error inserting thesis:', err);
    return res.status(500).json({ message: 'Error creating thesis.' });
  }
};

// Get list of theses with status 'to be assigned' for the logged-in professor
const getThesesToBeAssigned = async (req, res) => {
  const professorId = req.user.roleId;  // Professor's roleId should be in the request (from login)

  try {
    // Query to get theses where the status is 'to be assigned' and the professor_id matches the logged-in user
    const query = `
      SELECT id, title, status, synopsis, pdf_file
      FROM theses
      WHERE professor_id = $1 AND status = 'to be assigned';
    `;
    
    const result = await pool.query(query, [professorId]);

    // If no theses found, return an empty array or message
    if (result.rows.length === 0) {
      return res.status(200).json({ message: 'No theses to be assigned.' });
    }

    // Return the list of theses
    return res.status(200).json(result.rows);
  } catch (err) {
    console.error('Error fetching theses:', err);
    return res.status(500).json({ message: 'Error fetching theses.' });
  }
};

// Update thesis details
const editThesis = async (req, res) => {
  const { id } = req.params;  // Thesis ID from the URL
  let { title, synopsis, oldPdfPath, pdfChanged } = req.body;

  // Log the raw data coming from the frontend
  // console.log('oldpath:', oldPdfPath, typeof oldPdfPath);
  // console.log('pdfChanged:', pdfChanged, typeof pdfChanged);

  // Convert oldPdfPath to null if it's 'null' as a string
  if (oldPdfPath === 'null') {
    oldPdfPath = null;
  }

  // Convert pdfChanged to a boolean (it will come as a string from FormData)
  if (pdfChanged === 'true') {
    pdfChanged = true;
  } else if (pdfChanged === 'false') {
    pdfChanged = false;
  }

  // console.log('Converted oldPath:', oldPdfPath, typeof oldPdfPath);
  // console.log('Converted pdfChanged:', pdfChanged, typeof pdfChanged);

  let pdfFile = req.files ? req.files.pdf_file : null;  // Extract the PDF file if present, otherwise set to null
  
    // Check if the thesis exists
    try {
      const checkQuery = 'SELECT id FROM theses WHERE id = $1';
      const checkResult = await pool.query(checkQuery, [id]);
      const thesis = checkResult.rows[0];
  
      if (!thesis) {
        return res.status(404).json({ message: 'Thesis not found.' });
      }
  
      // Handle PDF file logic if pdfChanged is true
      let pdfFilePath = oldPdfPath; // Default to oldPdfPath if no changes

      if (pdfChanged) {
          // Case 1: Old PDF path is null, and the user added a new PDF
          if (!oldPdfPath && pdfFile) {
              const fileExtension = path.extname(pdfFile.name);  // e.g., '.pdf'
              const fileName = `${uuidv4()}${fileExtension}`; // Unique file name
              const uploadPath = path.join(__dirname, '../uploads/pdfs', fileName);  // Save path on server

              // Move the uploaded PDF file to the server directory
              await pdfFile.mv(uploadPath);

              // Set the new PDF file path for the database
              pdfFilePath = `/uploads/pdfs/${fileName}`;
          }

          // Case 2: Old PDF path is not null
          else if (oldPdfPath) {
              // Case a: The user changed the PDF file
              if (pdfFile) {
                  // Delete the old PDF file
                  const oldPdfPathResolved = path.join(__dirname, '..', oldPdfPath);
                  if (fs.existsSync(oldPdfPathResolved)) {
                      fs.unlinkSync(oldPdfPathResolved);  // Delete the old file
                  }

                  // Handle the new PDF file
                  const fileExtension = path.extname(pdfFile.name);  // e.g., '.pdf'
                  const fileName = `${uuidv4()}${fileExtension}`; // Unique file name
                  const uploadPath = path.join(__dirname, '../uploads/pdfs', fileName);  // Save path on server

                  // Move the uploaded PDF file to the server directory
                  await pdfFile.mv(uploadPath);

                  // Set the new PDF file path for the database
                  pdfFilePath = `/uploads/pdfs/${fileName}`;
              }

              // Case b: The user removed the PDF file
              else {
                  // Delete the old PDF file from the server
                  const oldPdfPathResolved = path.join(__dirname, '..', oldPdfPath);
                  if (fs.existsSync(oldPdfPathResolved)) {
                      fs.unlinkSync(oldPdfPathResolved);  // Delete the old file
                  }

                  // Set the PDF path to null in the database
                  pdfFilePath = null;
              }
          }
      }
  
      // Update the thesis details in the database
      const query = `
        UPDATE theses
        SET title = $1, synopsis = $2, pdf_file = $3, updated_at = NOW()
        WHERE id = $4
        RETURNING *;
      `;
      const values = [title, synopsis, pdfFilePath, id];
  
      const result = await pool.query(query, values);
      const updatedThesis = result.rows[0];
  
      return res.status(200).json({ message: 'Thesis updated successfully.', thesis: updatedThesis });
    } catch (err) {
      console.error('Error updating thesis:', err);
      return res.status(500).json({ message: 'Error updating thesis.' });
    }
};

///////////////////////////////////////////////
//// ROUTES FOR INITIAL THESIS ASSIGNMENT ////

//Function to search for students by name or ID
const searchStudents = async (req, res) => {
  const { query } = req.query; // The search term from the query string

  try {
    let result;

    // Check if the query is a number (integer)
    if (!isNaN(query)) {
      // Search by ID if query is numeric
      const searchQueryById = `
        SELECT u.name, s.id AS student_id, s.student_number AS student_number  -- Select name from users, student_id from students
        FROM users u
        JOIN students s ON u.id = s.user_id  -- Join users and students based on user_id
        WHERE u.role = 'student' AND s.student_number = $1
      `;
      result = await pool.query(searchQueryById, [parseInt(query)]);
    } else {
      // Search by name if query is not numeric
      const searchQueryByName = `
        SELECT u.name, s.id AS student_id  -- Select name from users, student_id from students
        FROM users u
        JOIN students s ON u.id = s.user_id  -- Join users and students based on user_id
        WHERE u.role = 'student' AND u.name ILIKE $1
      `;
      result = await pool.query(searchQueryByName, [`%${query}%`]);
    }

    // Check if no students were found
    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'No students found' });
    }

    return res.status(200).json(result.rows);
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Failed to search for students' });
  }
}

// Function to assign a thesis to a student temporarily
const assignThesisToStudent = async (req, res) => {
  const thesis_id = req.params.id;
  const { student_id } = req.body; // The student to whom the thesis is being assigned

  try {
    // Check if the thesis is already assigned
    const thesisQuery = 'SELECT * FROM theses WHERE id = $1';
    const thesisResult = await pool.query(thesisQuery, [thesis_id]);

    if (thesisResult.rows.length === 0) {
      return res.status(404).json({ error: 'Thesis not found' });
    }

    const thesis = thesisResult.rows[0];

    // If the thesis is already assigned, prevent reassignment
    if (thesis.student_id !== null) {
      return res.status(400).json({ error: 'Thesis is already assigned to a student' });
    }

    const updateQuery = `
      UPDATE theses
      SET student_id = $1, status = $2, updated_at = NOW()
      WHERE id = $3
      RETURNING *`;

    const updatedThesis = await pool.query(updateQuery, [student_id, 'assigned', thesis_id]);

    return res.status(200).json({ message: 'Thesis assigned temporarily', thesis: updatedThesis.rows[0] });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Failed to assign thesis' });
  }
}

//////////////////////////////////////////
//// ROUTES FOR CANCELING ASSIGNMENT ////

const getAssignedTheses = async (req, res) => {
  const professorId = req.user.roleId;  // Professor's roleId should be in the request (from login)
  try {
    // Query to get theses where the status is 'assigned' (but not finalized) and the professor_id matches the logged-in user
    const query = `
      SELECT id, title, status, synopsis, pdf_file
      FROM theses
      WHERE professor_id = $1 AND status = 'assigned';
    `;
    
    const result = await pool.query(query, [professorId]);

    // If no theses found, return an empty array or message
    if (result.rows.length === 0) {
      return res.status(200).json({ message: 'No theses assigned yet.' });
    }

    // Return the list of assigned theses
    return res.status(200).json(result.rows);
  } catch (err) {
    console.error('Error fetching assigned theses:', err);
    return res.status(500).json({ message: 'Error fetching assigned theses.' });
  }
};

// Function to cancel thesis assignment
const cancelThesisAssignment = async (req, res) => {
  const thesis_id = req.params.id;

  try {
    // Check if the thesis exists and is assigned temporarily
    const thesisQuery = 'SELECT * FROM theses WHERE id = $1';
    const thesisResult = await pool.query(thesisQuery, [thesis_id]);

    if (thesisResult.rows.length === 0) {
      return res.status(404).json({ error: 'Thesis not found' });
    }

    const thesis = thesisResult.rows[0];

    // Ensure the thesis is assigned temporarily
    if (thesis.status !== 'assigned') {
      return res.status(400).json({ error: 'Thesis cannot be canceled as it is not assigned' });
    }

    // Start a transaction to ensure all operations succeed or fail together
    await pool.query('BEGIN');

    // 1. Update thesis status and student_id to NULL (as it is canceled)
    const updateQuery = `
      UPDATE theses
      SET student_id = NULL, status = $1, updated_at = CURRENT_TIMESTAMP
      WHERE id = $2
      RETURNING *`;
    const updatedThesis = await pool.query(updateQuery, ['to be assigned', thesis_id]);

    // 2. Delete from thesis_professor_relationship where thesis_id and role NOT 'supervisor'
    const deleteProfessorsQuery = `
      DELETE FROM thesis_professor_relationship
      WHERE thesis_id = $1 AND role != 'supervisor'
      RETURNING *`;
    await pool.query(deleteProfessorsQuery, [thesis_id]);

    // 3. Delete from committee_invitations where thesis_id
    const deleteInvitationsQuery = `
      DELETE FROM committee_invitations
      WHERE thesis_id = $1
      RETURNING *`;
    await pool.query(deleteInvitationsQuery, [thesis_id]);

    // Commit the transaction
    await pool.query('COMMIT');

    return res.status(200).json({ message: 'Thesis assignment canceled', thesis: updatedThesis.rows[0] });
  } catch (error) {
    // Rollback the transaction in case of an error
    await pool.query('ROLLBACK');
    console.error(error);
    return res.status(500).json({ error: 'Failed to cancel thesis assignment' });
  }
};

///////////////////////////////////////////
//// ROUTES FOR VIEW MY THESES OPTION ////

// Controller function to get professor's theses
const getProfessorsTheses = async (req, res) => {
  const professor_id = req.headers['professor_id']; // Get professor_id from the headers
  const { role, status, limit, offset } = req.query; // Extract query parameters (limit, offset, etc.)

  // Convert limit and offset to integers
  let limitInt = parseInt(limit, 10);  // Convert to integer
  let offsetInt = parseInt(offset, 10); // Convert to integer

  // Check for invalid limit or offset values (they should be numbers)
  if (isNaN(limitInt)) limitInt = 10;  // Default to 10 if limit is invalid
  if (isNaN(offsetInt)) offsetInt = 0; // Default to 0 if offset is invalid

  try {
       // Construct the base query to fetch theses
      let query = `
      SELECT t.id AS thesis_id, t.title, t.status, tpr.role, t.grading
      FROM theses t
      JOIN thesis_professor_relationship tpr ON t.id = tpr.thesis_id
      WHERE tpr.professor_id = $1
      `;

      const queryParams = [professor_id];

      // Initialize position for role and status, starting after professor_id (which is $1)
      let paramCount = 2; // Starting position for the next parameter

      // Apply filters based on role and status
      if (role && role !== 'all') {
        query += ` AND tpr.role = $${paramCount}`;
        queryParams.push(role); // Supervisor or committee member
        paramCount++;
      }

      if (status && status !== 'all') {
        query += ` AND t.status = $${paramCount}`;
        queryParams.push(status); // Status of the thesis (e.g., 'under review', 'approved')
        paramCount++;
      }

      // Add pagination (limit and offset)
      query += ` LIMIT $${paramCount} OFFSET $${paramCount + 1}`;
      queryParams.push(limitInt, offsetInt); // Pass the integer values of limit and offset

       // Execute the query
      const result = await pool.query(query, queryParams);


      // Check if any theses were found
      if (result.rows.length === 0) {
          return res.status(404).json({ message: 'No theses found for this professor.' });
      }

      // Send the response with the fetched theses
      return res.status(200).json(result.rows);
  } catch (error) {
      console.error('Error fetching professor theses:', error);
      return res.status(500).json({ message: 'Server error' });
  }
};

const getThesisDetails = async (req, res) => {
  const { thesis_id } = req.params;  // Get thesis_id from route params

  try {
      // Query to fetch thesis details with professors (no status history)
      const thesisResult = await pool.query(
          `SELECT 
              t.id, t.title, t.synopsis, t.pdf_file, t.status, t.created_at, t.updated_at, 
              t.student_id, s.user_id AS student_user_id, u_student.name AS student_name, u_student.email AS student_email,
              -- Get professors
              json_agg(
                  json_build_object(
                      'professor_id', tpr.professor_id,
                      'role', tpr.role,
                      'professor_name', u_professor.name,
                      'professor_email', u_professor.email
                  )
              ) AS professors
          FROM theses t
          LEFT JOIN students s ON t.student_id = s.id
          LEFT JOIN users u_student ON s.user_id = u_student.id
          LEFT JOIN thesis_professor_relationship tpr ON t.id = tpr.thesis_id
          LEFT JOIN professors p ON tpr.professor_id = p.id
          LEFT JOIN users u_professor ON p.user_id = u_professor.id
          WHERE t.id = $1
          GROUP BY t.id, s.user_id, u_student.name, u_student.email`, 
          [thesis_id]
      );

      // Check if thesis exists
      if (thesisResult.rows.length === 0) {
          return res.status(404).json({ message: 'Thesis not found' });
      }

      const thesisDetails = thesisResult.rows[0];

      // Check if the thesis is completed and fetch additional data
      if (thesisDetails.status === 'completed') {
          // Fetch professor grades and nimertis_link if the thesis is completed
          const professorGradesResult = await pool.query(
              `SELECT 
                  tpr.professor_id, 
                  tpr.grade, 
                  tpr.role
              FROM thesis_professor_relationship tpr
              WHERE tpr.thesis_id = $1`, 
              [thesis_id]
          );

          // Fetch nimertis_link from student_submissions
          const nimertisLinkResult = await pool.query(
              `SELECT nimertis_link
              FROM student_submissions
              WHERE thesis_id = $1`, 
              [thesis_id]
          );

          // Attach professor grades to each professor and add nimertis_link to thesis details
          const professorsWithGrades = thesisDetails.professors.map(professor => {
              const professorGrade = professorGradesResult.rows.find(p => p.professor_id === professor.professor_id);
              if (professorGrade) {
                  professor.grade = professorGrade.grade;
              }
              return professor;
          });

          thesisDetails.professors = professorsWithGrades;
          thesisDetails.nimertis_link = nimertisLinkResult.rows.length > 0 ? nimertisLinkResult.rows[0].nimertis_link : null;
      }

      // Query to fetch status history
      const statusResult = await pool.query(
          `SELECT status, updated_at 
          FROM status_history
          WHERE thesis_id = $1
          ORDER BY updated_at`, 
          [thesis_id]
      );

      // Add status history to the thesis details object
      thesisDetails.status_history = statusResult.rows;

      // Return the thesis details along with professors, grades, nimertis_link, and status history
      return res.status(200).json(thesisDetails);

  } catch (error) {
      console.error('Error fetching thesis details:', error);
      return res.status(500).json({ message: 'Server error' });
  }
};

///////////////////////////////////////////
//// ROUTES FOR COMMITTEE INVITATIONS ////

const getCommitteeInvitations = async (req, res) => {
  const professorId = req.params.id;

  if (!professorId) {
    return res.status(400).json({ error: 'Professor ID is required' });
  }

  try {
    // Step 1: Fetch all the required information in one query
    const query = `
      SELECT 
        ci.thesis_id,
        t.title,
        t.professor_id AS supervisor_id,
        t.student_id,
        -- Professor details
        u_professor.name AS professor_name,
        u_professor.email AS professor_email,
        -- Student details
        u_student.name AS student_name,
        u_student.email AS student_email
      FROM committee_invitations ci
      JOIN theses t ON ci.thesis_id = t.id
      -- Professor join
      JOIN professors p ON t.professor_id = p.id
      JOIN users u_professor ON p.user_id = u_professor.id
      -- Student join
      JOIN students s ON t.student_id = s.id
      JOIN users u_student ON s.user_id = u_student.id
      WHERE ci.professor_id = $1
        AND ci.status = 'pending';
    `;
    
    const { rows } = await pool.query(query, [professorId]);

    if (rows.length === 0) {
      return res.status(404).json({ message: 'No pending invitations found for this professor' });
    }

    // Step 2: Send the response with the fetched data
    const result = rows.map((row) => ({
      thesis_id: row.thesis_id,
      title: row.title,
      supervisor: {
        professor_name: row.professor_name,
        professor_email: row.professor_email,
      },
      student: {
        student_name: row.student_name,
        student_email: row.student_email,
      },
    }));

    return res.status(200).json(result);

  } catch (err) {
    console.error('Error fetching committee invitations:', err);
    return res.status(500).json({ error: 'Internal server error' });
  }
};

// Function to handle accepting/rejecting the invitation and updating the thesis-professor relationship
const handleInvitationResponse = async (req, res) => {
  const { thesis_id, professor_id, status } = req.body; // Thesis ID, professor ID, and status ('accepted' or 'rejected') from the request body

  if (!thesis_id || !professor_id || !status) {
      return res.status(400).json({ error: 'Missing required fields' });
  }

  try {
      // Update the invitation status in the committee_invitations table
      const updateInvitationStatusQuery = `
          UPDATE committee_invitations 
          SET status = $1, response_date = NOW()
          WHERE thesis_id = $2 AND professor_id = $3
          RETURNING id;
      `;
      const updateResult = await pool.query(updateInvitationStatusQuery, [status, thesis_id, professor_id]);

      if (updateResult.rows.length === 0) {
          return res.status(404).json({ error: 'Invitation not found or already processed' });
      }

      // Respond with a success message
      res.status(200).json({
          message: `Invitation has been ${status === 'accepted' ? 'accepted' : 'rejected'}.`
      });
  } catch (error) {
      console.error('Error handling invitation response:', error);
      res.status(500).json({ error: 'Failed to process invitation response' });
  }
};

///////////////////////////
//// DYNAMIC FEATURES //// 

// assigned features
const getOtherProfessors = async (req, res) => {
  const { thesis_id, professor_id } = req.query; // Get thesis_id and professor_id from the request query

  if (!thesis_id || !professor_id) {
      return res.status(400).json({ error: 'Thesis ID and Professor ID are required.' });
  }

  try {
      // First Query: Get other professors' details (excluding the input professor_id) and include role
      const professorsQuery = `
          SELECT p.id, u.name, u.email, tpr.role
          FROM thesis_professor_relationship tpr
          JOIN professors p ON p.id = tpr.professor_id
          JOIN users u ON u.id = p.user_id
          WHERE tpr.thesis_id = $1 AND tpr.professor_id != $2;
      `;
      const professorsResult = await pool.query(professorsQuery, [thesis_id, professor_id]);

      // Second Query: Get the committee invitation details
      const invitationsQuery = `
          SELECT ci.professor_id, u.name, u.email, ci.status, ci.invitation_date, ci.response_date
          FROM committee_invitations ci
          JOIN professors p ON p.id = ci.professor_id
          JOIN users u ON u.id = p.user_id
          WHERE ci.thesis_id = $1;
      `;
      const invitationsResult = await pool.query(invitationsQuery, [thesis_id]);

      // If both results are empty, send 404
      if (professorsResult.rows.length === 0 && invitationsResult.rows.length === 0) {
          return res.status(404).json({ error: 'No professors or committee invitations found for this thesis.' });
      }

      // Map the professor results with role and other details
      const otherProfessors = professorsResult.rows.map(prof => ({
          professor_id: prof.professor_id,
          name: prof.name,
          email: prof.email,
          role: prof.role // Include role
      }));

      // Map the invitation results
      const invitations = invitationsResult.rows.map(invite => ({
          professor_id: invite.professor_id,
          name: invite.name,
          email: invite.email,
          status: invite.status,
          invitation_date: invite.invitation_date,
          response_date: invite.response_date
      }));

      // Respond with the data
      res.status(200).json({
          message: 'Other professors and committee invitations fetched successfully.',
          otherProfessors,
          invitations
      });
  } catch (error) {
      console.error('Error fetching data:', error);
      res.status(500).json({ error: 'Internal Server Error' });
  }
};

// in progresss features
const getProfessorNotes = async (req, res) => {
  const { thesis_id, professor_id } = req.query;  // Extract thesis_id and professor_id from query params
  try {
    // Validate input parameters
    if (!thesis_id || !professor_id) {
      return res.status(400).json({ error: 'Thesis ID and Professor ID are required' });
    }
    // Query the database to get the notes for the specified thesis and professor
    const query = `
      SELECT id, title, note, updated_at
      FROM professor_notes
      WHERE thesis_id = $1 AND professor_id = $2
      ORDER BY updated_at DESC
    `;
    
    const result = await pool.query(query, [thesis_id, professor_id]);

    // Check if notes exist for the given thesis and professor
    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'No notes found for this thesis and professor' });
    }

    // Return the notes as a response
    return res.status(200).json({ notes: result.rows });
  } catch (error) {
    console.error('Error fetching professor notes:', error);
    return res.status(500).json({ error: 'Failed to fetch professor notes' });
  }
};

const submitProfessorNote = async (req, res) => {
  const { thesis_id, professor_id } = req.params;  // Get thesis_id and professor_id from route params

  // Ensure the professor has permission and thesis exists
  try {
      // Example logic for inserting a new note
      const { title, note } = req.body;

      const insertQuery = `
          INSERT INTO professor_notes (thesis_id, professor_id, title, note, updated_at)
          VALUES ($1, $2, $3, $4, CURRENT_TIMESTAMP)
          RETURNING *`;
      
      const result = await pool.query(insertQuery, [thesis_id, professor_id, title, note]);

      if (result.rows.length === 0) {
          return res.status(400).json({ message: 'Failed to add note.' });
      }

      return res.status(200).json({ message: 'Note successfully added', note: result.rows[0] });

  } catch (error) {
      console.error("Error adding note:", error);
      res.status(500).json({ message: 'An error occurred while adding the note.' });
  }
};

const updateProfessorNote = async (req, res) => {
  const note_id = req.params.id;
  const { title, note } = req.body; // Get data from request body

  try {
      // Check for note length restriction
      if (note.length > 300) {
          return res.status(400).json({ error: 'Note content must not exceed 300 characters' });
      }

      // Check if the note exists
      const noteQuery = 'SELECT * FROM professor_notes WHERE id = $1';
      const noteResult = await pool.query(noteQuery, [note_id]);

      if (noteResult.rows.length === 0) {
          return res.status(404).json({ error: 'Note not found' });
      }

      // Update the note
      const updateQuery = `
          UPDATE professor_notes
          SET title = $1, note = $2 , updated_at = CURRENT_TIMESTAMP
          WHERE id = $3
          RETURNING *`;
      const updateResult = await pool.query(updateQuery, [title, note, note_id]);

      res.status(200).json({ message: 'Note updated successfully', note: updateResult.rows[0] });
  } catch (error) {
      console.error('Error updating professor note:', error);
      res.status(500).json({ error: 'Failed to update professor note' });
  }
};

const deleteProfessorNote = async (req, res) => {
  const note_id = req.params.id;

  try {
      // Check if the note exists
      const noteQuery = 'SELECT * FROM professor_notes WHERE id = $1';
      const noteResult = await pool.query(noteQuery, [note_id]);

      if (noteResult.rows.length === 0) {
          return res.status(404).json({ error: 'Note not found' });
      }

      // Delete the note
      const deleteQuery = 'DELETE FROM professor_notes WHERE id = $1';
      await pool.query(deleteQuery, [note_id]);

      res.status(200).json({ message: 'Note deleted successfully' });
  } catch (error) {
      console.error('Error deleting professor note:', error);
      res.status(500).json({ error: 'Failed to delete professor note' });
  }
};

// in progress supervisor features

// Function to cancel a thesis by a professor
const cancelThesis = async (req, res) => {
  const thesis_id = req.params.thesis_id;  // Get thesis_id from URL parameter
  const professor_id = req.params.professor_id;  // Get professor_id from URL parameter
  const { meeting_info } = req.body;  // Get meeting_info from the request body

  try {
      // Step 1: Verify if the professor is the owner of the thesis
      const thesisQuery = `
      SELECT * 
      FROM theses 
      WHERE id = $1 AND professor_id = $2
  `;
  const thesisResult = await pool.query(thesisQuery, [thesis_id, professor_id]);

  if (thesisResult.rows.length === 0) {
      throw new Error('Thesis not found or you are not authorized to cancel this thesis');
  }

    const statusHistoryQuery = `
          SELECT updated_at 
          FROM status_history 
          WHERE thesis_id = $1 AND status = 'in progress' 
          ORDER BY updated_at DESC LIMIT 1
      `;
      const statusHistoryResult = await pool.query(statusHistoryQuery, [thesis_id]);

      if (statusHistoryResult.rows.length === 0) {
          throw new Error('No record of thesis being "in progress" found.');
      }

      const statusUpdatedAt = statusHistoryResult.rows[0].updated_at;

      // Check if the "in progress" status was at least 2 years ago
      const twoYearsAgo = new Date();
      twoYearsAgo.setFullYear(twoYearsAgo.getFullYear() - 2);

      if (new Date(statusUpdatedAt) > twoYearsAgo) {
          return res.status(400).json({
              error: 'Thesis cannot be canceled. The status "in progress" must have been set at least two years ago.'
          });
      }

    // Step 2: Update the thesis status to 'cancel' and update the updated_at timestamp
    const updateQuery = `
        UPDATE theses 
        SET status = 'canceled', updated_at = CURRENT_TIMESTAMP 
        WHERE id = $1
        RETURNING *`;
    
    const updateResult = await pool.query(updateQuery, [thesis_id]);

    if (updateResult.rows.length === 0) {
        throw new Error('Failed to update thesis status');
    }

    // Step 3: Insert a new cancellation record into thesis_cancellations
    const insertCancellationQuery = `
        INSERT INTO thesis_cancellations (thesis_id, reason, meeting_info)
        VALUES ($1, $2, $3)
        RETURNING *`;
    
    const insertResult = await pool.query(insertCancellationQuery, [thesis_id, 'canceled by professor', meeting_info]);

    // Step 4: Return the result of the cancellation insertion
    return res.status(200).json({
        message: 'Thesis canceled successfully',
        cancellation: insertResult.rows[0]  // Return the cancellation record
    });

  } catch (error) {
      console.error('Error canceling thesis:', error);
      return res.status(500).json({ error: error.message });
  }
};

const setStatusUnderReview = async (req, res) => {
  const thesis_id = req.params.id;  // Get thesis_id from URL parameter

  try {
      // Step 1: Verify if the professor is the owner of the thesis
      const thesisQuery = `
          SELECT * 
          FROM theses 
          WHERE id = $1
      `;
      const thesisResult = await pool.query(thesisQuery, [thesis_id]);

      if (thesisResult.rows.length === 0) {
          throw new Error('Thesis not found.');
      }
      
      // Step 2: Update the thesis status to 'under review' and update the updated_at timestamp
      const updateQuery = `
          UPDATE theses 
          SET status = 'under review', updated_at = CURRENT_TIMESTAMP 
          WHERE id = $1
          RETURNING *`;
      
      const updateResult = await pool.query(updateQuery, [thesis_id]);

      if (updateResult.rows.length === 0) {
          throw new Error('Failed to update thesis status');
      }

      // Step 3: Return the result of the status update
      return res.status(200).json({
          message: 'The thesis status has been successfully changed to "Under Review".',
          thesis: updateResult.rows[0]  // Return the updated thesis record
      });

  } catch (error) {
      console.error('Error starting the review process:', error);
      return res.status(500).json({ error: error.message });
  }
};

// UNDER REVIEW FEATURES //
const getThesisDraft = async (req, res) => {
  const { thesis_id } = req.params;
  if (!thesis_id || isNaN(thesis_id)) {
    return res.status(400).json({ error: 'Invalid or missing thesis ID.' });
  }

  try {
    const query = `
      SELECT draft_file_path, additional_links
      FROM student_submissions
      WHERE thesis_id = $1
    `;
    const result = await pool.query(query, [thesis_id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'No draft found for this thesis.' });
    }

    const { draft_file_path, additional_links } = result.rows[0];

    return res.status(200).json({
      draft: draft_file_path,
      links: additional_links || []
    });

  } catch (error) {
    console.error('Error fetching thesis draft:', error);
    return res.status(500).json({ error: 'An error occurred while fetching the thesis draft.' });
  }
};

const getPresentationDetails = async (req, res) => {
  const { thesis_id } = req.params;

  if (!thesis_id || isNaN(thesis_id)) {
    return res.status(400).json({ error: 'Invalid or missing thesis ID.' });
  }

  try {
    // 1. Get presentation details
    const presentationQuery = `
      SELECT 
        ss.presentation_datetime,
        ss.presentation_location,
        ss.presentation_link,
        t.student_id
      FROM student_submissions ss
      JOIN theses t ON t.id = ss.thesis_id
      WHERE ss.thesis_id = $1
    `;
    const presentationResult = await pool.query(presentationQuery, [thesis_id]);

    if (presentationResult.rows.length === 0) {
      return res.status(404).json({ message: 'Presentation details not found for this thesis.' });
    }

    const {
      presentation_datetime,
      presentation_location,
      presentation_link,
      student_id
    } = presentationResult.rows[0];

    // 2. Get student name
    const studentQuery = `
      SELECT u.name AS student_name
      FROM students s
      JOIN users u ON s.user_id = u.id
      WHERE s.id = $1
    `;
    const studentResult = await pool.query(studentQuery, [student_id]);
    const student_name = studentResult.rows[0]?.student_name || null;

    // 3. Get professor names and roles
    const professorsQuery = `
      SELECT u.name AS professor_name, tpr.role
      FROM thesis_professor_relationship tpr
      JOIN professors p ON p.id = tpr.professor_id
      JOIN users u ON u.id = p.user_id
      WHERE tpr.thesis_id = $1
    `;
    const professorsResult = await pool.query(professorsQuery, [thesis_id]);

    const committee = professorsResult.rows.map(row => ({
      name: row.professor_name,
      role: row.role
    }));

    // 4. Return everything
    return res.status(200).json({
      presentation_datetime,
      presentation_location,
      presentation_link,
      student_name,
      committee
    });

  } catch (error) {
    console.error('Error fetching presentation details:', error);
    return res.status(500).json({ error: 'An error occurred while retrieving presentation details.' });
  }
};

const postAnnouncement = async (req, res) => {
  const { thesis_id, text } = req.body;

  if (!thesis_id || !text) {
      return res.status(400).json({ message: 'thesis_id and text are required.' });
  }

  try {
      // Check if an announcement already exists for this thesis
      const checkQuery = 'SELECT id FROM announcements WHERE thesis_id = $1 LIMIT 1';
      const checkResult = await pool.query(checkQuery, [thesis_id]);

      if (checkResult.rows.length > 0) {
          return res.status(400).json({ message: 'Announcement already exists for this thesis.' });
      }

      // Insert the new announcement
      const insertQuery = `
          INSERT INTO announcements (thesis_id, text)
          VALUES ($1, $2)
          RETURNING *;
      `;
      const insertResult = await pool.query(insertQuery, [thesis_id, text]);

      res.status(201).json({
          message: 'Announcement created successfully.',
          announcement: insertResult.rows[0]
      });
  } catch (error) {
      console.error('Error posting announcement:', error);
      res.status(500).json({ message: 'Internal server error.' });
  }
};

const enableGrading = async (req, res) => {
  const { thesis_id } = req.params;
  // Validate the thesis_id
  if (!thesis_id || isNaN(thesis_id)) {
      return res.status(400).json({ error: 'Invalid or missing thesis ID.' });
  }

  try {
      // Update the 'grading' column to 'enabled' for the specified thesis_id
      const query = `
          UPDATE theses
          SET grading = 'enabled'
          WHERE id = $1
          RETURNING *;
      `;
      const result = await pool.query(query, [thesis_id]);

      // If no thesis was found, return an error
      if (result.rows.length === 0) {
          return res.status(404).json({ error: 'Thesis not found.' });
      }

      // Successfully updated, return the updated thesis data
      return res.status(200).json({
          message: 'Grading has been enabled for this thesis.',
          thesis: result.rows[0]
      });

  } catch (error) {
      console.error('Error enabling grading:', error);
      return res.status(500).json({ error: 'An error occurred while enabling grading.' });
  }
};

const getThesisGrades = async (req, res) => {
  const thesisId = req.params.id;

  if (!thesisId || isNaN(thesisId)) {
    return res.status(400).json({ error: "Invalid thesis ID" });
  }

  try {
    const gradesQuery = `
      SELECT 
      tpr.grade, 
      tpr.professor_id, 
      u.name
    FROM thesis_professor_relationship tpr
    JOIN professors p ON p.id = tpr.professor_id
    JOIN users u ON u.id = p.user_id
    WHERE tpr.thesis_id = $1
    `;

    const gradingStatusQuery = `
      SELECT grading
      FROM theses
      WHERE id = $1
    `;

    const [gradesResult, gradingStatusResult] = await Promise.all([
      pool.query(gradesQuery, [thesisId]),
      pool.query(gradingStatusQuery, [thesisId])
    ]);

    const gradingStatus = gradingStatusResult.rows[0]?.grading || 'disabled';

    return res.status(200).json({
      grading: gradingStatus,
      grades: gradesResult.rows // { professor_name, grade }
    });

  } catch (error) {
    console.error("Error fetching grades and grading status:", error);
    return res.status(500).json({ error: "Failed to fetch grades or grading status." });
  }
};

const gradeThesis = async (req, res) => {
  const { thesis_id, professor_id, grade } = req.body;

  // Basic presence check
  if (!thesis_id || !professor_id || grade === undefined) {
    return res.status(400).json({ message: 'Missing thesis_id, professor_id, or grade.' });
  }

  // Validate grade is a number between 1 and 10
  const numericGrade = parseFloat(grade);
  if (isNaN(numericGrade) || numericGrade < 1 || numericGrade > 10) {
      return res.status(400).json({ message: 'Grade must be a number between 1 and 10.' });
  }


  try {
      const result = await pool.query(
          `UPDATE thesis_professor_relationship
           SET grade = $1
           WHERE thesis_id = $2 AND professor_id = $3
           RETURNING *`,
          [grade, thesis_id, professor_id]
      );

      if (result.rowCount === 0) {
          return res.status(404).json({ message: 'No matching record found to update.' });
      }

      res.status(200).json({
          message: 'Grade successfully updated.',
          updatedRecord: result.rows[0]
      });
  } catch (error) {
      console.error('Error updating grade:', error);
      res.status(500).json({ message: 'Internal server error.' });
  }
};

////////////////
//// STATS ////
const getProfessorStats = async (req, res) => {
  const professorId = req.params.id; // Get professor ID from request parameters

  try {
    // Step 1: Call the query function to get all completed theses for the professor
    const completedTheses = await handleStatsQueries(professorId);

    // Step 2: Return the result
    return res.status(200).json({ completedTheses });

  } catch (error) {
    console.error('Error fetching professor stats:', error);
    return res.status(500).json({ message: 'Internal server error' });
  }
};

const handleStatsQueries = async (professorId) => {
  try {
    // Step 1: Get all thesis IDs where the professor has participated and the thesis is completed
    const completedResult = await pool.query(
      `SELECT thesis_id
       FROM status_history
       WHERE status = 'completed'
         AND thesis_id IN (SELECT thesis_id FROM thesis_professor_relationship WHERE professor_id = $1)`,
      [professorId]
    );

    if (completedResult.rows.length === 0) {
      return { professorId, completedTheses: [] }; // No completed theses found
    }

    // Extract all thesis IDs from the result
    const completedTheses = completedResult.rows.map(row => row.thesis_id);

    // Step 2: Get professor details (role, grade) for each thesis from thesis_professor_relationship
    const tprResult = await pool.query(
      `SELECT thesis_id, professor_id, role, grade
       FROM thesis_professor_relationship
       WHERE thesis_id = ANY($1::int[])`,
      [completedTheses]
    );

    // Step 3: Get assigned and completed dates from status_history for each thesis
    const statusHistoryResult = await pool.query(
      `SELECT thesis_id, status, updated_at
       FROM status_history
       WHERE thesis_id = ANY($1::int[]) AND status IN ('assigned', 'completed')`,
      [completedTheses]
    );

    // Group the status history data by thesis_id for easy access
    const statusHistoryMap = {};
    statusHistoryResult.rows.forEach(row => {
      if (!statusHistoryMap[row.thesis_id]) {
        statusHistoryMap[row.thesis_id] = {};
      }
      statusHistoryMap[row.thesis_id][row.status] = row.updated_at;
    });

    // Step 4: Build the completedTheses array with additional details
    const completedThesesDetails = completedTheses.map(thesisId => {
      // Filter the TPR result for this thesis
      const thesisDetails = tprResult.rows.filter(row => row.thesis_id === thesisId);

      return {
        thesis_id: thesisId,
        professor_details: thesisDetails.map(detail => ({
          professor_id: detail.professor_id,
          role: detail.role,
          grade: detail.grade
        })),
        assignedDate: statusHistoryMap[thesisId]?.assigned || null,  // Assigned date from status_history
        completedDate: statusHistoryMap[thesisId]?.completed || null // Completed date from status_history
      };
    });

    // Step 5: Return the final result
    return {
      professorId,
      completedTheses: completedThesesDetails
    };

  } catch (error) {
    console.error('Error fetching completed theses with professor details:', error);
    return { error: 'Error fetching completed theses with professor details' };
  }
};


module.exports = { 
  createThesis, getThesesToBeAssigned, editThesis, searchStudents, assignThesisToStudent, getAssignedTheses , cancelThesisAssignment, getProfessorsTheses, 
  getThesisDetails, getCommitteeInvitations, handleInvitationResponse, getOtherProfessors, getProfessorNotes, submitProfessorNote, updateProfessorNote,
  deleteProfessorNote, cancelThesis, setStatusUnderReview, getThesisDraft, postAnnouncement, getPresentationDetails, enableGrading, getThesisGrades, gradeThesis,
  getProfessorStats
};     