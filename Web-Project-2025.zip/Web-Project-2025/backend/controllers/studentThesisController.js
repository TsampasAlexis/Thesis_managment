const path = require('path');
const fs = require('fs');
const pool = require('../db/db'); // Database setup for interaction (PostgreSQL pool)
const { v4: uuidv4 } = require('uuid'); // For generating unique file names (optional but recommended)

////////////////////////////////
//// VIEW MY THESIS OPTION ////

const getMyThesis = async (req, res) => {
    const student_id = req.params.id;  // Get student_id from the URL parameter

    try {
        // Step 1: Retrieve the thesis information based on student ID
        const thesisQuery = `
            SELECT * 
            FROM theses 
            WHERE student_id = $1
        `;
        const thesisResult = await pool.query(thesisQuery, [student_id]);

        if (thesisResult.rows.length === 0) {
            return res.status(404).json({ error: 'No thesis found for this student.' });
        }

        // Thesis record
        const thesis = thesisResult.rows[0];

        // Step 2: Get the professor(s) assigned to the thesis by joining the thesis_professor_relationship table
        const professorQuery = `
            SELECT tpr.professor_id, tpr.role, u.name, u.email
            FROM thesis_professor_relationship tpr
            JOIN professors p ON tpr.professor_id = p.id
            JOIN users u ON p.user_id = u.id
            WHERE tpr.thesis_id = $1
        `;
        const professorResult = await pool.query(professorQuery, [thesis.id]);

        if (professorResult.rows.length === 0) {
            return res.status(404).json({ error: 'No professors found for this thesis.' });
        }

        // Professors information
        const professors = professorResult.rows;

        // Step 3: Get the date the thesis was assigned by looking up the 'assigned' status in status_history
        const statusQuery = `
            SELECT updated_at 
            FROM status_history 
            WHERE thesis_id = $1 AND status = 'assigned'
            ORDER BY updated_at DESC LIMIT 1
        `;
        const statusResult = await pool.query(statusQuery, [thesis.id]);

        if (statusResult.rows.length === 0) {
            return res.status(404).json({ error: 'No assigned status found for this thesis.' });
        }

        // Date the thesis was assigned
        const assignedDate = statusResult.rows[0].updated_at;

        // Step 4: Return the result with all the necessary data
        return res.status(200).json({
            message: 'Thesis retrieved successfully.',
            thesis: thesis,  // Thesis record
            professors: professors,  // Professors related to this thesis
            assignedDate: assignedDate  // Date when the thesis was assigned
        });

    } catch (error) {
        console.error('Error fetching thesis:', error);
        return res.status(500).json({ error: 'An error occurred while fetching the thesis.' });
    }
};

const getProfileData = async (req, res) => {
    try {
        const { id } = req.params; // Get the student ID from the request params

        // Query to join the students table with the users table and get the full user profile
        const query = `
            SELECT u.*
            FROM students s
            JOIN users u ON s.user_id = u.id
            WHERE s.id = $1
        `;
        
        // Execute the query to fetch the user profile based on student ID
        const result = await pool.query(query, [id]);

        // Check if the student record was found
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Student or associated user not found' });
        }

        // Extract the user data and remove the password field
        const userData = result.rows[0];
        delete userData.password;

        // Return the user profile data
        return res.status(200).json({ profile: userData });
    } catch (error) {
        console.error('Error fetching profile data:', error);
        return res.status(500).json({ error: 'An error occurred while fetching profile data' });
    }
};

const updateContactInfo = async (req, res) => {
    const studentId = req.params.id;
    const { name, email, address, cell_phone, home_phone } = req.body;

    try {
        // First, get user_id from students table
        const studentResult = await pool.query(
            'SELECT user_id FROM students WHERE id = $1',
            [studentId]
        );

        if (studentResult.rows.length === 0) {
            return res.status(404).json({ error: 'Student not found' });
        }

        const userId = studentResult.rows[0].user_id;

        // Update users table with new contact info
        await pool.query(
            `UPDATE users
             SET name = $1, email = $2, address = $3, cell_phone = $4, home_phone = $5
             WHERE id = $6`,
            [name, email, address, cell_phone, home_phone, userId]
        );

        res.json({ message: 'Contact information updated successfully.' });
    } catch (error) {
        console.error('Error updating contact info:', error);
        res.status(500).json({ error: 'Server error while updating contact info.' });
    }
};

const getStatusBasedData = async (req, res) => {
    const studentId = req.params.id;

    try {
        // Get status and thesis ID
        const statusResult = await pool.query(
            'SELECT id, status FROM theses WHERE student_id = $1',
            [studentId]
        );

        if (statusResult.rows.length === 0) {
            return res.status(404).json({ error: 'No thesis found for this student.' });
        }

        const { id: thesisId, status } = statusResult.rows[0];

        // Handle status-specific logic
        if (status === 'assigned') {
            const invitationsResult = await pool.query(`
                SELECT 
                    ci.*, 
                    u.name AS professor_name, 
                    u.email AS professor_email
                FROM committee_invitations ci
                JOIN professors p ON ci.professor_id = p.id
                JOIN users u ON p.user_id = u.id
                WHERE ci.thesis_id = $1
            `,[thesisId]
            );

            return res.status(200).json({
                message: 'Status retrieved successfully.',
                status: status,
                thesis_id: thesisId,
                invitations: invitationsResult.rows
            });
        }

        // Handle status-specific logic
        if (status === 'under review') {
            // const invitationsResult = await pool.query(`
            //     SELECT 
            //         ci.*, 
            //         u.name AS professor_name, 
            //         u.email AS professor_email
            //     FROM committee_invitations ci
            //     JOIN professors p ON ci.professor_id = p.id
            //     JOIN users u ON p.user_id = u.id
            //     WHERE ci.thesis_id = $1
            // `,[thesisId]
            // );

            return res.status(200).json({
                message: 'Status retrieved successfully.',
                status: status,
                thesis_id: thesisId
            });
        }

        if (status === 'completed') {
          // 1. Get professors' roles, names, and grades
          const professorsResult = await pool.query(`
            SELECT 
              tpr.role,
              tpr.grade,
              u.name AS professor_name
            FROM thesis_professor_relationship tpr
            JOIN professors p ON tpr.professor_id = p.id
            JOIN users u ON p.user_id = u.id
            WHERE tpr.thesis_id = $1
          `, [thesisId]);

          // 2. Get status history
          const statusHistoryResult = await pool.query(`
            SELECT status, updated_at
            FROM status_history
            WHERE thesis_id = $1
            ORDER BY updated_at ASC
          `, [thesisId]);

          // 3. Get nimertis link
          const submissionResult = await pool.query(`
            SELECT nimertis_link
            FROM student_submissions
            WHERE thesis_id = $1
            LIMIT 1
          `, [thesisId]);

          const completedData = {
            professors: professorsResult.rows,
            status_history: statusHistoryResult.rows,
            nimertis_link: submissionResult.rows[0]?.nimertis_link || null
          };

          return res.status(200).json({
            message: 'Status retrieved successfully.',
            status: status,
            thesis_id: thesisId,
            completed_data: completedData
          });

        }
        // Default response for statuses we haven’t handled yet
        return res.status(200).json({
            message: 'Status retrieved successfully.',
            status: status
        });

    } catch (error) {
        console.error("Error fetching status-based data:", error);
        res.status(500).json({ error: 'Failed to fetch thesis status.' });
    }
};

const searchProfessors = async (req, res) => {
    const query = req.query.query.trim(); // Get the query from the request

    try {
        let professorsData;

        // Check if the query is a number (professor_id search)
        if (!isNaN(query)) {
            // Search by professor_id
            professorsData = await pool.query(`
                SELECT u.name AS professor_name, u.email AS professor_email, p.id
                FROM professors p
                JOIN users u ON p.user_id = u.id
                WHERE p.id = $1
            `, [query]);

        } else {
            // Search by name or email (user search)
            professorsData = await pool.query(`
                SELECT u.name AS professor_name, u.email AS professor_email, p.id
                FROM users u
                JOIN professors p ON u.id = p.user_id
                WHERE (u.name ILIKE $1 OR u.email ILIKE $1) AND u.role = 'professor'
            `, [`%${query}%`]);
        }

        return res.status(200).json({
            message: 'Professors found successfully.',
            professors: professorsData.rows
        });

    } catch (error) {
        console.error("Error during professor search:", error);
        res.status(500).json({ error: 'Failed to search for professors.' });
    }
};

const inviteProfessor = async (req, res) => {
    const { thesis_id, professor_id } = req.body;

    try {
        const query = `
            INSERT INTO committee_invitations (thesis_id, professor_id, status)
            VALUES ($1, $2, 'pending')
            RETURNING *;
            `;
        const values = [thesis_id, professor_id];

        // Execute the query using pool.query
        const result = await pool.query(query, values); // Use pool.query, not db.query
        
        const invitation = result.rows[0];

        return res.status(201).json({ message: 'Invitation sent successfully.', invitation: invitation });
    } catch (error) {
        console.error('Error sending invite:', error);
        res.status(500).json({ error: 'Server error while sending invite.' });
    }
};

const uploadDraft = async (req, res) => {
    const thesis_id = parseInt(req.body.thesis_id, 10);
  
    if (isNaN(thesis_id)) {
      return res.status(400).json({ message: 'Invalid thesis ID.' });
    }
  
    // Normalize the links from the form
    const rawLinks = req.body['links[]'];
    const additionalLinks = Array.isArray(rawLinks)
      ? rawLinks.filter(link => link.trim() !== '')
      : rawLinks
      ? [rawLinks.trim()]
      : [];
  
    // Handle thesis draft file upload
    let draftFilePath = null;
    if (req.files && req.files.thesisDraft) {
      const draftFile = req.files.thesisDraft;
      const fileExtension = path.extname(draftFile.name);
      const fileName = `${uuidv4()}${fileExtension}`;
      const uploadDir = path.join(__dirname, '../uploads/studentDrafts');
      const uploadPath = path.join(uploadDir, fileName);
  
      try {
        if (!fs.existsSync(uploadDir)) {
          fs.mkdirSync(uploadDir, { recursive: true });
        }
  
        await draftFile.mv(uploadPath); // Promisified version (or use callback if needed)
        draftFilePath = `/uploads/studentDrafts/${fileName}`;
      } catch (err) {
        console.error('Upload error:', err);
        return res.status(500).json({ message: 'Error processing the thesis draft.' });
      }
    }

    // Get presentation fields
    const presentation_datetime = req.body.presentation_datetime || null;
    const presentation_location = req.body.presentation_location?.trim() || null;
    const presentation_link = req.body.presentation_link?.trim() || null;
  
    try {
      const insertQuery = `
      INSERT INTO student_submissions 
        (thesis_id, draft_file_path, additional_links, presentation_datetime, presentation_location, presentation_link)
      VALUES 
        ($1, $2, $3, $4, $5, $6)
      RETURNING *;
    `;
  
    const values = [
        thesis_id,
        draftFilePath,
        additionalLinks,
        presentation_datetime,
        presentation_location,
        presentation_link
      ];
  
      const result = await pool.query(insertQuery, values);
  
      return res.status(200).json({
        message: 'Thesis draft uploaded and saved successfully.',
        submission: result.rows[0],
      });
    } catch (err) {
      console.error('DB insert error:', err);
      return res.status(500).json({ message: 'Error saving submission to the database.' });
    }
};  

const editDraft = async (req, res) => {
    const thesis_id = parseInt(req.body.thesis_id, 10);
    if (isNaN(thesis_id)) {
        return res.status(400).json({ message: 'Invalid thesis ID.' });
    }

    // Normalize links
    const rawLinks = req.body['links[]'];
    const additionalLinks = Array.isArray(rawLinks)
        ? rawLinks.filter(link => link.trim() !== '')
        : rawLinks
        ? [rawLinks.trim()]
        : [];

    // Normalize presentation fields
    const presentation_datetime = req.body.presentation_datetime || null;
    let presentation_location = req.body.presentation_location?.trim() || null;
    let presentation_link = req.body.presentation_link?.trim() || null;

    // Enforce mutual exclusivity
    if (presentation_location) {
        presentation_link = null;
    } else if (presentation_link) {
        presentation_location = null;
    }

    let draftFilePath = null;

    try {
        // Fetch current draft file path
        const existingQuery = `SELECT draft_file_path FROM student_submissions WHERE thesis_id = $1`;
        const existingResult = await pool.query(existingQuery, [thesis_id]);

        if (existingResult.rows.length === 0) {
            return res.status(404).json({ message: 'Submission not found.' });
        }

        const existingFilePath = existingResult.rows[0].draft_file_path;

        // Handle new draft file
        if (req.files && req.files.thesisDraft) {
            const draftFile = req.files.thesisDraft;
            const fileExtension = path.extname(draftFile.name);
            const fileName = `${uuidv4()}${fileExtension}`;
            const uploadDir = path.join(__dirname, '../uploads/studentDrafts');
            const uploadPath = path.join(uploadDir, fileName);

            if (!fs.existsSync(uploadDir)) {
                fs.mkdirSync(uploadDir, { recursive: true });
            }

            await draftFile.mv(uploadPath);
            draftFilePath = `/uploads/studentDrafts/${fileName}`;

            // Delete old file
            if (existingFilePath) {
                const oldFullPath = path.join(__dirname, '..', existingFilePath);
                if (fs.existsSync(oldFullPath)) {
                    fs.unlinkSync(oldFullPath);
                }
            }
        } else {
            // Keep old path if no new file is uploaded
            draftFilePath = existingFilePath;
        }

        // Final update
        const updateQuery = `
            UPDATE student_submissions
            SET draft_file_path = $1,
                additional_links = $2,
                presentation_datetime = $3,
                presentation_location = $4,
                presentation_link = $5
            WHERE thesis_id = $6
            RETURNING *;
        `;

        const values = [
            draftFilePath,
            additionalLinks,
            presentation_datetime || null,
            presentation_location || null,
            presentation_link || null,
            thesis_id
        ];

        const result = await pool.query(updateQuery, values);

        return res.status(200).json({
            message: 'Thesis draft updated successfully.',
            submission: result.rows[0],
        });
    } catch (err) {
        console.error('Edit draft error:', err);
        return res.status(500).json({ message: 'Error updating submission.' });
    }
};

const getMyThesisDraft = async (req, res) => {
    const thesis_id = req.params.id;
  
    try {
      // Step 1: Check grades
      const gradeQuery = `
        SELECT grade FROM thesis_professor_relationship WHERE thesis_id = $1
      `;
      const gradeResult = await pool.query(gradeQuery, [thesis_id]);
  
      const grades = gradeResult.rows.map(row => row.grade);
  
      // If there are no records at all, fallback to getPregardingData (safety net)
      if (grades.length === 0 || grades.some(g => g === null)) {
        return await getPregardingData(req, res);
      }
  
      // All records are graded
      return await getPostGradingData(req, res);
  
    } catch (error) {
      console.error('Error determining grading status:', error);
      return res.status(500).json({ error: 'An error occurred while checking grades.' });
    }
};

  const getPregardingData = async (req, res) => {
    const thesis_id = req.params.id;
  
    try {
      const query = `
        SELECT draft_file_path, additional_links, 
               presentation_datetime, presentation_location, 
               presentation_link, nimertis_link
        FROM student_submissions 
        WHERE thesis_id = $1
      `;
      const result = await pool.query(query, [thesis_id]);
  
      if (result.rows.length === 0 || result.rows[0].draft_file_path === null) {
        return res.status(404).json({ message: 'No draft found for this student.' });
      }
  
      const {
        draft_file_path,
        additional_links,
        presentation_datetime,
        presentation_location,
        presentation_link,
        nimertis_link
      } = result.rows[0];
  
      return res.status(200).json({
        message: 'Draft retrieved successfully.',
        draft: draft_file_path,
        links: additional_links || [],
        presentation_datetime,
        presentation_location,
        presentation_link,
        nimertis_link
      });
  
    } catch (error) {
      console.error('Error fetching thesis (pre-grading):', error);
      return res.status(500).json({ error: 'An error occurred while fetching the draft.' });
    }
};
  
const getPostGradingData = async (req, res) => {
    const thesis_id = req.params.id;

    try {
        const query = `
            SELECT nimertis_link 
            FROM student_submissions
            WHERE thesis_id = $1
        `;
        const result = await pool.query(query, [thesis_id]);

        if (result.rows.length === 0) {
            return res.status(404).json({ message: 'No submission found for this thesis.' });
        }

        return res.status(200).json({
            message: 'Post grading data retrieved successfully.',
            nimertis_link: result.rows[0].nimertis_link || null
        });
    } catch (error) {
        console.error('Error fetching post grading data:', error);
        return res.status(500).json({ message: 'Failed to retrieve post grading data.' });
    }
};

const setNimertisLink = async (req, res) => {
    const thesisId = req.params.id;
    const { nimertis_link } = req.body;
  
    if (!nimertis_link || typeof nimertis_link !== 'string') {
      return res.status(400).json({ message: 'A valid Nimertis link must be provided.' });
    }
  
    try {
      const updateQuery = `
        UPDATE student_submissions
        SET nimertis_link = $1
        WHERE thesis_id = $2
        RETURNING id, nimertis_link;
      `;
  
      const result = await pool.query(updateQuery, [nimertis_link.trim(), thesisId]);
  
      if (result.rowCount === 0) {
        return res.status(404).json({ message: 'Thesis not found.' });
      }
  
      return res.status(200).json({
        message: 'Nimertis link updated successfully.',
        thesis: result.rows[0]
      });
    } catch (error) {
      console.error('Error updating Nimertis link:', error);
      return res.status(500).json({ message: 'Internal server error.' });
    }
};
const getExaminationReportData = async (req, res) => {
    const { id: thesis_id } = req.params;
    console.log('thesis ID: ' ,thesis_id);
  
    try {
      // 1. Get thesis details
      const thesisQuery = `
        SELECT title, student_id, meeting_info
        FROM theses
        WHERE id = $1;
      `;
      const thesisResult = await pool.query(thesisQuery, [thesis_id]);
  
      if (thesisResult.rows.length === 0) {
        return res.status(404).json({ message: 'Thesis not found.' });
      }
  
      const thesis = thesisResult.rows[0];
  
      // 2. Get student name
      const studentQuery = `
        SELECT u.name 
        FROM students s
        JOIN users u ON s.user_id = u.id
        WHERE s.id = $1;
      `;
      const studentResult = await pool.query(studentQuery, [thesis.student_id]);
  
      if (studentResult.rows.length === 0) {
        return res.status(404).json({ message: 'Student not found.' });
      }
  
      const studentName = studentResult.rows[0].name;
  
      // 3. Get professor details (for all professors related to this thesis)
      const professorQuery = `
        SELECT p.id AS professor_id, tr.role, tr.grade
        FROM thesis_professor_relationship tr
        JOIN professors p ON tr.professor_id = p.id
        WHERE tr.thesis_id = $1;
      `;

      const professorResult = await pool.query(professorQuery, [thesis_id]);
  
      const professors = [];
      for (let professor of professorResult.rows) {
        const professorNameQuery = `
          SELECT u.name
          FROM professors p
          JOIN users u ON p.user_id = u.id
          WHERE p.id = $1;
        `;
        const professorNameResult = await pool.query(professorNameQuery, [professor.professor_id]);
        console.log(professorNameResult);
  
        if (professorNameResult.rows.length > 0) {
          professors.push({
            professor_name: professorNameResult.rows[0].name,
            role: professor.role,
            grade: professor.grade
          });
        }
      }
  
      // 4. Get presentation details
      const presentationQuery = `
        SELECT presentation_datetime, presentation_location, presentation_link
        FROM student_submissions
        WHERE thesis_id = $1;
      `;
      const presentationResult = await pool.query(presentationQuery, [thesis_id]);
  
      let presentationDetails = {};
      if (presentationResult.rows.length > 0) {
        const presentation = presentationResult.rows[0];
        presentationDetails = {
          presentation_datetime: presentation.presentation_datetime,
          presentation_location: presentation.presentation_location,
          presentation_link: presentation.presentation_link
        };
      }
  
      // Return all the gathered data
      return res.status(200).json({
        message: 'Examination report data retrieved successfully.',
        thesis: {
          title: thesis.title,
          student_name: studentName,
          meeting_info: thesis.meeting_info
        },
        professors,
        presentation_details: presentationDetails
      });
  
    } catch (err) {
      console.error('Error retrieving examination report data:', err);
      return res.status(500).json({ message: 'Error retrieving examination report data.' });
    }
};
  

module.exports = { 
    getMyThesis, getProfileData, updateContactInfo, getStatusBasedData, searchProfessors, inviteProfessor, uploadDraft, getMyThesisDraft, editDraft, 
    setNimertisLink, getExaminationReportData
};