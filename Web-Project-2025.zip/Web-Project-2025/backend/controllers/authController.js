const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const pool = require('../db/db'); // Your DB connection

// Login Controller
const loginUser = async (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).json({ message: 'Username and password are required.' });
  }

  try {
    // Step 1: Check if the user exists
    const query = 'SELECT * FROM users WHERE username = $1';
    const result = await pool.query(query, [username]);

    if (result.rows.length === 0) {
      return res.status(401).json({ message: 'Invalid username.' });
    }

    const user = result.rows[0];

    // Step 2: Compare password
    const match = await bcrypt.compare(password, user.password);
    if (!match) {
      return res.status(401).json({ message: 'Invalid password.' });
    }

    // Step 3: Get the role information (role ID)
    let roleId = null;
    if (user.role === 'professor') {
      // Fetch the professor-specific ID from the 'professors' table
      const professorResult = await pool.query('SELECT id FROM professors WHERE user_id = $1', [user.id]);
      if (professorResult.rows.length === 0) {
        return res.status(400).json({ message: 'Professor role data not found.' });
      }
      roleId = professorResult.rows[0].id;
    } else if (user.role === 'student') {
      // Fetch the student-specific ID from the 'students' table
      const studentResult = await pool.query('SELECT id FROM students WHERE user_id = $1', [user.id]);
      if (studentResult.rows.length === 0) {
        return res.status(400).json({ message: 'Student role data not found.' });
      }
      roleId = studentResult.rows[0].id;
    } else if (user.role === 'secretariat') {
      roleId = null;
    }

    // Step 4: Generate JWT token
    const token = jwt.sign(
      { id: user.id, username: user.username, role: user.role, roleId: roleId },
      process.env.JWT_SECRET,
      { expiresIn: '1h' }
    );

    // Step 5: Store the token in the session
    req.session.token = token;

    // Include role and roleId in the response along with the token
    res.json({ message: 'Login successful', token, username: user.username, role: user.role, roleId: roleId });
  } catch (err) {
    console.error('Error during login:', err);
    res.status(500).json({ message: 'Server error' });
  }
};

// Logout Controller
const logoutUser = (req, res) => {
  // Destroy the session (clears the stored token)
  req.session.destroy((err) => {
    if (err) {
      return res.status(500).json({ message: 'Failed to log out, please try again.' });
    }
    res.json({ message: 'Logged out successfully' });
  });
};

module.exports = {
  loginUser, 
  logoutUser,
};