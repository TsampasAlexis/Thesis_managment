const path = require('path');
const fs = require('fs');
const pool = require('../db/db'); // Database setup for interaction (PostgreSQL pool)
const { v4: uuidv4 } = require('uuid'); // For generating unique file names (optional but recommended)

//////////////////////////////////////////  
//// ROUTES FOR ACTIVE THESES OPTION ////

const getActiveTheses = async (req, res) => {
    try {
        // Step 1: Fetch active theses
        const thesisResult = await pool.query(`
            SELECT t.*, u.name AS student_name, u.email AS student_email
            FROM theses t
            JOIN students s ON t.student_id = s.id
            JOIN users u ON s.user_id = u.id
            WHERE t.status IN ('in progress', 'under review')
        `);

        const theses = thesisResult.rows;

        for (const thesis of theses) {
            // Step 2: Fetch professors associated with the thesis
            const professorResult = await pool.query(`
                SELECT 
                    tpr.professor_id,
                    u.name AS professor_name,
                    u.email AS professor_email,
                    tpr.grade,
                    tpr.role
                FROM thesis_professor_relationship tpr
                JOIN professors p ON tpr.professor_id = p.id
                JOIN users u ON p.user_id = u.id
                WHERE tpr.thesis_id = $1
            `, [thesis.id]);

            thesis.professors = professorResult.rows;

            // Step 3: Fetch the most recent 'assigned' status from status_history
            const statusHistoryResult = await pool.query(`
                SELECT updated_at
                FROM status_history
                WHERE thesis_id = $1 AND status = 'assigned'
                ORDER BY updated_at DESC
                LIMIT 1
            `, [thesis.id]);

            const assignedStatus = statusHistoryResult.rows[0];

            if (assignedStatus) {
                const now = new Date();
                const assignedDate = new Date(assignedStatus.updated_at);
                const diffMs = now - assignedDate;
                
                // Convert to days (rounded)
                const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
                
                thesis.time_since_assignment = `${diffDays} day${diffDays !== 1 ? 's' : ''}`;
            } else {
                thesis.time_since_assignment = 'N/A';
            }

            // Step 4: Fetch the nimertis_link from student_submissions
            const submissionResult = await pool.query(`
                SELECT nimertis_link
                FROM student_submissions
                WHERE thesis_id = $1
            `, [thesis.id]);

            // Add nimertis_link to the thesis object if it exists
            if (submissionResult.rows.length > 0) {
                thesis.nimertis_link = submissionResult.rows[0].nimertis_link;
            } else {
                thesis.nimertis_link = null;
            }
        }

        // Step 5: Return the data to the client
        res.status(200).json(theses);
    } catch (error) {
        console.error('Error fetching active theses:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};


const setMeetingInfo = async (req, res) => {
    const { thesis_id } = req.params;
    const { meeting_info } = req.body;

    // Validate presence and structure
    if (!meeting_info || typeof meeting_info !== 'object') {
        return res.status(400).json({ message: 'Invalid or missing meeting_info.' });
    }

    const { number, date } = meeting_info;

    // Validate number
    const parsedNumber = parseInt(number, 10);
    if (isNaN(parsedNumber)) {
        return res.status(400).json({ message: 'Meeting number must be an integer.' });
    }

    // Validate date
    const parsedDate = new Date(date);
    if (isNaN(parsedDate.getTime())) {
        return res.status(400).json({ message: 'Meeting date is invalid.' });
    }

    const fullMeetingInfo = {
        number: parsedNumber,
        date: parsedDate.toISOString() // Store as ISO string
    };

    try {
        const updateQuery = `
            UPDATE theses
            SET meeting_info = $1
            WHERE id = $2
            RETURNING *;
        `;
        const result = await pool.query(updateQuery, [fullMeetingInfo, thesis_id]);

        if (result.rowCount === 0) {
            return res.status(404).json({ message: 'Thesis not found.' });
        }

        return res.status(200).json({ message: 'Meeting info updated successfully.' });
    } catch (error) {
        console.error('Error setting meeting info:', error);
        return res.status(500).json({ message: 'Internal server error.' });
    }
};

const cancelAssignment = async (req, res) => {
    const { thesis_id } = req.params;

    try {
        // Start a transaction
        const client = await pool.connect();
        try {
            await client.query('BEGIN');

            // 1. Update thesis status
            const updateThesisQuery = `
                UPDATE theses
                SET status = 'canceled'
                WHERE id = $1
                RETURNING *;
            `;
            const thesisResult = await client.query(updateThesisQuery, [thesis_id]);

            if (thesisResult.rowCount === 0) {
                await client.query('ROLLBACK');
                return res.status(404).json({ message: 'Thesis not found.' });
            }

            // 2. Insert cancelation record
            const insertCancelationQuery = `
                INSERT INTO thesis_cancellations (thesis_id, reason, date)
                VALUES ($1, $2, NOW());
            `;
            await client.query(insertCancelationQuery, [thesis_id, 'canceled by student']);

            await client.query('COMMIT');
            return res.status(200).json({ message: 'Thesis assignment canceled successfully.' });

        } catch (error) {
            await client.query('ROLLBACK');
            console.error('Transaction error:', error);
            return res.status(500).json({ message: 'Error canceling thesis assignment.' });
        } finally {
            client.release();
        }

    } catch (err) {
        console.error('Database error:', err);
        return res.status(500).json({ message: 'Internal server error.' });
    }
};

const completeThesis = async (req, res) => {
    try {
        const { thesis_id } = req.params; // Get thesis ID from URL parameter

        // Update thesis status to 'completed' in the database
        const result = await pool.query(`
            UPDATE theses
            SET status = 'completed'
            WHERE id = $1
            RETURNING id, title, status
        `, [thesis_id]);

        if (result.rows.length > 0) {
            const updatedThesis = result.rows[0];
            return res.status(200).json({
                message: `Thesis with ID ${updatedThesis.id} marked as completed.`,
                thesis: updatedThesis,
            });
        } else {
            return res.status(404).json({ error: "Thesis not found." });
        }
    } catch (error) {
        console.error("Error marking thesis as completed:", error);
        res.status(500).json({ error: "Internal server error" });
    }
};


module.exports = { 
  getActiveTheses, setMeetingInfo, cancelAssignment, completeThesis
  }; 