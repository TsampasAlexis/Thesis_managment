const express = require('express');  //load library express.js
const cors = require('cors'); //allow request
const session = require('express-session'); //cookies-based session
const fileUpload = require('express-fileupload'); //PDF
const path = require('path'); //Χειρισμος path
const authController = require('./controllers/authController');
const { registerUser, createUsers } = require('./controllers/userController');  
const { authenticate, authorizeRole } = require('./middleware/authMiddleware');

// PROFESSOR STUFF
const { 
  createThesis, getThesesToBeAssigned, editThesis, searchStudents, assignThesisToStudent, getAssignedTheses, cancelThesisAssignment, getProfessorsTheses, 
  getThesisDetails, getCommitteeInvitations, handleInvitationResponse, getOtherProfessors, getProfessorNotes, submitProfessorNote, updateProfessorNote,
  deleteProfessorNote, cancelThesis, setStatusUnderReview, getThesisDraft, postAnnouncement, getPresentationDetails, enableGrading, getThesisGrades, gradeThesis,
  getProfessorStats
} = require('./controllers/professorThesisController');

 // STUDENT STUFF
const {
  getMyThesis, getProfileData, updateContactInfo, getStatusBasedData, searchProfessors, inviteProfessor, uploadDraft, getMyThesisDraft, editDraft, 
  setNimertisLink, getExaminationReportData
} = require('./controllers/studentThesisController');

 // SECRETARIAT STUFF
 const {
  getActiveTheses, setMeetingInfo, cancelAssignment, completeThesis
} = require('./controllers/secretariatThesisController');

const pool = require('./db/db'); // DB connection(PostgreSQL)
require('dotenv').config(); //load .env

// Create an express app(WEB server)
const app = express();
const port = process.env.PORT //Port 5000

// Use CORS middleware to allow all domains users
app.use(cors());

// Middleware to parse(αναλυω) JSON requests
app.use(express.json());

// Middleware to parse URL-encoded data (for forms) and multipart (for file uploads)
app.use(express.urlencoded({ extended: true }));

// Show static files (like PDFs) from the 'uploads' folder
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Middleware for handling file uploads (PDF files)
app.use(fileUpload()); // Add this middleware to handle file uploads

// Configure the session middleware
app.use(
  session({
    secret: process.env.JWT_SECRET,
    resave: false,
    saveUninitialized: true,
    cookie: {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
    },
  })
);


// ROUTES (reorganize later)
// Route to register a new user
//app.post('/register', registerUser);

// Route for login
app.post('/login', authController.loginUser);

// Logout route
app.post('/logout', authController.logoutUser);

// protect data  of role based routes
app.get('/protected', authenticate, (req, res) => {
  res.json({ message: 'This is a protected route', user: req.user });
});

///////////////////////////
//// PROFESSOR ROUTES ////
// Professor test route

// routes for initializing theses
app.post('/professor/theses', authenticate, authorizeRole(['professor']), createThesis);  // Create Thesis
app.get('/professor/theses', authenticate, authorizeRole(['professor']), getThesesToBeAssigned);  // Get theses to be assigned//προςΑναθεση
app.put('/professor/theses/:id', authenticate, authorizeRole(['professor']), editThesis);  // Update Thesis

// Routes for initial thesis assignment
app.get('/professor/students/search', authenticate, authorizeRole(['professor']), searchStudents); //Searching for students
app.put('/professor/theses/:id/assign', authenticate, authorizeRole(['professor']), assignThesisToStudent); // Αναθεση σε φοιτητη


// routes for cacelling assignment
app.get('/professor/theses/assigned', authenticate, authorizeRole(['professor']), getAssignedTheses);//GET Assigned List
app.delete('/professor/theses/:id/cancel', authenticate, authorizeRole(['professor']), cancelThesisAssignment);//Delete Assign

// routes for the view all theses option
app.get('/professor/theses/all', authenticate, authorizeRole(['professor']), getProfessorsTheses);
app.get('/professor/theses/:thesis_id/details', authenticate, authorizeRole(['professor']), getThesisDetails);
app.get('/professor/assigned/otherProfessors', authenticate, authorizeRole(['professor']), getOtherProfessors);
app.get('/professor/inProgress/getNotes', authenticate, authorizeRole(['professor']), getProfessorNotes);
app.post('/professor/inProgress/addNote/:thesis_id/:professor_id', authenticate, authorizeRole(['professor']), submitProfessorNote);
app.put('/professor/notes/:id', authenticate, authorizeRole(['professor']), updateProfessorNote);
app.delete('/professor/notes/:id', authenticate, authorizeRole(['professor']), deleteProfessorNote);
app.post('/professor/cancelThesis/:thesis_id/:professor_id', authenticate, authorizeRole(['professor']), cancelThesis);
app.put('/professor/startReviewProcess/:id', authenticate, authorizeRole(['professor']), setStatusUnderReview);
app.get('/professor/theses/draft/:thesis_id', authenticate, authorizeRole(['professor']), getThesisDraft); //From student drafted
app.get('/professor/theses/presentation/:thesis_id', authenticate, authorizeRole(['professor']), getPresentationDetails);
app.post('/professor/announcements', authenticate, authorizeRole(['professor']), postAnnouncement);
app.put('/professor/enableGrading/:thesis_id', authenticate, authorizeRole(['professor']), enableGrading); //Ενεργοποιηση Βαθμολογιας
app.get('/professor/thesisGrades/:id', authenticate, authorizeRole(['professor']), getThesisGrades);//Δες βαθμους
app.put('/professor/gradeThesis', authenticate, authorizeRole(['professor']), gradeThesis);//Υποβολη απο καθηγητη
app.get('/professor/:id/examinationReport/', authenticate, authorizeRole(['professor']), getExaminationReportData);

// routes for professor committte invitations
app.get('/professor/invitations/:id', authenticate, authorizeRole(['professor']), getCommitteeInvitations); //Εκκρεμμεις προσκλησεις επιτροπης
app.post('/professor/invitation/response', authenticate, authorizeRole(['professor']), handleInvitationResponse); //Αποδοχη/απορριψη

// routes for stats
app.get('/professor/:id/stats/', authenticate, authorizeRole(['professor']), getProfessorStats);

/////////////////////////
//// STUDENT ROUTES ////
app.get('/student/myThesis/:id', authenticate, authorizeRole(['student']), getMyThesis);
app.get('/student/profile/:id', authenticate, authorizeRole(['student']), getProfileData);
app.put('/student/updateContact/:id', authenticate, authorizeRole(['student']), updateContactInfo);
app.get('/student/status-data/:id', authenticate, authorizeRole(['student']), getStatusBasedData); //Αν γινει Edit
app.get('/searchProfessors', authenticate, authorizeRole(['student']), searchProfessors); //invitation
app.post('/student/inviteProfessor', authenticate, authorizeRole(['student']), inviteProfessor);
app.post('/student/uploadDraft', authenticate, authorizeRole(['student']), uploadDraft);//upload διπλωματικης 
app.put('/student/editDraft', authenticate, authorizeRole(['student']), editDraft);
app.put('/student/nimertisLink/:id', authenticate, authorizeRole(['student']), setNimertisLink);//Αποθηκευση Συνδεσμου
app.get('/student/myThesisdraft/:id', authenticate, authorizeRole(['student']), getMyThesisDraft);//Κανει show την διπλωματικη του στο Thesisdraft
app.get('/student/:id/examinationReport/', authenticate, authorizeRole(['student']), getExaminationReportData); //Show αναφορα

/////////////////////////////
//// SECRETARIAT ROUTES ////
app.get('/secretariat/activeTheses', authenticate, authorizeRole(['secretariat']), getActiveTheses);
app.post('/secretariat/createUsers', authenticate, authorizeRole(['secretariat']), createUsers); //δημιουργια χρηστων
app.put('/secretariat/:thesis_id/setMeetingInfo', authenticate, authorizeRole(['secretariat']), setMeetingInfo);
app.put('/secretariat/:thesis_id/cancel', authenticate, authorizeRole(['secretariat']), cancelAssignment);
app.put('/secretariat/:thesis_id/complete', authenticate, authorizeRole(['secretariat']), completeThesis);

// public announcements endpoint
// Route: GET /public/announcements
app.get('/public/announcements', async (req, res) => {
  try {
      const { from } = req.query;   
      let queryParams = []; // Θα χρησιμοποιήσουμε αυτό το array για να περάσουμε παραμέτρους με ασφάλεια στο SQL query
      let query = `
          SELECT 
              t.title,
              a.text,
              a.created_at
          FROM announcements a
          JOIN theses t ON a.thesis_id = t.id
      `;

      // Αν έχει δοθεί παράμετρος "from" (δηλαδή από ποια ημερομηνία και μετά να φέρει ανακοινώσεις)
      if (from) {
          const fromDate = new Date(from); //Μετατροπη σε αντικειμενο Date
          if (isNaN(fromDate.getTime())) {
              return res.status(400).json({ message: 'Invalid date format for "from" parameter.' });
          }
          query += ' WHERE a.created_at >= $1'; //Where Filter
          queryParams.push(fromDate.toISOString());
      }

      query += ' ORDER BY a.created_at DESC'; //Φιλτρο ταξινομησης

      const result = await pool.query(query, queryParams); //στελνει το SQL στη βαση και περιμενει απαντηση
      res.json(result.rows); //JSON αποτελεσμα
  } catch (err) {
      console.error('Error fetching announcements:', err);
      res.status(500).json({ message: 'Internal server error' });
  }
});

// Backend route for dashboard, protected by the authentication middleware
app.get('/dashboard', authenticate, (req, res) => {
  res.json({ message: 'Welcome to the protected Dashboard!', user: req.user });
});

// Start the server
app.listen(port, () => {
  console.log(`Backend running on http://localhost:${port}`);
});