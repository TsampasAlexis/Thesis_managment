const jwt = require('jsonwebtoken');

const authenticate = (req, res, next) => {
  const token = req.session.token || req.headers['authorization']?.split(' ')[1]; // Check for token in session or Authorization header

  if (!token) {
    return res.status(401).json({ message: 'Unauthorized: No token provided.' });
  }

  try {
    // Verify the token
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded; // Attach user data to request for further use
    next();
  } catch (err) {
    return res.status(401).json({ message: 'Unauthorized: Invalid or expired token.' });
  }
};

// Middleware to check for specific role access
const authorizeRole = (roles) => {
  return (req, res, next) => {
    const { role } = req.user; // Get role from decoded JWT (attached in authenticate middleware)

    if (!roles.includes(role)) {
      return res.status(403).json({ message: 'Forbidden: You do not have permission to access this resource.' });
    }

    next(); // User has the correct role, continue to the next middleware or route handler
  };
};

module.exports = { authenticate, authorizeRole };